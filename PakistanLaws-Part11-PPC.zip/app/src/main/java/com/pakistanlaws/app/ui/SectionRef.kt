package com.pakistanlaws.app.ui

import com.pakistanlaws.app.content.LawCatalog

/** Turns a section id such as "arms-8" into a short label such as "Arms s.8". */
fun sectionRef(sectionId: String): String {
    val lawId = sectionId.substringBefore('-')
    val number = sectionId.substringAfter('-', "")
    val name = LawCatalog.laws.firstOrNull { it.id == lawId }?.shortName ?: lawId
    return if (number.isEmpty()) name else "$name s.$number"
}
