package com.pakistanlaws.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pakistanlaws.app.R
import com.pakistanlaws.app.content.LawCatalog
import com.pakistanlaws.app.data.db.NoteEntity
import com.pakistanlaws.app.ui.StudyViewModel
import com.pakistanlaws.app.ui.components.NoteEditorDialog
import com.pakistanlaws.app.ui.components.SectionHeader
import com.pakistanlaws.app.ui.sectionRef
import com.pakistanlaws.app.ui.theme.Language

private const val TAB_NOTES = 0
private const val TAB_BOOKMARKS = 1

/** The Study tab: your notes (searchable, grouped by subject) and your bookmarked sections. */
@Composable
fun StudyScreen(
    onOpenSection: (String) -> Unit,
    studyVm: StudyViewModel = viewModel()
) {
    val notes by studyVm.notes.collectAsState()
    val bookmarks by studyVm.bookmarkedSections.collectAsState()
    val urdu = Language.isUrdu(LocalConfiguration.current)
    val general = stringResource(R.string.notes_general)

    var tab by rememberSaveable { mutableIntStateOf(TAB_NOTES) }
    var query by rememberSaveable { mutableStateOf("") }
    var subjectFilter by rememberSaveable { mutableStateOf<String?>(null) }
    var editorOpen by remember { mutableStateOf(false) }
    var editingNote by remember { mutableStateOf<NoteEntity?>(null) }

    val subjects = notes.map { it.subject.ifBlank { general } }.distinct()
    val q = query.trim()
    val visibleNotes = notes.filter { note ->
        (subjectFilter == null || note.subject.ifBlank { general } == subjectFilter) &&
            (q.isEmpty() ||
                note.title.contains(q, ignoreCase = true) ||
                note.body.contains(q, ignoreCase = true) ||
                note.subject.contains(q, ignoreCase = true))
    }
    val grouped = visibleNotes.groupBy { it.subject.ifBlank { general } }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
    ) {
        item {
            Text(
                text = stringResource(R.string.tab_study),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = tab == TAB_NOTES,
                    onClick = { tab = TAB_NOTES },
                    label = { Text(stringResource(R.string.quick_notes)) }
                )
                FilterChip(
                    selected = tab == TAB_BOOKMARKS,
                    onClick = { tab = TAB_BOOKMARKS },
                    label = { Text(stringResource(R.string.quick_bookmarks)) }
                )
            }
            Spacer(Modifier.height(8.dp))
        }

        if (tab == TAB_NOTES) {
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    placeholder = { Text(stringResource(R.string.notes_search_hint)) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth()
                )
                if (subjects.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = subjectFilter == null,
                            onClick = { subjectFilter = null },
                            label = { Text(stringResource(R.string.notes_subject_all)) }
                        )
                        subjects.forEach { subject ->
                            FilterChip(
                                selected = subjectFilter == subject,
                                onClick = { subjectFilter = subject },
                                label = { Text(subject) }
                            )
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Button(onClick = {
                    editingNote = null
                    editorOpen = true
                }) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.notes_new))
                }
            }
            if (notes.isEmpty()) {
                item {
                    Text(
                        text = stringResource(R.string.notes_empty),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
            } else if (visibleNotes.isEmpty()) {
                item {
                    Text(
                        text = stringResource(R.string.notes_none_match),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
            }
            grouped.forEach { (subject, list) ->
                item(key = "subject-$subject") { SectionHeader(subject) }
                items(list, key = { "note-" + it.id }) { note ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(MaterialTheme.shapes.medium)
                            .clickable {
                                editingNote = note
                                editorOpen = true
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        androidx.compose.foundation.layout.Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = note.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = note.body,
                                style = MaterialTheme.typography.bodyMedium,
                                maxLines = 3,
                                overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (note.sectionId != null) {
                                Spacer(Modifier.height(6.dp))
                                AssistChip(
                                    onClick = { onOpenSection(note.sectionId) },
                                    label = { Text(sectionRef(note.sectionId)) }
                                )
                            }
                        }
                    }
                }
            }
        } else {
            if (bookmarks.isEmpty()) {
                item {
                    Text(
                        text = stringResource(R.string.bookmarks_empty),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
            }
            items(bookmarks, key = { "bookmark-" + it.id }) { section ->
                val lawName = LawCatalog.laws.firstOrNull { it.id == section.lawId }?.shortName ?: section.lawId
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(MaterialTheme.shapes.medium)
                        .clickable { onOpenSection(section.id) },
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(start = 14.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        androidx.compose.foundation.layout.Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = section.number + "  " +
                                    if (urdu && section.titleUr.isNotBlank()) section.titleUr else section.titleEn,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = lawName,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { studyVm.removeBookmark(section.id) }) {
                            Icon(
                                imageVector = Icons.Filled.Bookmark,
                                contentDescription = stringResource(R.string.reader_bookmarked),
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }

    if (editorOpen) {
        val subjectChoices = (notes.map { it.subject } + LawCatalog.laws.map { it.shortName })
            .filter { it.isNotBlank() }
            .distinct()
        NoteEditorDialog(
            existing = editingNote,
            defaultSubject = "",
            subjects = subjectChoices,
            onSave = { subject, title, body ->
                studyVm.saveNote(editingNote, null, subject, title, body)
                editorOpen = false
            },
            onDelete = editingNote?.let { note ->
                {
                    studyVm.deleteNote(note.id)
                    editorOpen = false
                }
            },
            onDismiss = { editorOpen = false }
        )
    }
}
