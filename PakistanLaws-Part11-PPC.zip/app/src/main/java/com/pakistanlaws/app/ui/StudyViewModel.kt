package com.pakistanlaws.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pakistanlaws.app.data.db.AppDatabase
import com.pakistanlaws.app.data.db.BookmarkEntity
import com.pakistanlaws.app.data.db.FavouriteEntity
import com.pakistanlaws.app.data.db.HighlightEntity
import com.pakistanlaws.app.data.db.NoteEntity
import com.pakistanlaws.app.data.db.QuestionEntity
import com.pakistanlaws.app.data.db.SectionEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Everything the user saves: notes, bookmarks, favourites and highlights. */
class StudyViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.get(application)

    val notes: StateFlow<List<NoteEntity>> = db.noteDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val bookmarkedSections: StateFlow<List<SectionEntity>> = db.bookmarkDao().observeSections()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val favouriteQuestionIds: StateFlow<Set<String>> = db.favouriteDao().observeIds(KIND_QUESTION)
        .map { it.toSet() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    val favouriteLawIds: StateFlow<Set<String>> = db.favouriteDao().observeIds(KIND_LAW)
        .map { it.toSet() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    val favouriteQuestions: StateFlow<List<QuestionEntity>> = db.favouriteDao().observeQuestions()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val highlights: StateFlow<List<HighlightEntity>> = db.highlightDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun notesFor(sectionId: String): Flow<List<NoteEntity>> = db.noteDao().observeForSection(sectionId)

    fun highlightsFor(sectionId: String): Flow<List<HighlightEntity>> = db.highlightDao().observeFor(sectionId)

    // ---- notes ----

    /** Saves a new note, or updates [existing]. The title falls back to the start of the text. */
    fun saveNote(existing: NoteEntity?, sectionId: String?, subject: String, title: String, body: String) {
        val text = body.trim()
        if (text.isEmpty()) return
        val now = System.currentTimeMillis()
        val note = NoteEntity(
            id = existing?.id ?: 0,
            sectionId = existing?.sectionId ?: sectionId,
            subject = subject.trim(),
            title = title.trim().ifEmpty { text.take(40) },
            body = text,
            createdAt = existing?.createdAt ?: now,
            updatedAt = now
        )
        viewModelScope.launch { db.noteDao().upsert(note) }
    }

    fun deleteNote(id: Long) {
        viewModelScope.launch { db.noteDao().delete(id) }
    }

    // ---- bookmarks ----

    fun removeBookmark(sectionId: String) {
        viewModelScope.launch { db.bookmarkDao().delete(sectionId) }
    }

    fun addBookmark(sectionId: String) {
        viewModelScope.launch {
            db.bookmarkDao().insert(BookmarkEntity(sectionId, System.currentTimeMillis()))
        }
    }

    // ---- favourites ----

    fun toggleFavouriteQuestion(id: String) = toggleFavourite(KIND_QUESTION, id, id in favouriteQuestionIds.value)

    fun toggleFavouriteLaw(id: String) = toggleFavourite(KIND_LAW, id, id in favouriteLawIds.value)

    private fun toggleFavourite(kind: String, id: String, isFavourite: Boolean) {
        val key = "$kind:$id"
        viewModelScope.launch {
            if (isFavourite) {
                db.favouriteDao().delete(key)
            } else {
                db.favouriteDao().insert(FavouriteEntity(key, kind, id, System.currentTimeMillis()))
            }
        }
    }

    // ---- highlights ----

    fun toggleHighlight(sectionId: String, source: String, paragraph: Int, text: String, isOn: Boolean) {
        viewModelScope.launch {
            if (isOn) {
                db.highlightDao().delete(sectionId, source, paragraph)
            } else {
                db.highlightDao().insert(
                    HighlightEntity(sectionId, source, paragraph, text, System.currentTimeMillis())
                )
            }
        }
    }

    fun removeHighlight(item: HighlightEntity) {
        viewModelScope.launch {
            db.highlightDao().delete(item.sectionId, item.source, item.paragraph)
        }
    }

    private companion object {
        const val KIND_QUESTION = "q"
        const val KIND_LAW = "l"
    }
}
