package com.pakistanlaws.app.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.pakistanlaws.app.ui.AppViewModel
import com.pakistanlaws.app.ui.FlashcardViewModel
import com.pakistanlaws.app.ui.QuizMode
import com.pakistanlaws.app.ui.QuizViewModel
import com.pakistanlaws.app.ui.Session
import com.pakistanlaws.app.ui.components.PlaceholderScreen
import com.pakistanlaws.app.ui.components.UserGuideDialog
import com.pakistanlaws.app.ui.screens.HomeScreen
import com.pakistanlaws.app.ui.screens.FlashcardSessionScreen
import com.pakistanlaws.app.ui.screens.FlashcardsScreen
import com.pakistanlaws.app.ui.screens.LawScreen
import com.pakistanlaws.app.ui.screens.LibraryScreen
import com.pakistanlaws.app.ui.screens.PracticeScreen
import com.pakistanlaws.app.ui.screens.QuestionBankScreen
import com.pakistanlaws.app.ui.screens.QuizPlayScreen
import com.pakistanlaws.app.ui.screens.QuizResultScreen
import com.pakistanlaws.app.ui.screens.QuizSetupScreen
import com.pakistanlaws.app.ui.screens.StudyScreen
import com.pakistanlaws.app.ui.screens.ProfileScreen
import com.pakistanlaws.app.ui.screens.ReaderScreen
import com.pakistanlaws.app.ui.screens.SearchScreen

/** Switches the bottom tab, keeping each tab's own state. */
private fun NavController.switchTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) {
            saveState = true
        }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun MainScaffold(
    vm: AppViewModel,
    onLoggedOut: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val tabNav = rememberNavController()
    // One quiz state shared by the setup, play and result screens.
    val quizVm: QuizViewModel = viewModel()
    val flashVm: FlashcardViewModel = viewModel()
    val backStackEntry by tabNav.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val selectedTab = InnerRoutes.tabFor(currentRoute)
    val guideSeen by vm.guideSeen.collectAsState()
    val session by vm.session.collectAsState()
    val userName = (session as? Session.Active)?.name.orEmpty()

    if (!guideSeen) {
        UserGuideDialog(onFinish = { vm.markGuideSeen() })
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                BottomTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { tabNav.switchTab(tab.route) },
                        icon = {
                            Icon(tab.icon, contentDescription = stringResource(tab.label))
                        },
                        label = { Text(stringResource(tab.label)) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = tabNav,
            startDestination = BottomTab.HOME.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(BottomTab.HOME.route) {
                HomeScreen(
                    name = userName,
                    onOpenSearch = { tabNav.navigate(InnerRoutes.SEARCH) },
                    onOpenTab = { target -> tabNav.switchTab(target.route) },
                    onOpenSection = { id -> tabNav.navigate(InnerRoutes.section(id)) },
                    onOpenBank = { tabNav.navigate(InnerRoutes.bank("all")) },
                    onOpenFlashcards = { tabNav.navigate(InnerRoutes.FLASHCARDS) }
                )
            }
            composable(BottomTab.LIBRARY.route) {
                LibraryScreen(onOpenLaw = { id -> tabNav.navigate(InnerRoutes.law(id)) })
            }
            composable(BottomTab.PRACTICE.route) {
                PracticeScreen(
                    vm = quizVm,
                    onOpenSetup = { mode -> tabNav.navigate(InnerRoutes.quizSetup(mode.name)) },
                    onPlay = { tabNav.navigate(InnerRoutes.QUIZ_PLAY) },
                    onOpenBank = { preset -> tabNav.navigate(InnerRoutes.bank(preset)) },
                    onOpenFlashcards = { tabNav.navigate(InnerRoutes.FLASHCARDS) }
                )
            }
            composable(InnerRoutes.FLASHCARDS) {
                FlashcardsScreen(
                    vm = flashVm,
                    onBack = { tabNav.popBackStack() },
                    onStart = { tabNav.navigate(InnerRoutes.FLASH_SESSION) }
                )
            }
            composable(InnerRoutes.FLASH_SESSION) {
                FlashcardSessionScreen(
                    vm = flashVm,
                    onClose = { tabNav.popBackStack() }
                )
            }
            composable(
                route = InnerRoutes.BANK,
                arguments = listOf(navArgument("preset") { type = NavType.StringType })
            ) { entry ->
                QuestionBankScreen(
                    preset = entry.arguments?.getString("preset").orEmpty(),
                    quizVm = quizVm,
                    onBack = { tabNav.popBackStack() },
                    onPlay = { tabNav.navigate(InnerRoutes.QUIZ_PLAY) }
                )
            }
            composable(
                route = InnerRoutes.QUIZ_SETUP,
                arguments = listOf(navArgument("mode") { type = NavType.StringType })
            ) { entry ->
                val mode = runCatching {
                    QuizMode.valueOf(entry.arguments?.getString("mode").orEmpty())
                }.getOrDefault(QuizMode.PRACTICE)
                QuizSetupScreen(
                    mode = mode,
                    vm = quizVm,
                    onBack = { tabNav.popBackStack() },
                    onStart = { tabNav.navigate(InnerRoutes.QUIZ_PLAY) }
                )
            }
            composable(InnerRoutes.QUIZ_PLAY) {
                QuizPlayScreen(
                    vm = quizVm,
                    onFinished = {
                        tabNav.navigate(InnerRoutes.QUIZ_RESULT) {
                            popUpTo(BottomTab.PRACTICE.route)
                        }
                    },
                    onClose = { tabNav.popBackStack() }
                )
            }
            composable(InnerRoutes.QUIZ_RESULT) {
                QuizResultScreen(
                    vm = quizVm,
                    onRetry = {
                        quizVm.retry()
                        tabNav.navigate(InnerRoutes.QUIZ_PLAY) {
                            popUpTo(BottomTab.PRACTICE.route)
                        }
                    },
                    onBack = { tabNav.popBackStack(BottomTab.PRACTICE.route, false) }
                )
            }
            composable(BottomTab.STUDY.route) {
                StudyScreen(
                    onOpenSection = { id -> tabNav.navigate(InnerRoutes.section(id)) }
                )
            }
            composable(BottomTab.PROFILE.route) {
                ProfileScreen(
                    vm = vm,
                    onLoggedOut = onLoggedOut,
                    onOpenSettings = onOpenSettings
                )
            }
            composable(InnerRoutes.SEARCH) {
                SearchScreen(
                    onBack = { tabNav.popBackStack() },
                    onOpenLaw = { id -> tabNav.navigate(InnerRoutes.law(id)) },
                    onOpenSection = { id -> tabNav.navigate(InnerRoutes.section(id)) }
                )
            }
            composable(
                route = InnerRoutes.LAW,
                arguments = listOf(navArgument("lawId") { type = NavType.StringType })
            ) { entry ->
                LawScreen(
                    lawId = entry.arguments?.getString("lawId").orEmpty(),
                    onBack = { tabNav.popBackStack() },
                    onOpenSection = { id -> tabNav.navigate(InnerRoutes.section(id)) }
                )
            }
            composable(
                route = InnerRoutes.SECTION,
                arguments = listOf(navArgument("sectionId") { type = NavType.StringType })
            ) { entry ->
                ReaderScreen(
                    sectionId = entry.arguments?.getString("sectionId").orEmpty(),
                    onBack = { tabNav.popBackStack() }
                )
            }
        }
    }
}
