package com.pakistanlaws.app.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** One law, for example the Pakistan Penal Code. */
@Entity(tableName = "laws")
data class LawEntity(
    @PrimaryKey val id: String,
    val titleEn: String,
    val titleUr: String,
    val shortName: String,
    val sortOrder: Int
)

/** One section, article or rule of a law, with its short and long explanations. */
@Entity(tableName = "sections", indices = [Index("lawId")])
data class SectionEntity(
    @PrimaryKey val id: String,
    val lawId: String,
    val number: String,
    val chapter: String,
    val titleEn: String,
    val titleUr: String,
    val shortEn: String,
    val shortUr: String,
    val longEn: String,
    val longUr: String,
    val originalText: String,
    val sortOrder: Int,
    val isImportant: Boolean,
    /** True when the text must still be checked against the official Gazette. */
    val needsVerify: Boolean
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey val sectionId: String,
    val createdAt: Long
)

@Entity(tableName = "notes", indices = [Index("sectionId")])
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sectionId: String?,
    val subject: String,
    val title: String,
    val body: String,
    val createdAt: Long,
    val updatedAt: Long
)
