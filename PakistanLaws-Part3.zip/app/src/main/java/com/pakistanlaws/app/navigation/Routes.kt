package com.pakistanlaws.app.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.ui.graphics.vector.ImageVector
import com.pakistanlaws.app.R
import com.pakistanlaws.app.ui.Session

object Routes {
    const val SPLASH = "splash"
    const val WELCOME = "welcome"
    const val ONBOARDING = "onboarding"
    const val AUTH = "auth"
    const val LOGIN = "login"
    const val SIGNUP = "signup"
    const val GUEST = "guest"
    const val PENDING = "pending"
    const val MAIN = "main"
    const val SETTINGS = "settings"
}

/** Which screen a given session state belongs on. */
fun routeFor(session: Session): String = when (session) {
    Session.Loading -> Routes.SPLASH
    Session.NeedsOnboarding -> Routes.WELCOME
    Session.NeedsAuth -> Routes.AUTH
    is Session.Pending -> Routes.PENDING
    is Session.Rejected -> Routes.PENDING
    is Session.Active -> Routes.MAIN
}

/** The five bottom-navigation tabs. */
enum class BottomTab(
    val route: String,
    @StringRes val label: Int,
    val icon: ImageVector
) {
    HOME("home", R.string.tab_home, Icons.Filled.Home),
    LIBRARY("library", R.string.tab_library, Icons.AutoMirrored.Filled.MenuBook),
    PRACTICE("practice", R.string.tab_practice, Icons.Filled.Quiz),
    STUDY("study", R.string.tab_study, Icons.Filled.Bookmarks),
    PROFILE("profile", R.string.tab_profile, Icons.Filled.Person)
}
