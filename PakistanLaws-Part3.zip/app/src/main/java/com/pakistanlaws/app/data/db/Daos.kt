package com.pakistanlaws.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LawDao {
    @Query("SELECT * FROM laws ORDER BY sortOrder")
    fun observeAll(): Flow<List<LawEntity>>

    @Query("SELECT COUNT(*) FROM laws")
    fun observeCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<LawEntity>)
}

@Dao
interface SectionDao {
    @Query("SELECT * FROM sections WHERE lawId = :lawId ORDER BY sortOrder")
    fun observeByLaw(lawId: String): Flow<List<SectionEntity>>

    @Query("SELECT * FROM sections WHERE id = :id")
    suspend fun getById(id: String): SectionEntity?

    @Query(
        "SELECT * FROM sections WHERE titleEn LIKE '%' || :query || '%' " +
            "OR titleUr LIKE '%' || :query || '%' " +
            "OR number LIKE :query || '%' ORDER BY sortOrder LIMIT 100"
    )
    fun search(query: String): Flow<List<SectionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<SectionEntity>)

    @Query("SELECT COUNT(*) FROM sections")
    suspend fun count(): Int
}

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<BookmarkEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(bookmark: BookmarkEntity)

    @Query("DELETE FROM bookmarks WHERE sectionId = :sectionId")
    suspend fun delete(sectionId: String)
}

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<NoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(note: NoteEntity): Long

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun delete(id: Long)
}
