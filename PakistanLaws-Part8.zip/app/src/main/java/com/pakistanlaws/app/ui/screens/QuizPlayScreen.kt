package com.pakistanlaws.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pakistanlaws.app.R
import com.pakistanlaws.app.ui.QuizViewModel
import com.pakistanlaws.app.ui.explanation
import com.pakistanlaws.app.ui.options
import com.pakistanlaws.app.ui.text
import com.pakistanlaws.app.ui.theme.Language

private fun clock(seconds: Int): String {
    val m = seconds / 60
    val s = seconds % 60
    return m.toString() + ":" + s.toString().padStart(2, '0')
}

/** The screen where the questions are answered. */
@Composable
fun QuizPlayScreen(
    vm: QuizViewModel,
    onFinished: () -> Unit,
    onClose: () -> Unit
) {
    val state by vm.state.collectAsState()
    val s = state
    val appUrdu = Language.isUrdu(LocalConfiguration.current)
    var urdu by rememberSaveable { mutableStateOf(appUrdu) }
    var showQuit by rememberSaveable { mutableStateOf(false) }

    BackHandler { showQuit = true }
    LaunchedEffect(s?.outcome != null) {
        if (s?.outcome != null) onFinished()
    }
    LaunchedEffect(s == null) {
        if (s == null) onClose()
    }

    if (s == null) {
        Box(modifier = Modifier.fillMaxSize())
        return
    }
    if (s.loading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }
    if (s.questions.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = stringResource(R.string.play_no_questions),
                style = MaterialTheme.typography.bodyLarge
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = { vm.quit() }) { Text(stringResource(R.string.action_back)) }
        }
        return
    }

    val mode = s.config.mode
    val question = s.questions[s.index.coerceIn(0, s.questions.lastIndex)]
    val chosen = s.answers[s.index]
    val showFeedback = mode.instantFeedback && s.locked
    val isLast = s.index >= s.questions.lastIndex
    val optionTexts = question.options(urdu)
    val timed = mode.secondsPerQuestionTotal > 0 || mode.secondsPerQuestion > 0

    Column(modifier = Modifier.fillMaxSize()) {
        // Top: close, progress, timer, lives, language
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { showQuit = true }) {
                Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.action_back))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.play_question_format, s.index + 1, s.questions.size),
                    style = MaterialTheme.typography.labelLarge
                )
                LinearProgressIndicator(
                    progress = { (s.index + 1f) / s.questions.size },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                )
            }
            if (timed) {
                Spacer(Modifier.width(8.dp))
                Icon(
                    imageVector = Icons.Filled.Timer,
                    contentDescription = null,
                    tint = if (s.secondsLeft <= 10) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = clock(s.secondsLeft),
                    style = MaterialTheme.typography.labelLarge,
                    color = if (s.secondsLeft <= 10) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp)
                )
            }
            if (mode.lives > 0) {
                Spacer(Modifier.width(8.dp))
                Icon(
                    imageVector = Icons.Filled.Favorite,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = s.lives.toString(),
                    style = MaterialTheme.typography.labelLarge,
                    modifier = Modifier.padding(start = 4.dp)
                )
            }
            TextButton(onClick = { urdu = !urdu }) {
                Text(if (urdu) "English" else "اردو")
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text(
                text = question.text(urdu),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(16.dp))

            optionTexts.forEachIndexed { i, label ->
                val isCorrect = i == question.correctIndex
                val isChosen = chosen == i
                val container = when {
                    showFeedback && isCorrect -> MaterialTheme.colorScheme.primaryContainer
                    showFeedback && isChosen -> MaterialTheme.colorScheme.errorContainer
                    !mode.instantFeedback && isChosen -> MaterialTheme.colorScheme.secondaryContainer
                    else -> MaterialTheme.colorScheme.surfaceVariant
                }
                val borderColor = when {
                    showFeedback && isCorrect -> MaterialTheme.colorScheme.primary
                    showFeedback && isChosen -> MaterialTheme.colorScheme.error
                    !mode.instantFeedback && isChosen -> MaterialTheme.colorScheme.secondary
                    else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                }
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp)
                        .clip(MaterialTheme.shapes.medium)
                        .clickable(enabled = !(mode.instantFeedback && s.locked)) { vm.select(i) },
                    colors = CardDefaults.cardColors(containerColor = container),
                    border = BorderStroke(
                        if (isChosen || (showFeedback && isCorrect)) 2.dp else 1.dp,
                        borderColor
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = (i + 1).toString(),
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.width(28.dp)
                        )
                        Text(
                            text = label,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            if (showFeedback) {
                Spacer(Modifier.height(12.dp))
                val right = chosen == question.correctIndex
                Text(
                    text = stringResource(if (right) R.string.daily_correct else R.string.daily_wrong),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (right) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                )
                if (!right) {
                    Text(
                        text = stringResource(
                            R.string.play_correct_answer_format,
                            optionTexts[question.correctIndex]
                        ),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = question.explanation(urdu),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = question.ref,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            Spacer(Modifier.height(16.dp))
        }

        // Bottom buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (!mode.instantFeedback) {
                OutlinedButton(
                    onClick = { vm.previous() },
                    enabled = s.index > 0,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(stringResource(R.string.play_previous))
                }
            }
            if (!(mode.secondsPerQuestion > 0)) {
                val outOfLives = mode.lives > 0 && s.lives <= 0
                Button(
                    onClick = { if (isLast || outOfLives) vm.finish() else vm.next() },
                    enabled = !mode.instantFeedback || s.locked,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        stringResource(
                            if (isLast || (outOfLives && s.locked)) R.string.play_finish else R.string.action_next
                        )
                    )
                }
            }
        }
    }

    if (showQuit) {
        AlertDialog(
            onDismissRequest = { showQuit = false },
            title = { Text(stringResource(R.string.play_quit_title)) },
            text = { Text(stringResource(R.string.play_quit_body)) },
            confirmButton = {
                TextButton(onClick = {
                    showQuit = false
                    vm.quit()
                }) {
                    Text(stringResource(R.string.play_quit_yes))
                }
            },
            dismissButton = {
                TextButton(onClick = { showQuit = false }) {
                    Text(stringResource(R.string.play_quit_no))
                }
            }
        )
    }
}
