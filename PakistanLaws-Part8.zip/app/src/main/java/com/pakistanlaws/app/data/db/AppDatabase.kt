package com.pakistanlaws.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        LawEntity::class,
        SectionEntity::class,
        BookmarkEntity::class,
        NoteEntity::class,
        QuestionEntity::class,
        QuizResultEntity::class,
        AnswerRecordEntity::class,
        CustomCardEntity::class,
        CardProgressEntity::class
    ],
    version = 5,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun lawDao(): LawDao
    abstract fun sectionDao(): SectionDao
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun noteDao(): NoteDao
    abstract fun questionDao(): QuestionDao
    abstract fun quizResultDao(): QuizResultDao
    abstract fun answerRecordDao(): AnswerRecordDao
    abstract fun flashcardDao(): FlashcardDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "pakistan_laws.db"
                )
                    // During development a schema change rebuilds the database.
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { instance = it }
            }
    }
}
