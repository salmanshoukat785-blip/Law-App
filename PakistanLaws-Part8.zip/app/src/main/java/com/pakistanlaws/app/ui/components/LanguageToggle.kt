package com.pakistanlaws.app.ui.components

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import com.pakistanlaws.app.ui.theme.Language

/** A small button that switches the app between English and Urdu. */
@Composable
fun LanguageToggle(modifier: Modifier = Modifier) {
    val urdu = Language.isUrdu(LocalConfiguration.current)
    TextButton(
        onClick = { Language.set(if (urdu) "en" else "ur") },
        modifier = modifier
    ) {
        Icon(
            imageVector = Icons.Filled.Language,
            contentDescription = null,
            modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(6.dp))
        Text(if (urdu) "English" else "اردو")
    }
}
