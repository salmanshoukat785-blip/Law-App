package com.pakistanlaws.app.ui.theme

import android.content.res.Configuration
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

/** In-app language switching. The choice is remembered by AppCompat. */
object Language {
    fun isUrdu(config: Configuration): Boolean = config.locales[0].language == "ur"

    fun set(code: String) {
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(code))
    }
}
