package com.pakistanlaws.app.ui.theme

import android.content.Context
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily

/**
 * Looks for the Noto Nastaliq Urdu font at res/font/noto_nastaliq_urdu.ttf.
 * If the file has not been added, Urdu text uses the phone's own Urdu font.
 */
object UrduFont {
    fun family(context: Context): FontFamily {
        val id = context.resources.getIdentifier("noto_nastaliq_urdu", "font", context.packageName)
        return if (id != 0) FontFamily(Font(id)) else FontFamily.Default
    }
}
