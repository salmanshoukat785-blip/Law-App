package com.pakistanlaws.app.data

import android.content.Context
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate

private val Context.homeDataStore by preferencesDataStore(name = "pakistan_laws_home")

private val K_RECENT = stringPreferencesKey("recent")
private val K_DQ_DATE = stringPreferencesKey("dq_date")
private val K_DQ_CHOICE = intPreferencesKey("dq_choice")
private val K_GOAL_Q = intPreferencesKey("goal_questions")
private val K_GOAL_MIN = intPreferencesKey("goal_minutes")
private val K_PROG_DATE = stringPreferencesKey("prog_date")
private val K_PROG_Q = intPreferencesKey("prog_questions")
private val K_PROG_MIN = intPreferencesKey("prog_minutes")
private val K_STREAK = intPreferencesKey("streak")
private val K_LAST_ACTIVE = stringPreferencesKey("last_active")

private const val MAX_RECENT = 10

/** Everything the Home dashboard shows, already adjusted for "today". */
data class HomeData(
    val recentIds: List<String> = emptyList(),
    val dailyChoice: Int? = null,
    val goalQuestions: Int = 10,
    val goalMinutes: Int = 15,
    val todayQuestions: Int = 0,
    val todayMinutes: Int = 0,
    val streak: Int = 0
)

/**
 * Small values that belong to the dashboard: recently viewed topics, today's daily question
 * answer, daily goals, today's progress and the learning streak. Later parts (reader, quiz)
 * call [addRecent], [recordQuestions] and [addMinutes] to feed it.
 */
class HomeStore(context: Context) {
    private val store = context.applicationContext.homeDataStore

    fun flow(today: String): Flow<HomeData> = store.data.map { p ->
        val yesterday = LocalDate.parse(today).minusDays(1).toString()
        val last = p[K_LAST_ACTIVE]
        val sameDay = p[K_PROG_DATE] == today
        HomeData(
            recentIds = (p[K_RECENT] ?: "").split("|").filter { it.isNotBlank() },
            dailyChoice = if (p[K_DQ_DATE] == today) p[K_DQ_CHOICE] else null,
            goalQuestions = p[K_GOAL_Q] ?: 10,
            goalMinutes = p[K_GOAL_MIN] ?: 15,
            todayQuestions = if (sameDay) p[K_PROG_Q] ?: 0 else 0,
            todayMinutes = if (sameDay) p[K_PROG_MIN] ?: 0 else 0,
            streak = if (last == today || last == yesterday) p[K_STREAK] ?: 0 else 0
        )
    }

    /** Starts a new day's counters if needed and keeps the streak up to date. */
    private fun MutablePreferences.rollToday(today: String) {
        if (this[K_PROG_DATE] != today) {
            this[K_PROG_DATE] = today
            this[K_PROG_Q] = 0
            this[K_PROG_MIN] = 0
        }
        val last = this[K_LAST_ACTIVE]
        if (last != today) {
            val yesterday = LocalDate.parse(today).minusDays(1).toString()
            this[K_STREAK] = if (last == yesterday) (this[K_STREAK] ?: 0) + 1 else 1
            this[K_LAST_ACTIVE] = today
        }
    }

    suspend fun addRecent(sectionId: String) {
        store.edit { p ->
            val current = (p[K_RECENT] ?: "").split("|").filter { it.isNotBlank() && it != sectionId }
            p[K_RECENT] = (listOf(sectionId) + current).take(MAX_RECENT).joinToString("|")
        }
    }

    suspend fun answerDaily(today: String, choice: Int) {
        store.edit { p ->
            if (p[K_DQ_DATE] == today) return@edit
            p[K_DQ_DATE] = today
            p[K_DQ_CHOICE] = choice
            p.rollToday(today)
            p[K_PROG_Q] = (p[K_PROG_Q] ?: 0) + 1
        }
    }

    suspend fun recordQuestions(today: String, count: Int) {
        store.edit { p ->
            p.rollToday(today)
            p[K_PROG_Q] = (p[K_PROG_Q] ?: 0) + count
        }
    }

    suspend fun addMinutes(today: String, minutes: Int) {
        store.edit { p ->
            p.rollToday(today)
            p[K_PROG_MIN] = (p[K_PROG_MIN] ?: 0) + minutes
        }
    }

    suspend fun setGoals(questions: Int, minutes: Int) {
        store.edit { p ->
            p[K_GOAL_Q] = questions
            p[K_GOAL_MIN] = minutes
        }
    }
}
