package com.pakistanlaws.app.ui.theme

import androidx.compose.runtime.compositionLocalOf

/** False when the user turned animations off (or Accessibility mode is on). */
val LocalAnimations = compositionLocalOf { true }
