package com.pakistanlaws.app.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.pakistanlaws.app.R
import com.pakistanlaws.app.ui.AppViewModel
import com.pakistanlaws.app.ui.Session
import com.pakistanlaws.app.ui.components.LogoMark
import com.pakistanlaws.app.ui.theme.Brand
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(vm: AppViewModel, onReady: (Session) -> Unit) {
    val session by vm.session.collectAsState()
    var minTimeDone by remember { mutableStateOf(false) }
    var showText by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        delay(600)
        showText = true
        delay(1600)
        minTimeDone = true
    }
    LaunchedEffect(session, minTimeDone) {
        if (minTimeDone && session != Session.Loading) onReady(session)
    }

    val textAlpha by animateFloatAsState(
        targetValue = if (showText) 1f else 0f,
        animationSpec = tween(800),
        label = "splashText"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Brand.Green, Brand.DeepGreen))),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            LogoMark(logoSize = 150.dp)
            Spacer(Modifier.height(24.dp))
            Column(
                modifier = Modifier.alpha(textAlpha),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = stringResource(R.string.app_name),
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = androidx.compose.ui.graphics.Color.White
                )
                Text(
                    text = stringResource(R.string.splash_tagline),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Brand.Mist,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 48.dp, vertical = 8.dp)
                )
            }
        }
    }
}
