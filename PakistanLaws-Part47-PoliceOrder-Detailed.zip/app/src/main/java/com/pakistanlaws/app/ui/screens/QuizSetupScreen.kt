package com.pakistanlaws.app.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pakistanlaws.app.R
import com.pakistanlaws.app.content.LawCatalog
import com.pakistanlaws.app.ui.QuizConfig
import com.pakistanlaws.app.ui.QuizMode
import com.pakistanlaws.app.ui.QuizViewModel
import com.pakistanlaws.app.ui.components.PrimaryButton
import com.pakistanlaws.app.ui.theme.Language

/** Chooses the law, topic (chapter), level and number of questions for a quiz. */
@Composable
fun QuizSetupScreen(
    mode: QuizMode,
    vm: QuizViewModel,
    onBack: () -> Unit,
    onStart: () -> Unit
) {
    val bank by vm.bank.collectAsState()
    val urdu = Language.isUrdu(LocalConfiguration.current)

    var lawId by rememberSaveable { mutableStateOf<String?>(null) }
    var topic by rememberSaveable { mutableStateOf<String?>(null) }
    var difficulty by rememberSaveable { mutableStateOf<Int?>(null) }
    var count by rememberSaveable { mutableIntStateOf(10) }

    val laws = LawCatalog.laws.filter { law -> bank.any { it.lawId == law.id } }
    val topics = bank
        .filter { lawId != null && it.lawId == lawId }
        .map { it.topicEn to it.topicUr }
        .distinct()
    val matching = bank.count { q ->
        (lawId == null || q.lawId == lawId) &&
            (topic == null || q.topicEn == topic) &&
            (difficulty == null || q.difficulty == difficulty)
    }
    val effectiveCount = minOf(count, matching)

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(R.string.action_back)
                )
            }
            Text(
                text = stringResource(mode.titleRes),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            Text(
                text = stringResource(mode.descRes),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (mode.negativeMarking > 0.0 || mode.secondsPerQuestionTotal > 0) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = stringResource(R.string.setup_exam_info, effectiveCount),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Label(R.string.setup_law)
            ChipRow {
                FilterChip(
                    selected = lawId == null,
                    onClick = {
                        lawId = null
                        topic = null
                    },
                    label = { Text(stringResource(R.string.setup_all_laws)) }
                )
                laws.forEach { law ->
                    FilterChip(
                        selected = lawId == law.id,
                        onClick = {
                            lawId = law.id
                            topic = null
                        },
                        label = { Text(law.shortName) }
                    )
                }
            }

            if (topics.isNotEmpty()) {
                Label(R.string.setup_topic)
                ChipRow {
                    FilterChip(
                        selected = topic == null,
                        onClick = { topic = null },
                        label = { Text(stringResource(R.string.setup_all_topics)) }
                    )
                    topics.forEach { (en, ur) ->
                        FilterChip(
                            selected = topic == en,
                            onClick = { topic = en },
                            label = { Text(if (urdu && ur.isNotBlank()) ur else en) }
                        )
                    }
                }
            }

            Label(R.string.setup_level)
            ChipRow {
                FilterChip(
                    selected = difficulty == null,
                    onClick = { difficulty = null },
                    label = { Text(stringResource(R.string.level_mixed)) }
                )
                FilterChip(
                    selected = difficulty == 1,
                    onClick = { difficulty = 1 },
                    label = { Text(stringResource(R.string.level_easy)) }
                )
                FilterChip(
                    selected = difficulty == 2,
                    onClick = { difficulty = 2 },
                    label = { Text(stringResource(R.string.level_medium)) }
                )
                FilterChip(
                    selected = difficulty == 3,
                    onClick = { difficulty = 3 },
                    label = { Text(stringResource(R.string.level_hard)) }
                )
            }

            Label(R.string.setup_count)
            ChipRow {
                listOf(5, 10, 20).forEach { option ->
                    FilterChip(
                        selected = count == option,
                        onClick = { count = option },
                        label = { Text("$option") }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                text = if (matching > 0) stringResource(R.string.setup_available_format, matching)
                else stringResource(R.string.setup_none),
                style = MaterialTheme.typography.bodyMedium,
                color = if (matching > 0) MaterialTheme.colorScheme.onSurfaceVariant
                else MaterialTheme.colorScheme.error
            )
            Spacer(Modifier.height(16.dp))
        }

        PrimaryButton(
            text = stringResource(R.string.quiz_start),
            onClick = {
                vm.start(
                    QuizConfig(
                        mode = mode,
                        lawId = lawId,
                        topic = topic,
                        difficulty = difficulty,
                        count = effectiveCount
                    )
                )
                onStart()
            },
            enabled = matching > 0,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
        )
    }
}

@Composable
private fun Label(textRes: Int) {
    Text(
        text = stringResource(textRes),
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 20.dp, bottom = 8.dp)
    )
}

@Composable
private fun ChipRow(content: @Composable () -> Unit) {
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        content()
    }
}
