package com.pakistanlaws.app.ui.theme

import android.content.res.Configuration
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

/**
 * The app is English by default. When the Urdu switch in Settings is on, the app language is set
 * to Urdu, so every screen picks up the Urdu strings and right-to-left layout.
 */
object Language {
    fun isUrdu(config: Configuration): Boolean =
        config.locales.size() > 0 && config.locales[0].language == "ur"

    /** Switches the whole app between Urdu and English (the activity restarts to apply it). */
    fun setUrdu(on: Boolean) {
        val tag = if (on) "ur" else "en"
        val saved = AppCompatDelegate.getApplicationLocales().toLanguageTags()
        if (saved != tag) {
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
        }
    }
}
