package com.pakistanlaws.app.ui.components

import androidx.annotation.StringRes
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.res.stringResource
import com.pakistanlaws.app.R
import com.pakistanlaws.app.navigation.BottomTab

private data class GuideStep(val tab: BottomTab, @StringRes val body: Int)

/** First-time user guide: a short tour of the five tabs, shown once after the first sign-in. */
@Composable
fun UserGuideDialog(onFinish: () -> Unit) {
    val steps = remember {
        listOf(
            GuideStep(BottomTab.HOME, R.string.guide_home),
            GuideStep(BottomTab.LIBRARY, R.string.guide_library),
            GuideStep(BottomTab.PRACTICE, R.string.guide_practice),
            GuideStep(BottomTab.STUDY, R.string.guide_study),
            GuideStep(BottomTab.PROFILE, R.string.guide_profile)
        )
    }
    var index by remember { mutableIntStateOf(0) }
    val step = steps[index]
    val isLast = index == steps.lastIndex

    AlertDialog(
        onDismissRequest = {},
        title = {
            Text(stringResource(R.string.guide_title) + ": " + stringResource(step.tab.label))
        },
        text = {
            Text(
                stringResource(R.string.guide_step_format, index + 1, steps.size) +
                    "\n\n" + stringResource(step.body)
            )
        },
        confirmButton = {
            TextButton(onClick = { if (isLast) onFinish() else index += 1 }) {
                Text(stringResource(if (isLast) R.string.action_done else R.string.action_next))
            }
        },
        dismissButton = {
            if (!isLast) {
                TextButton(onClick = onFinish) {
                    Text(stringResource(R.string.action_skip))
                }
            }
        }
    )
}
