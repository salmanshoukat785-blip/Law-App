package com.pakistanlaws.app.content

/**
 * Daily question and daily knowledge cards. Every item is based on law text that was checked
 * against the uploaded Gazette copies. For education only, not legal advice.
 */
data class DailyQuestion(
    val ref: String,
    val questionEn: String,
    val questionUr: String,
    val optionsEn: List<String>,
    val optionsUr: List<String>,
    val correct: Int,
    val explanationEn: String,
    val explanationUr: String
) {
    fun question(urdu: Boolean) = if (urdu) questionUr else questionEn
    fun options(urdu: Boolean) = if (urdu) optionsUr else optionsEn
    fun explanation(urdu: Boolean) = if (urdu) explanationUr else explanationEn
}

data class KnowledgeCard(
    val ref: String,
    val titleEn: String,
    val titleUr: String,
    val bodyEn: String,
    val bodyUr: String
) {
    fun title(urdu: Boolean) = if (urdu) titleUr else titleEn
    fun body(urdu: Boolean) = if (urdu) bodyUr else bodyEn
}

object DailyContent {

    fun questionFor(epochDay: Long): DailyQuestion =
        questions[Math.floorMod(epochDay, questions.size.toLong()).toInt()]

    fun knowledgeFor(epochDay: Long, offset: Int): KnowledgeCard =
        knowledge[Math.floorMod(epochDay + offset, knowledge.size.toLong()).toInt()]

    val questions = listOf(
        DailyQuestion(
            ref = "PPC s.82",
            questionEn = "Under section 82 of the Pakistan Penal Code, nothing is an offence if it is done by a child under what age?",
            questionUr = "تعزیراتِ پاکستان کی دفعہ 82 کے مطابق کس عمر سے کم بچے کا فعل جرم نہیں؟",
            optionsEn = listOf("5 years", "7 years", "10 years", "12 years"),
            optionsUr = listOf("5 سال", "7 سال", "10 سال", "12 سال"),
            correct = 2,
            explanationEn = "Section 82 PPC: nothing is an offence which is done by a child under ten years of age.",
            explanationUr = "دفعہ 82: دس سال سے کم عمر بچے کا کیا ہوا کوئی فعل جرم نہیں ہوتا۔"
        ),
        DailyQuestion(
            ref = "CrPC s.154",
            questionEn = "Which section of the Code of Criminal Procedure deals with the First Information Report (FIR)?",
            questionUr = "ضابطہ فوجداری کی کون سی دفعہ ابتدائی اطلاعی رپورٹ (ایف آئی آر) سے متعلق ہے؟",
            optionsEn = listOf("Section 154", "Section 164", "Section 173", "Section 497"),
            optionsUr = listOf("دفعہ 154", "دفعہ 164", "دفعہ 173", "دفعہ 497"),
            correct = 0,
            explanationEn = "Section 154 CrPC covers information about a cognizable offence given to the officer in charge of a police station.",
            explanationUr = "دفعہ 154 قابلِ دست اندازی جرم کی اس اطلاع سے متعلق ہے جو تھانے کے انچارج کو دی جائے۔"
        ),
        DailyQuestion(
            ref = "QSO Art. 38",
            questionEn = "Under Article 38 of the Qanun-e-Shahadat Order, a confession made to a police officer:",
            questionUr = "قانونِ شہادت کے آرٹیکل 38 کے مطابق پولیس افسر کے سامنے کیا گیا اقبالِ جرم:",
            optionsEn = listOf(
                "can be proved against the accused",
                "cannot be proved against the accused",
                "is always conclusive proof",
                "is admissible only before a DSP"
            ),
            optionsUr = listOf(
                "ملزم کے خلاف ثابت کیا جا سکتا ہے",
                "ملزم کے خلاف ثابت نہیں کیا جا سکتا",
                "ہمیشہ حتمی ثبوت ہوتا ہے",
                "صرف ڈی ایس پی کے سامنے ہو تو قابلِ قبول ہے"
            ),
            correct = 1,
            explanationEn = "Article 38: no confession made to a police officer shall be proved against a person accused of any offence.",
            explanationUr = "آرٹیکل 38: پولیس افسر کے سامنے کیا گیا کوئی اقبالِ جرم کسی ملزم کے خلاف ثابت نہیں کیا جائے گا۔"
        ),
        DailyQuestion(
            ref = "Arms Ordinance s.8",
            questionEn = "Which section of the Punjab Arms Ordinance, 1965 prohibits going armed without a licence?",
            questionUr = "پنجاب اسلحہ آرڈیننس، 1965 کی کون سی دفعہ لائسنس کے بغیر اسلحہ لے کر چلنے سے منع کرتی ہے؟",
            optionsEn = listOf("Section 4", "Section 8", "Section 13", "Section 20"),
            optionsUr = listOf("دفعہ 4", "دفعہ 8", "دفعہ 13", "دفعہ 20"),
            correct = 1,
            explanationEn = "Section 8: no person shall go armed with any arms except under a licence and to the extent and in the manner it permits.",
            explanationUr = "دفعہ 8: کوئی شخص لائسنس کے بغیر، اور اس کی اجازت کی حد اور طریقے کے علاوہ، اسلحہ لے کر نہیں چل سکتا۔"
        ),
        DailyQuestion(
            ref = "Animals Act s.9",
            questionEn = "Within what time must a prosecution under the Prevention of Cruelty to Animals Act, 1890 be started?",
            questionUr = "انسدادِ ظلم بر حیوانات ایکٹ، 1890 کے تحت مقدمہ کتنی مدت کے اندر شروع کرنا لازم ہے؟",
            optionsEn = listOf("1 month", "3 months", "6 months", "1 year"),
            optionsUr = listOf("1 مہینہ", "3 مہینے", "6 مہینے", "1 سال"),
            correct = 1,
            explanationEn = "Section 9: a prosecution shall not be instituted after three months from the date of the offence.",
            explanationUr = "دفعہ 9: جرم کی تاریخ سے تین مہینے گزرنے کے بعد مقدمہ دائر نہیں کیا جا سکتا۔"
        ),
        DailyQuestion(
            ref = "CNSA s.21",
            questionEn = "Under section 21 of the Control of Narcotic Substances Act, 1997, an officer may enter and search without a warrant if his rank is not below:",
            questionUr = "کنٹرول آف نارکوٹک سبسٹینسز ایکٹ، 1997 کی دفعہ 21 کے تحت وارنٹ کے بغیر داخل ہو کر تلاشی لینے والے افسر کا عہدہ کم از کم کیا ہونا چاہیے؟",
            optionsEn = listOf("Constable", "Assistant Sub-Inspector", "Sub-Inspector", "Superintendent"),
            optionsUr = listOf("کانسٹیبل", "اسسٹنٹ سب انسپکٹر", "سب انسپکٹر", "سپرنٹنڈنٹ"),
            correct = 2,
            explanationEn = "Section 21: an officer not below the rank of Sub-Inspector of Police, or equivalent, authorized by the Federal or a Provincial Government.",
            explanationUr = "دفعہ 21: ایسا افسر جو سب انسپکٹر پولیس یا اس کے برابر عہدے سے کم نہ ہو اور جسے وفاقی یا صوبائی حکومت نے اختیار دیا ہو۔"
        ),
        DailyQuestion(
            ref = "CNSA s.25",
            questionEn = "Which section of the Code of Criminal Procedure does NOT apply to searches and arrests under the CNSA, 1997?",
            questionUr = "سی این ایس اے، 1997 کے تحت تلاشی اور گرفتاری پر ضابطہ فوجداری کی کون سی دفعہ لاگو نہیں ہوتی؟",
            optionsEn = listOf("Section 103", "Section 154", "Section 161", "Section 164"),
            optionsUr = listOf("دفعہ 103", "دفعہ 154", "دفعہ 161", "دفعہ 164"),
            correct = 0,
            explanationEn = "Section 25 CNSA applies the Code to searches and arrests except section 103 (search in the presence of witnesses).",
            explanationUr = "سی این ایس اے کی دفعہ 25 تلاشی اور گرفتاری پر ضابطہ فوجداری لاگو کرتی ہے، سوائے دفعہ 103 (گواہوں کی موجودگی میں تلاشی) کے۔"
        ),
        DailyQuestion(
            ref = "QSO Art. 39",
            questionEn = "A confession made while in police custody can be proved only if it is made in the immediate presence of:",
            questionUr = "پولیس کی حراست میں کیا گیا اقبالِ جرم صرف اسی صورت میں ثابت کیا جا سکتا ہے جب وہ کس کی فوری موجودگی میں کیا گیا ہو؟",
            optionsEn = listOf("a Police Inspector", "a Magistrate", "a Lambardar", "a Jail Superintendent"),
            optionsUr = listOf("پولیس انسپکٹر", "مجسٹریٹ", "نمبردار", "جیل سپرنٹنڈنٹ"),
            correct = 1,
            explanationEn = "Article 39: a confession made in police custody cannot be proved against the person unless it was made in the immediate presence of a Magistrate.",
            explanationUr = "آرٹیکل 39: پولیس کی حراست میں کیا گیا اقبالِ جرم اس شخص کے خلاف تب تک ثابت نہیں ہو سکتا جب تک وہ مجسٹریٹ کی فوری موجودگی میں نہ کیا گیا ہو۔"
        ),
        DailyQuestion(
            ref = "CrPC s.164",
            questionEn = "Who may record a statement or confession under section 164 of the Code of Criminal Procedure?",
            questionUr = "ضابطہ فوجداری کی دفعہ 164 کے تحت بیان یا اقبالِ جرم کون ریکارڈ کر سکتا ہے؟",
            optionsEn = listOf("A Magistrate", "A Station House Officer", "A Public Prosecutor", "A court clerk"),
            optionsUr = listOf("مجسٹریٹ", "ایس ایچ او", "پبلک پراسیکیوٹر", "عدالت کا کلرک"),
            correct = 0,
            explanationEn = "Section 164 allows a Magistrate to record statements and confessions made during an investigation.",
            explanationUr = "دفعہ 164 مجسٹریٹ کو تفتیش کے دوران دیے گئے بیانات اور اقبالِ جرم ریکارڈ کرنے کا اختیار دیتی ہے۔"
        ),
        DailyQuestion(
            ref = "PPC s.34",
            questionEn = "Section 34 of the Pakistan Penal Code deals with:",
            questionUr = "تعزیراتِ پاکستان کی دفعہ 34 کا تعلق کس سے ہے؟",
            optionsEn = listOf("Common intention", "Abetment", "Criminal conspiracy", "Right of private defence"),
            optionsUr = listOf("مشترکہ ارادہ", "اعانتِ جرم", "مجرمانہ سازش", "ذاتی دفاع کا حق"),
            correct = 0,
            explanationEn = "Section 34: when a criminal act is done by several persons in furtherance of the common intention of all, each is liable as if he alone did it.",
            explanationUr = "دفعہ 34: جب کئی افراد سب کے مشترکہ ارادے کو آگے بڑھانے کے لیے کوئی مجرمانہ فعل کریں تو ہر ایک اس کا ذمہ دار ہوتا ہے جیسے اس نے اکیلے کیا ہو۔"
        ),
        DailyQuestion(
            ref = "Arms Ordinance s.13(2)(b)",
            questionEn = "Under section 13(2)(b) of the Punjab Arms Ordinance, the minimum imprisonment for an offence with a prohibited bore weapon is:",
            questionUr = "پنجاب اسلحہ آرڈیننس کی دفعہ 13(2)(ب) کے تحت ممنوعہ بور کے ہتھیار کے جرم پر کم از کم قید کتنی ہے؟",
            optionsEn = listOf("1 year", "2 years", "4 years", "7 years"),
            optionsUr = listOf("1 سال", "2 سال", "4 سال", "7 سال"),
            correct = 2,
            explanationEn = "Prohibited bore weapon: imprisonment of not less than four years and up to seven years, and fine (Punjab text as amended in 2015).",
            explanationUr = "ممنوعہ بور کا ہتھیار: کم از کم چار سال اور زیادہ سے زیادہ سات سال قید، اور جرمانہ (پنجاب کا متن، 2015 کی ترمیم کے مطابق)۔"
        ),
        DailyQuestion(
            ref = "PPC s.83",
            questionEn = "Under section 83 PPC, a child of which age range is protected only if he had not attained sufficient maturity of understanding?",
            questionUr = "تعزیراتِ پاکستان کی دفعہ 83 کے تحت کس عمر کے بچے کو تب تحفظ ملتا ہے جب وہ سمجھ کی کافی پختگی تک نہ پہنچا ہو؟",
            optionsEn = listOf("Above 7 and under 12", "Above 10 and under 14", "Above 12 and under 16", "Above 14 and under 18"),
            optionsUr = listOf("7 سے اوپر اور 12 سے کم", "10 سے اوپر اور 14 سے کم", "12 سے اوپر اور 16 سے کم", "14 سے اوپر اور 18 سے کم"),
            correct = 1,
            explanationEn = "Section 83: a child above ten and under fourteen, who has not attained sufficient maturity of understanding to judge the nature and consequences of his conduct on that occasion.",
            explanationUr = "دفعہ 83: دس سے اوپر اور چودہ سے کم عمر بچہ، جو اس موقع پر اپنے طرزِ عمل کی نوعیت اور نتائج سمجھنے کی کافی پختگی تک نہ پہنچا ہو۔"
        )
    )

    val knowledge = listOf(
        KnowledgeCard(
            "PPC s.82",
            "A child under ten", "دس سال سے کم عمر بچہ",
            "Under section 82 of the Pakistan Penal Code, nothing is an offence if it is done by a child under ten years of age.",
            "تعزیراتِ پاکستان کی دفعہ 82 کے مطابق دس سال سے کم عمر بچے کا کیا ہوا کوئی فعل جرم نہیں ہوتا۔"
        ),
        KnowledgeCard(
            "PPC s.83",
            "A child between ten and fourteen", "دس سے چودہ سال کا بچہ",
            "Under section 83, an act of a child above ten and under fourteen is not an offence if the child had not attained sufficient maturity of understanding to judge the nature and consequences of the conduct on that occasion.",
            "دفعہ 83 کے مطابق دس سے چودہ سال کے بچے کا فعل اس صورت میں جرم نہیں جب بچہ اس موقع پر اپنے طرزِ عمل کی نوعیت اور نتائج سمجھنے کی کافی پختگی تک نہ پہنچا ہو۔"
        ),
        KnowledgeCard(
            "PPC s.34",
            "Common intention", "مشترکہ ارادہ",
            "Section 34: when a criminal act is done by several persons in furtherance of the common intention of all, each of them is liable for that act in the same manner as if it were done by him alone.",
            "دفعہ 34: جب کئی افراد سب کے مشترکہ ارادے کو آگے بڑھانے کے لیے کوئی مجرمانہ فعل کریں تو ان میں سے ہر ایک اس فعل کا اسی طرح ذمہ دار ہوتا ہے جیسے وہ اس نے اکیلے کیا ہو۔"
        ),
        KnowledgeCard(
            "CrPC s.154",
            "What is an FIR?", "ایف آئی آر کیا ہے؟",
            "Section 154 CrPC: information about a cognizable offence given to the officer in charge of a police station is written down and signed by the person giving it. This is known as the First Information Report (FIR).",
            "ضابطہ فوجداری کی دفعہ 154: قابلِ دست اندازی جرم کی اطلاع تھانے کے انچارج کو دی جائے تو اسے تحریر کیا جاتا ہے اور اطلاع دینے والا اس پر دستخط کرتا ہے۔ اسی کو ابتدائی اطلاعی رپورٹ (ایف آئی آر) کہتے ہیں۔"
        ),
        KnowledgeCard(
            "CrPC s.164",
            "Statements before a Magistrate", "مجسٹریٹ کے سامنے بیان",
            "Section 164 CrPC lets a Magistrate record statements and confessions made during an investigation.",
            "ضابطہ فوجداری کی دفعہ 164 مجسٹریٹ کو تفتیش کے دوران دیے گئے بیانات اور اقبالِ جرم ریکارڈ کرنے کا اختیار دیتی ہے۔"
        ),
        KnowledgeCard(
            "QSO Art. 38",
            "Confession to the police", "پولیس کے سامنے اقبالِ جرم",
            "Article 38: no confession made to a police officer shall be proved against a person accused of any offence.",
            "آرٹیکل 38: پولیس افسر کے سامنے کیا گیا کوئی اقبالِ جرم کسی ملزم کے خلاف ثابت نہیں کیا جائے گا۔"
        ),
        KnowledgeCard(
            "QSO Art. 39",
            "Confession in police custody", "پولیس کی حراست میں اقبالِ جرم",
            "Article 39: a confession made by a person in the custody of a police officer cannot be proved against him unless it was made in the immediate presence of a Magistrate.",
            "آرٹیکل 39: پولیس کی حراست میں کسی شخص کا اقبالِ جرم اس کے خلاف ثابت نہیں ہو سکتا جب تک وہ مجسٹریٹ کی فوری موجودگی میں نہ کیا گیا ہو۔"
        ),
        KnowledgeCard(
            "QSO Art. 164",
            "Evidence from modern devices", "جدید آلات سے حاصل شدہ شہادت",
            "Article 164: the Court may allow any evidence that has become available because of modern devices or techniques to be produced, in such cases as it considers appropriate.",
            "آرٹیکل 164: عدالت جن مقدمات کو مناسب سمجھے ان میں جدید آلات یا تکنیک سے حاصل ہونے والی کسی بھی شہادت کو پیش کرنے کی اجازت دے سکتی ہے۔"
        ),
        KnowledgeCard(
            "Arms Ordinance s.8",
            "Going armed", "اسلحہ لے کر چلنا",
            "Section 8 of the Punjab Arms Ordinance: no person shall go armed with any arms except under a licence. An unlicensed person may be disarmed by a Magistrate, a Police Officer or another empowered person.",
            "پنجاب اسلحہ آرڈیننس کی دفعہ 8: کوئی شخص لائسنس کے بغیر اسلحہ لے کر نہیں چل سکتا۔ لائسنس کے بغیر شخص کا اسلحہ مجسٹریٹ، پولیس افسر یا بااختیار شخص لے سکتا ہے۔"
        ),
        KnowledgeCard(
            "Arms Ordinance s.13",
            "Punishment depends on the bore", "سزا کا انحصار بور پر ہے",
            "Section 13(2): for a non-prohibited bore weapon the imprisonment is two to seven years and fine; for a prohibited bore weapon it is four to seven years and fine; for larger quantities it is five to fourteen years and fine.",
            "دفعہ 13(2): غیر ممنوعہ بور کے ہتھیار پر دو سے سات سال قید اور جرمانہ؛ ممنوعہ بور کے ہتھیار پر چار سے سات سال قید اور جرمانہ؛ زیادہ تعداد پر پانچ سے چودہ سال قید اور جرمانہ۔"
        ),
        KnowledgeCard(
            "Animals Act s.9",
            "Three months to prosecute", "مقدمے کے لیے تین مہینے",
            "Section 9 of the Prevention of Cruelty to Animals Act, 1890: a prosecution must not be started after three months from the date of the offence.",
            "انسدادِ ظلم بر حیوانات ایکٹ، 1890 کی دفعہ 9: جرم کی تاریخ سے تین مہینے گزرنے کے بعد مقدمہ شروع نہیں کیا جا سکتا۔"
        ),
        KnowledgeCard(
            "CNSA s.21",
            "Search without a warrant", "وارنٹ کے بغیر تلاشی",
            "Section 21 CNSA: an authorized officer not below the rank of Sub-Inspector of Police, or equivalent, may enter and search without a warrant if a warrant cannot be obtained without giving a chance to hide evidence or escape. He must record his grounds and send a copy to his superior.",
            "سی این ایس اے کی دفعہ 21: سب انسپکٹر پولیس یا اس کے برابر عہدے سے کم نہ ہونے والا بااختیار افسر وارنٹ کے بغیر داخل ہو کر تلاشی لے سکتا ہے، اگر وارنٹ لینے میں ثبوت چھپانے یا فرار کا موقع مل سکتا ہو۔ اسے اپنی وجوہات لکھ کر بالا افسر کو نقل بھیجنی ہوتی ہے۔"
        ),
        KnowledgeCard(
            "CNSA s.36",
            "Government Analyst report", "گورنمنٹ اینالسٹ کی رپورٹ",
            "Section 36(2) CNSA: a report signed by a Government Analyst is admissible as evidence of the facts stated in it without formal proof and, unless rebutted, is conclusive.",
            "سی این ایس اے کی دفعہ 36(2): گورنمنٹ اینالسٹ کی دستخط شدہ رپورٹ بغیر رسمی ثبوت کے بیان کردہ حقائق کے ثبوت کے طور پر قابلِ قبول ہے اور جب تک رد نہ ہو حتمی ہوتی ہے۔"
        )
    )
}
