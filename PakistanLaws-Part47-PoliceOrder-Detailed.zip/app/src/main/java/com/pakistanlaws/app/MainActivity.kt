package com.pakistanlaws.app

import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pakistanlaws.app.data.ThemeMode
import com.pakistanlaws.app.navigation.AppNavHost
import com.pakistanlaws.app.ui.SettingsViewModel
import com.pakistanlaws.app.ui.theme.Language
import com.pakistanlaws.app.ui.theme.LocalAnimations
import com.pakistanlaws.app.ui.theme.PakistanLawsTheme
import com.pakistanlaws.app.ui.theme.UrduFont

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val settingsVm: SettingsViewModel = viewModel()
            val saved by settingsVm.settings.collectAsState()
            val settings = saved

            if (settings == null) {
                Box(Modifier.fillMaxSize())
            } else {
                val systemDark = isSystemInDarkTheme()
                val dark = when (settings.themeMode) {
                    ThemeMode.SYSTEM -> systemDark
                    ThemeMode.LIGHT -> false
                    ThemeMode.DARK -> true
                }
                val urdu = Language.isUrdu(LocalConfiguration.current)
                val context = LocalContext.current
                val family = remember(urdu) {
                    if (urdu) UrduFont.family(context) else FontFamily.Default
                }
                // Accessibility mode: larger text, stronger contrast, no animations.
                val scale = if (settings.accessibility) {
                    (settings.fontScale * 1.2f).coerceAtMost(1.6f)
                } else {
                    settings.fontScale
                }
                val animations = settings.animations && !settings.accessibility

                DisposableEffect(dark) {
                    this@MainActivity.enableEdgeToEdge(
                        statusBarStyle = SystemBarStyle.auto(
                            android.graphics.Color.TRANSPARENT,
                            android.graphics.Color.TRANSPARENT
                        ) { dark },
                        navigationBarStyle = SystemBarStyle.auto(
                            android.graphics.Color.TRANSPARENT,
                            android.graphics.Color.TRANSPARENT
                        ) { dark }
                    )
                    onDispose { }
                }

                CompositionLocalProvider(LocalAnimations provides animations) {
                    PakistanLawsTheme(
                        palette = settings.palette,
                        darkTheme = dark,
                        fontScale = scale,
                        highContrast = settings.accessibility,
                        urdu = urdu,
                        fontFamily = family
                    ) {
                        Surface(
                            modifier = Modifier.fillMaxSize(),
                            color = MaterialTheme.colorScheme.background
                        ) {
                            AppNavHost(settingsVm = settingsVm)
                        }
                    }
                }
            }
        }
    }
}
