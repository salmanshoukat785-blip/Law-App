package com.pakistanlaws.app.ui.screens

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.pakistanlaws.app.R
import com.pakistanlaws.app.ui.AppViewModel
import com.pakistanlaws.app.ui.Session
import com.pakistanlaws.app.ui.components.AppTextField
import com.pakistanlaws.app.ui.components.AuthLayout
import com.pakistanlaws.app.ui.components.ErrorText
import com.pakistanlaws.app.ui.components.PrimaryButton

/** "Enter Name" screen shown when someone continues as a guest. */
@Composable
fun GuestNameScreen(
    vm: AppViewModel,
    onSession: (Session) -> Unit,
    onBack: () -> Unit
) {
    val session by vm.session.collectAsState()
    val error by vm.error.collectAsState()
    var name by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(Unit) { vm.clearError() }
    LaunchedEffect(session) {
        if (session is Session.Active) onSession(session)
    }

    AuthLayout(
        title = stringResource(R.string.guest_title),
        subtitle = stringResource(R.string.guest_subtitle),
        onBack = onBack
    ) {
        AppTextField(
            value = name,
            onValueChange = { name = it },
            label = stringResource(R.string.label_name)
        )
        ErrorText(error, modifier = Modifier.padding(top = 12.dp))
        Spacer(Modifier.height(20.dp))
        PrimaryButton(
            text = stringResource(R.string.action_continue),
            onClick = { vm.continueAsGuest(name) }
        )
    }
}
