package com.pakistanlaws.app.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily

/**
 * Typography with a user-controlled scale (Font Size Adjustment).
 * Urdu needs taller lines, so the line height grows when [urdu] is true.
 */
fun appTypography(
    scale: Float = 1f,
    urdu: Boolean = false,
    family: FontFamily = FontFamily.Default
): Typography {
    val base = Typography()
    val lineFactor = if (urdu) 1.3f else 1f
    fun TextStyle.adapted() = copy(
        fontFamily = family,
        fontSize = fontSize * scale,
        lineHeight = lineHeight * scale * lineFactor
    )
    return Typography(
        displayLarge = base.displayLarge.adapted(),
        displayMedium = base.displayMedium.adapted(),
        displaySmall = base.displaySmall.adapted(),
        headlineLarge = base.headlineLarge.adapted(),
        headlineMedium = base.headlineMedium.adapted(),
        headlineSmall = base.headlineSmall.adapted(),
        titleLarge = base.titleLarge.adapted(),
        titleMedium = base.titleMedium.adapted(),
        titleSmall = base.titleSmall.adapted(),
        bodyLarge = base.bodyLarge.adapted(),
        bodyMedium = base.bodyMedium.adapted(),
        bodySmall = base.bodySmall.adapted(),
        labelLarge = base.labelLarge.adapted(),
        labelMedium = base.labelMedium.adapted(),
        labelSmall = base.labelSmall.adapted()
    )
}
