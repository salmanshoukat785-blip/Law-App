package com.pakistanlaws.app.data

const val STATUS_PENDING = "pending"
const val STATUS_APPROVED = "approved"
const val STATUS_REJECTED = "rejected"

/** A user account as stored in Firestore: users/{uid}. */
data class UserProfile(
    val uid: String,
    val name: String,
    val phone: String,
    val status: String
)

object PhoneUtil {
    /** Returns a number like 923001234567, or null if the input is not a valid Pakistani mobile number. */
    fun normalize(input: String): String? {
        val d = input.filter { it.isDigit() }
        val n = when {
            d.length == 12 && d.startsWith("92") -> d
            d.length == 11 && d.startsWith("0") -> "92" + d.substring(1)
            d.length == 10 && d.startsWith("3") -> "92$d"
            else -> return null
        }
        return if (n.startsWith("923")) n else null
    }

    fun display(normalized: String): String =
        if (normalized.length == 12) {
            "+" + normalized.substring(0, 2) + " " + normalized.substring(2, 5) + " " + normalized.substring(5)
        } else {
            normalized
        }

    /** Firebase email/password sign-in is used behind the scenes: the mobile number becomes the "email". */
    fun toEmail(normalized: String): String = "$normalized@pakistanlaws.app"
}
