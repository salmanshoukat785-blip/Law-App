package com.pakistanlaws.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pakistanlaws.app.data.HomeData
import com.pakistanlaws.app.data.HomeStore
import com.pakistanlaws.app.data.db.AppDatabase
import com.pakistanlaws.app.data.db.SectionEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val store = HomeStore(application)
    private val sections = AppDatabase.get(application).sectionDao()
    private val today = LocalDate.now().toString()

    val data: StateFlow<HomeData?> = store.flow(today)
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    /** Recently viewed sections in order, newest first. */
    val recent: StateFlow<List<SectionEntity>> = store.flow(today)
        .map { it.recentIds }
        .distinctUntilChanged()
        .map { ids ->
            if (ids.isEmpty()) {
                emptyList()
            } else {
                val found = sections.getByIds(ids).associateBy { it.id }
                ids.mapNotNull { found[it] }
            }
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun answerDaily(choice: Int) {
        viewModelScope.launch { store.answerDaily(today, choice) }
    }

    fun setGoals(questions: Int, minutes: Int) {
        viewModelScope.launch { store.setGoals(questions, minutes) }
    }

    fun recordRecent(sectionId: String) {
        viewModelScope.launch { store.addRecent(sectionId) }
    }
}
