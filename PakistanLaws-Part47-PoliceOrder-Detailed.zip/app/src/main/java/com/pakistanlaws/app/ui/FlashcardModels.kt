package com.pakistanlaws.app.ui

import androidx.annotation.StringRes
import com.pakistanlaws.app.R
import com.pakistanlaws.app.data.db.CardProgressEntity

/** The groups of flashcards. */
enum class FlashDeck(@StringRes val titleRes: Int, @StringRes val descRes: Int) {
    SECTIONS(R.string.deck_sections, R.string.deck_sections_desc),
    VOCAB(R.string.deck_vocab, R.string.deck_vocab_desc),
    DIFFICULT(R.string.deck_difficult, R.string.deck_difficult_desc),
    CUSTOM(R.string.deck_custom, R.string.deck_custom_desc)
}

/** One card, in both languages. [key] identifies it in the spaced-repetition table. */
data class Flashcard(
    val key: String,
    val deck: FlashDeck,
    val frontEn: String,
    val frontUr: String,
    val backEn: String,
    val backUr: String,
    val ref: String
) {
    fun front(urdu: Boolean): String = if (urdu && frontUr.isNotBlank()) frontUr else frontEn
    fun back(urdu: Boolean): String = if (urdu && backUr.isNotBlank()) backUr else backEn
}

/** A practice session that is running (or has just finished). */
data class FlashSession(
    val deck: FlashDeck?,
    val queue: List<Flashcard>,
    val index: Int = 0,
    val flipped: Boolean = false,
    val remembered: Int = 0,
    val forgot: Int = 0,
    val startedAt: Long,
    val finished: Boolean = false,
    /** True for "practise anyway": the schedule is not changed. */
    val practiceOnly: Boolean = false
)

data class DeckCounts(val total: Int, val due: Int, val fresh: Int)

/**
 * A simple Leitner system. A card you remember moves up a box and comes back after a longer gap
 * (1, 3, 7, 14 and 30 days). A card you forget goes back to box 1 and returns in 10 minutes.
 */
object Srs {
    private const val DAY_MS = 24L * 60 * 60 * 1000
    private const val FORGOT_GAP_MS = 10L * 60 * 1000
    private const val MAX_BOX = 5
    private val gapDays = intArrayOf(0, 1, 3, 7, 14, 30)

    fun after(old: CardProgressEntity?, key: String, remembered: Boolean, now: Long): CardProgressEntity {
        val reps = (old?.reps ?: 0) + 1
        return if (remembered) {
            val box = minOf((old?.box ?: 0) + 1, MAX_BOX)
            CardProgressEntity(
                cardKey = key,
                box = box,
                dueAt = now + gapDays[box] * DAY_MS,
                reps = reps,
                lapses = old?.lapses ?: 0,
                lastReviewedAt = now
            )
        } else {
            CardProgressEntity(
                cardKey = key,
                box = 1,
                dueAt = now + FORGOT_GAP_MS,
                reps = reps,
                lapses = (old?.lapses ?: 0) + 1,
                lastReviewedAt = now
            )
        }
    }

    fun counts(cards: List<Flashcard>, progress: Map<String, CardProgressEntity>, now: Long): DeckCounts {
        var due = 0
        var fresh = 0
        for (card in cards) {
            val p = progress[card.key]
            if (p == null) fresh++ else if (p.dueAt <= now) due++
        }
        return DeckCounts(cards.size, due, fresh)
    }

    /** Due cards first (oldest first), then new cards, at most [limit] cards and [newLimit] new ones. */
    fun buildSession(
        cards: List<Flashcard>,
        progress: Map<String, CardProgressEntity>,
        now: Long,
        limit: Int = 20,
        newLimit: Int = 10
    ): List<Flashcard> {
        val due = cards
            .filter { card -> progress[card.key]?.let { it.dueAt <= now } == true }
            .sortedBy { progress[it.key]?.dueAt ?: 0L }
            .take(limit)
        val room = limit - due.size
        val fresh = cards
            .filter { progress[it.key] == null }
            .shuffled()
            .take(minOf(room, newLimit))
        return due + fresh
    }
}
