package com.pakistanlaws.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pakistanlaws.app.R
import com.pakistanlaws.app.ui.components.GUEST_SECTION_LIMIT
import com.pakistanlaws.app.content.LawCatalog
import com.pakistanlaws.app.data.db.SectionEntity
import com.pakistanlaws.app.ui.LawViewModel
import com.pakistanlaws.app.ui.theme.Language

/** A law's table of contents, grouped by chapter, with a box to jump to a section number. */
@Composable
fun LawScreen(
    lawId: String,
    onBack: () -> Unit,
    onOpenSection: (String) -> Unit,
    vm: LawViewModel = viewModel()
) {
    LaunchedEffect(lawId) { vm.load(lawId) }
    val law by vm.law.collectAsState()
    val sections by vm.sections.collectAsState()
    val urdu = Language.isUrdu(LocalConfiguration.current)
    var filter by rememberSaveable { mutableStateOf("") }

    val fallbackName = LawCatalog.laws.firstOrNull { it.id == lawId }?.name(urdu).orEmpty()
    val title = law?.let { if (urdu && it.titleUr.isNotBlank()) it.titleUr else it.titleEn } ?: fallbackName

    val isGuest = com.pakistanlaws.app.ui.components.LocalIsGuest.current
    val query = filter.trim()
    val visible = if (query.isEmpty()) {
        sections
    } else {
        sections.filter {
            it.number.startsWith(query, ignoreCase = true) ||
                it.titleEn.contains(query, ignoreCase = true) ||
                it.titleUr.contains(query)
        }
    }
    val exact = sections.firstOrNull { it.number.equals(query, ignoreCase = true) }
    val grouped = visible.groupBy {
        if (urdu && it.chapterUr.isNotBlank()) it.chapterUr else it.chapter
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(R.string.action_back)
                )
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
        ) {
            item {
                OutlinedTextField(
                    value = filter,
                    onValueChange = { filter = it },
                    singleLine = true,
                    label = { Text(stringResource(R.string.law_jump_hint)) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Go
                    ),
                    keyboardActions = KeyboardActions(
                        onGo = { exact?.let { onOpenSection(it.id) } }
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
            }
            if (sections.isEmpty()) {
                item {
                    Text(
                        text = stringResource(R.string.law_empty),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
            }
            grouped.forEach { (chapter, list) ->
                item(key = "chapter-$chapter") {
                    Text(
                        text = com.pakistanlaws.app.ui.components.rememberUrdu(chapter),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
                    )
                }
                items(list, key = { it.id }) { section ->
                    SectionRow(
                        section,
                        urdu,
                        locked = isGuest && section.sortOrder > GUEST_SECTION_LIMIT
                    ) { onOpenSection(section.id) }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun SectionRow(
    section: SectionEntity,
    urdu: Boolean,
    locked: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = section.number,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.width(48.dp)
        )
        Text(
            text = com.pakistanlaws.app.ui.components.rememberUrdu(section.titleEn),
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f)
        )
        if (locked) {
            Spacer(Modifier.width(8.dp))
            Icon(
                imageVector = Icons.Filled.Lock,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
        }
        if (section.isImportant) {
            Spacer(Modifier.width(8.dp))
            Icon(
                imageVector = Icons.Filled.Star,
                contentDescription = stringResource(R.string.reader_important),
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
