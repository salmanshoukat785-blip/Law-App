package com.pakistanlaws.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pakistanlaws.app.data.SyllabusStore
import com.pakistanlaws.app.data.db.AppDatabase
import com.pakistanlaws.app.data.db.BookmarkEntity
import com.pakistanlaws.app.data.db.FavouriteEntity
import com.pakistanlaws.app.data.db.HighlightEntity
import com.pakistanlaws.app.data.db.NoteEntity
import com.pakistanlaws.app.data.db.QuestionEntity
import com.pakistanlaws.app.data.db.SectionEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
/** Everything the user saves: notes, bookmarks, favourites and highlights. */
class StudyViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.get(application)
    private val syllabusStore = SyllabusStore(application)

    /** The user's own syllabus, in book (law) and section order. */
    val syllabusSections: StateFlow<List<SectionEntity>> = syllabusStore.ids
        .flatMapLatest { ids ->
            kotlinx.coroutines.flow.flow {
                emit(
                    if (ids.isEmpty()) emptyList()
                    else ids.toList().chunked(500).flatMap { db.sectionDao().getByIds(it) }
                        .sortedWith(compareBy({ it.lawId }, { it.sortOrder }))
                )
            }
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun removeFromSyllabus(id: String) {
        viewModelScope.launch { syllabusStore.remove(id) }
    }

    fun clearSyllabus() {
        viewModelScope.launch { syllabusStore.clear() }
    }

    val notes: StateFlow<List<NoteEntity>> = db.noteDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val bookmarkedSections: StateFlow<List<SectionEntity>> = db.bookmarkDao().observeSections()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val favouriteQuestionIds: StateFlow<Set<String>> = db.favouriteDao().observeIds(KIND_QUESTION)
        .map { it.toSet() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    val favouriteLawIds: StateFlow<Set<String>> = db.favouriteDao().observeIds(KIND_LAW)
        .map { it.toSet() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    val favouriteQuestions: StateFlow<List<QuestionEntity>> = db.favouriteDao().observeQuestions()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val highlights: StateFlow<List<HighlightEntity>> = db.highlightDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun notesFor(sectionId: String): Flow<List<NoteEntity>> = db.noteDao().observeForSection(sectionId)

    fun highlightsFor(sectionId: String): Flow<List<HighlightEntity>> = db.highlightDao().observeFor(sectionId)

    // ---- notes ----

    /** Saves a new note, or updates [existing]. The title falls back to the start of the text. */
    fun saveNote(existing: NoteEntity?, sectionId: String?, subject: String, title: String, body: String) {
        val text = body.trim()
        if (text.isEmpty()) return
        val now = System.currentTimeMillis()
        val note = NoteEntity(
            id = existing?.id ?: 0,
            sectionId = existing?.sectionId ?: sectionId,
            subject = subject.trim(),
            title = title.trim().ifEmpty { text.take(40) },
            body = text,
            createdAt = existing?.createdAt ?: now,
            updatedAt = now
        )
        viewModelScope.launch { db.noteDao().upsert(note) }
    }

    fun deleteNote(id: Long) {
        viewModelScope.launch { db.noteDao().delete(id) }
    }

    // ---- bookmarks ----

    fun removeBookmark(sectionId: String) {
        viewModelScope.launch { db.bookmarkDao().delete(sectionId) }
    }

    fun addBookmark(sectionId: String) {
        viewModelScope.launch {
            db.bookmarkDao().insert(BookmarkEntity(sectionId, System.currentTimeMillis()))
        }
    }

    // ---- favourites ----

    fun toggleFavouriteQuestion(id: String) = toggleFavourite(KIND_QUESTION, id, id in favouriteQuestionIds.value)

    fun toggleFavouriteLaw(id: String) = toggleFavourite(KIND_LAW, id, id in favouriteLawIds.value)

    private fun toggleFavourite(kind: String, id: String, isFavourite: Boolean) {
        val key = "$kind:$id"
        viewModelScope.launch {
            if (isFavourite) {
                db.favouriteDao().delete(key)
            } else {
                db.favouriteDao().insert(FavouriteEntity(key, kind, id, System.currentTimeMillis()))
            }
        }
    }

    // ---- highlights ----

    fun toggleHighlight(sectionId: String, source: String, paragraph: Int, text: String, isOn: Boolean) {
        viewModelScope.launch {
            if (isOn) {
                db.highlightDao().delete(sectionId, source, paragraph)
            } else {
                db.highlightDao().insert(
                    HighlightEntity(sectionId, source, paragraph, text, System.currentTimeMillis())
                )
            }
        }
    }

    fun removeHighlight(item: HighlightEntity) {
        viewModelScope.launch {
            db.highlightDao().delete(item.sectionId, item.source, item.paragraph)
        }
    }


    // ---- quiz from the syllabus ----

    /**
     * MCQs only for the sections in the user's syllabus: the ready-made bank questions whose
     * reference is one of those sections, plus one generated "which provision is this?" question
     * for each syllabus section that has no bank question yet.
     */
    suspend fun buildSyllabusQuiz(): List<QuestionEntity> {
        val secs = syllabusSections.value
        if (secs.isEmpty()) return emptyList()
        val keys = secs.map { it.lawId to it.number.lowercase() }.toSet()
        val covered = HashSet<Pair<String, String>>()
        val bank = db.questionDao().getAll().filter { q ->
            val m = REF_RX.find(q.ref) ?: return@filter false
            val key = q.lawId to m.groupValues[1].lowercase()
            if (key in keys) { covered.add(key); true } else false
        }
        val byLaw = HashMap<String, List<SectionEntity>>()
        val generated = secs.filter { (it.lawId to it.number.lowercase()) !in covered }.mapNotNull { sec ->
            val siblings = byLaw.getOrPut(sec.lawId) { db.sectionDao().observeByLaw(sec.lawId).first() }
            makeQuestion(sec, siblings)
        }
        return bank + generated
    }

    private fun makeQuestion(sec: SectionEntity, siblings: List<SectionEntity>): QuestionEntity? {
        var desc = sec.shortEn.trim().replace("\\s+".toRegex(), " ")
        if (desc.length < 20) return null
        if (desc.length > 230) desc = desc.take(230).substringBeforeLast(' ') + "…"
        val wrong = siblings.filter { it.id != sec.id && it.titleEn.isNotBlank() && it.titleEn != sec.titleEn }
            .shuffled().take(3)
        if (wrong.size < 3) return null
        fun label(x: SectionEntity) = sectionRef(x.id) + " — " + x.titleEn
        val options = (listOf(sec) + wrong).map { label(it) }.joinToString("\n")
        val lawName = com.pakistanlaws.app.content.LawCatalog.laws.firstOrNull { it.id == sec.lawId }?.shortName ?: sec.lawId
        val text = "Which provision is this?\n\n" + desc
        val expl = label(sec) + "\n\n" + sec.shortEn.trim()
        return QuestionEntity(
            id = "syl-" + sec.id, lawId = sec.lawId,
            topicEn = lawName, topicUr = lawName,
            typeEn = "My Syllabus", typeUr = "My Syllabus",
            isImportant = sec.isImportant, difficulty = 2,
            textEn = text, textUr = text,
            optionsEn = options, optionsUr = options,
            correctIndex = 0,
            explanationEn = expl, explanationUr = expl,
            ref = sectionRef(sec.id)
        )
    }

    private companion object {
        val REF_RX = Regex("""(?:Art\.|\bs\.|\br\.|Rule)\s*([0-9A-Za-z]+(?:-[0-9A-Za-z]+)?)""")
        const val KIND_QUESTION = "q"
        const val KIND_LAW = "l"
    }
}
