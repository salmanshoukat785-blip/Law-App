package com.pakistanlaws.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pakistanlaws.app.data.AppSettings
import com.pakistanlaws.app.data.SettingsStore
import com.pakistanlaws.app.data.ThemeMode
import com.pakistanlaws.app.data.db.AppDatabase
import com.pakistanlaws.app.ui.theme.AppPalette
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val store = SettingsStore(application)
    private val database = AppDatabase.get(application)

    /** Null until the saved settings have been read, so the app never flashes the wrong theme. */
    val settings: StateFlow<AppSettings?> = store.flow
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val lawCount: StateFlow<Int> = database.lawDao().observeCount()
        .stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { store.setThemeMode(mode) }
    }

    fun setPalette(palette: AppPalette) {
        viewModelScope.launch { store.setPalette(palette) }
    }

    fun setFontScale(scale: Float) {
        viewModelScope.launch { store.setFontScale(scale) }
    }

    fun setAccessibility(enabled: Boolean) {
        viewModelScope.launch { store.setAccessibility(enabled) }
    }

    fun setAnimations(enabled: Boolean) {
        viewModelScope.launch { store.setAnimations(enabled) }
    }

    fun setAutoUrdu(enabled: Boolean) {
        viewModelScope.launch {
            store.setAutoUrdu(enabled)
            com.pakistanlaws.app.ui.theme.Language.setUrdu(enabled)
        }
    }
}
