package com.pakistanlaws.app.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

/** The app is English only, so there is no language button. Kept so existing screens still compile. */
@Composable
@Suppress("UNUSED_PARAMETER")
fun LanguageToggle(modifier: Modifier = Modifier) {
}
