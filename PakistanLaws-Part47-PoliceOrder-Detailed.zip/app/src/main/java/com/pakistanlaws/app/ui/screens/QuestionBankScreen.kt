package com.pakistanlaws.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pakistanlaws.app.R
import com.pakistanlaws.app.content.LawCatalog
import com.pakistanlaws.app.data.db.QuestionEntity
import com.pakistanlaws.app.ui.QuestionBankViewModel
import com.pakistanlaws.app.ui.QuizConfig
import com.pakistanlaws.app.ui.QuizMode
import com.pakistanlaws.app.ui.QuizViewModel
import com.pakistanlaws.app.ui.explanation
import com.pakistanlaws.app.ui.options
import com.pakistanlaws.app.ui.text
import com.pakistanlaws.app.ui.theme.Language
import com.pakistanlaws.app.ui.type

private const val STATUS_ALL = 0
private const val STATUS_WRONG = 1
private const val STATUS_UNATTEMPTED = 2
private const val STATUS_IMPORTANT = 3

/**
 * The question bank: search and filter every question, revise wrong answers, see unattempted and
 * important questions, and start a random practice set from the current selection.
 */
@Composable
fun QuestionBankScreen(
    preset: String,
    quizVm: QuizViewModel,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    vm: QuestionBankViewModel = viewModel()
) {
    val bank by vm.bank.collectAsState()
    val status by vm.status.collectAsState()
    val appUrdu = Language.isUrdu(LocalConfiguration.current)
    var urdu by rememberSaveable { mutableStateOf(appUrdu) }

    var query by rememberSaveable { mutableStateOf("") }
    var lawId by rememberSaveable { mutableStateOf<String?>(null) }
    var topic by rememberSaveable { mutableStateOf<String?>(null) }
    var difficulty by rememberSaveable { mutableStateOf<Int?>(null) }
    var type by rememberSaveable { mutableStateOf<String?>(null) }
    var statusFilter by rememberSaveable {
        mutableIntStateOf(if (preset == "wrong") STATUS_WRONG else STATUS_ALL)
    }
    var setSize by rememberSaveable { mutableIntStateOf(10) }
    var expandedId by rememberSaveable { mutableStateOf<String?>(null) }

    val laws = LawCatalog.laws.filter { law -> bank.any { it.lawId == law.id } }
    val topics = bank
        .filter { lawId != null && it.lawId == lawId }
        .map { it.topicEn to it.topicUr }
        .distinct()
    val types = bank.map { it.typeEn to it.typeUr }.filter { it.first.isNotBlank() }.distinct()

    val q = query.trim()
    val filtered = remember(bank, status, q, lawId, topic, difficulty, type, statusFilter) {
        bank.filter { item ->
            (lawId == null || item.lawId == lawId) &&
                (topic == null || item.topicEn == topic) &&
                (difficulty == null || item.difficulty == difficulty) &&
                (type == null || item.typeEn == type) &&
                when (statusFilter) {
                    STATUS_WRONG -> status[item.id] == false
                    STATUS_UNATTEMPTED -> !status.containsKey(item.id)
                    STATUS_IMPORTANT -> item.isImportant
                    else -> true
                } &&
                (q.length < 2 ||
                    item.textEn.contains(q, ignoreCase = true) ||
                    item.textUr.contains(q) ||
                    item.ref.contains(q, ignoreCase = true) ||
                    item.topicEn.contains(q, ignoreCase = true))
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(R.string.action_back)
                )
            }
            Text(
                text = stringResource(R.string.quick_bank),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
        ) {
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    placeholder = { Text(stringResource(R.string.bank_search_hint)) },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth()
                )

                // Show: all / wrong / unattempted / important
                FilterLabel(R.string.bank_status)
                ChipsRow {
                    FilterChip(
                        selected = statusFilter == STATUS_ALL,
                        onClick = { statusFilter = STATUS_ALL },
                        label = { Text(stringResource(R.string.status_all)) }
                    )
                    FilterChip(
                        selected = statusFilter == STATUS_WRONG,
                        onClick = { statusFilter = STATUS_WRONG },
                        label = { Text(stringResource(R.string.status_wrong)) }
                    )
                    FilterChip(
                        selected = statusFilter == STATUS_UNATTEMPTED,
                        onClick = { statusFilter = STATUS_UNATTEMPTED },
                        label = { Text(stringResource(R.string.status_unattempted)) }
                    )
                    FilterChip(
                        selected = statusFilter == STATUS_IMPORTANT,
                        onClick = { statusFilter = STATUS_IMPORTANT },
                        label = { Text(stringResource(R.string.reader_important)) }
                    )
                }

                FilterLabel(R.string.setup_law)
                ChipsRow {
                    FilterChip(
                        selected = lawId == null,
                        onClick = {
                            lawId = null
                            topic = null
                        },
                        label = { Text(stringResource(R.string.setup_all_laws)) }
                    )
                    laws.forEach { law ->
                        FilterChip(
                            selected = lawId == law.id,
                            onClick = {
                                lawId = law.id
                                topic = null
                            },
                            label = { Text(law.shortName) }
                        )
                    }
                }

                if (topics.isNotEmpty()) {
                    FilterLabel(R.string.setup_topic)
                    ChipsRow {
                        FilterChip(
                            selected = topic == null,
                            onClick = { topic = null },
                            label = { Text(stringResource(R.string.setup_all_topics)) }
                        )
                        topics.forEach { (en, ur) ->
                            FilterChip(
                                selected = topic == en,
                                onClick = { topic = en },
                                label = { Text(if (urdu && ur.isNotBlank()) ur else en) }
                            )
                        }
                    }
                }

                FilterLabel(R.string.setup_level)
                ChipsRow {
                    FilterChip(
                        selected = difficulty == null,
                        onClick = { difficulty = null },
                        label = { Text(stringResource(R.string.level_mixed)) }
                    )
                    FilterChip(
                        selected = difficulty == 1,
                        onClick = { difficulty = 1 },
                        label = { Text(stringResource(R.string.level_easy)) }
                    )
                    FilterChip(
                        selected = difficulty == 2,
                        onClick = { difficulty = 2 },
                        label = { Text(stringResource(R.string.level_medium)) }
                    )
                    FilterChip(
                        selected = difficulty == 3,
                        onClick = { difficulty = 3 },
                        label = { Text(stringResource(R.string.level_hard)) }
                    )
                }

                if (types.isNotEmpty()) {
                    FilterLabel(R.string.bank_type)
                    ChipsRow {
                        FilterChip(
                            selected = type == null,
                            onClick = { type = null },
                            label = { Text(stringResource(R.string.status_all)) }
                        )
                        types.forEach { (en, ur) ->
                            FilterChip(
                                selected = type == en,
                                onClick = { type = en },
                                label = { Text(if (urdu && ur.isNotBlank()) ur else en) }
                            )
                        }
                    }
                }

                // Practice set from the current selection
                FilterLabel(R.string.bank_set_size)
                ChipsRow {
                    listOf(5, 10, 20).forEach { option ->
                        FilterChip(
                            selected = setSize == option,
                            onClick = { setSize = option },
                            label = { Text("$option") }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = stringResource(R.string.bank_count_format, filtered.size),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    androidx.compose.material3.Button(
                        onClick = {
                            quizVm.start(
                                QuizConfig(
                                    mode = QuizMode.PRACTICE,
                                    count = minOf(setSize, filtered.size),
                                    questionIds = filtered.map { it.id }
                                )
                            )
                            onPlay()
                        },
                        enabled = filtered.isNotEmpty()
                    ) {
                        Text(
                            stringResource(
                                if (statusFilter == STATUS_WRONG) R.string.bank_repeat_wrong
                                else R.string.bank_practice
                            )
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            if (filtered.isEmpty()) {
                item {
                    Text(
                        text = stringResource(R.string.bank_none),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                }
            }

            items(filtered, key = { it.id }) { item ->
                QuestionCard(
                    item = item,
                    urdu = urdu,
                    lastCorrect = status[item.id],
                    expanded = expandedId == item.id,
                    onToggle = { expandedId = if (expandedId == item.id) null else item.id }
                )
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun QuestionCard(
    item: QuestionEntity,
    urdu: Boolean,
    lastCorrect: Boolean?,
    expanded: Boolean,
    onToggle: () -> Unit
) {
    val lawName = LawCatalog.laws.firstOrNull { it.id == item.lawId }?.shortName ?: item.lawId
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onToggle),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Icon(
                    imageVector = when (lastCorrect) {
                        true -> Icons.Filled.Check
                        false -> Icons.Filled.Close
                        null -> Icons.Filled.RadioButtonUnchecked
                    },
                    contentDescription = stringResource(
                        when (lastCorrect) {
                            true -> R.string.bank_status_correct
                            false -> R.string.bank_status_wrong
                            null -> R.string.bank_status_new
                        }
                    ),
                    tint = when (lastCorrect) {
                        true -> MaterialTheme.colorScheme.primary
                        false -> MaterialTheme.colorScheme.error
                        null -> MaterialTheme.colorScheme.outline
                    },
                    modifier = Modifier.size(22.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = item.text(urdu),
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = if (expanded) Int.MAX_VALUE else 3,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (item.isImportant) {
                    Spacer(Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Filled.Star,
                        contentDescription = stringResource(R.string.reader_important),
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                AssistChip(onClick = onToggle, label = { Text(lawName) })
                AssistChip(onClick = onToggle, label = { Text(item.ref) })
                AssistChip(
                    onClick = onToggle,
                    label = {
                        Text(
                            stringResource(
                                when (item.difficulty) {
                                    1 -> R.string.level_easy
                                    3 -> R.string.level_hard
                                    else -> R.string.level_medium
                                }
                            )
                        )
                    }
                )
                if (item.typeEn.isNotBlank()) {
                    AssistChip(onClick = onToggle, label = { Text(item.type(urdu)) })
                }
            }

            if (expanded) {
                Spacer(Modifier.height(10.dp))
                item.options(urdu).forEachIndexed { i, option ->
                    val correct = i == item.correctIndex
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (correct) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(
                            if (correct) 2.dp else 1.dp,
                            if (correct) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                        )
                    ) {
                        Text(
                            text = (i + 1).toString() + ".  " + option,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = item.explanation(urdu),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun FilterLabel(textRes: Int) {
    Text(
        text = stringResource(textRes),
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 14.dp, bottom = 6.dp)
    )
}

@Composable
private fun ChipsRow(content: @Composable () -> Unit) {
    Row(
        modifier = Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        content()
    }
}
