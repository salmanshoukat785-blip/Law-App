package com.pakistanlaws.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pakistanlaws.app.data.HomeStore
import com.pakistanlaws.app.data.SyllabusStore
import com.pakistanlaws.app.data.db.AppDatabase
import com.pakistanlaws.app.data.db.BookmarkEntity
import com.pakistanlaws.app.data.db.SectionEntity
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class ReaderViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.get(application)
    private val home = HomeStore(application)
    private val syllabus = SyllabusStore(application)
    private val currentId = MutableStateFlow<String?>(null)

    /** The section on screen (null while loading or if it does not exist). */
    val section: StateFlow<SectionEntity?> = currentId
        .flatMapLatest { id ->
            if (id == null) flowOf<SectionEntity?>(null) else flow<SectionEntity?> { emit(db.sectionDao().getById(id)) }
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    /** All sections of the same law, in order, for previous/next and related links. */
    val siblings: StateFlow<List<SectionEntity>> = section
        .map { it?.lawId }
        .distinctUntilChanged()
        .flatMapLatest { lawId ->
            if (lawId == null) flowOf(emptyList<SectionEntity>()) else db.sectionDao().observeByLaw(lawId)
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val bookmarked: StateFlow<Boolean> = currentId
        .flatMapLatest { id ->
            if (id == null) flowOf(false) else db.bookmarkDao().observeIsBookmarked(id)
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val inSyllabus: StateFlow<Boolean> = currentId
        .flatMapLatest { id -> syllabus.ids.map { id != null && id in it } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    fun toggleSyllabus() {
        val id = currentId.value ?: return
        viewModelScope.launch { syllabus.toggle(id) }
    }

    fun load(id: String) {
        currentId.value = id
        viewModelScope.launch { home.addRecent(id) }
    }

    fun toggleBookmark() {
        val id = currentId.value ?: return
        viewModelScope.launch {
            if (bookmarked.value) {
                db.bookmarkDao().delete(id)
            } else {
                db.bookmarkDao().insert(BookmarkEntity(id, System.currentTimeMillis()))
            }
        }
    }
}
