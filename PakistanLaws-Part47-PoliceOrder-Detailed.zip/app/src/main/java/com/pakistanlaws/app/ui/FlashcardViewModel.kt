package com.pakistanlaws.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pakistanlaws.app.content.LawCatalog
import com.pakistanlaws.app.content.VocabCards
import com.pakistanlaws.app.data.HomeStore
import com.pakistanlaws.app.data.db.AnswerRecordEntity
import com.pakistanlaws.app.data.db.AppDatabase
import com.pakistanlaws.app.data.db.CardProgressEntity
import com.pakistanlaws.app.data.db.CustomCardEntity
import com.pakistanlaws.app.data.db.QuestionEntity
import com.pakistanlaws.app.data.db.SectionEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import kotlin.math.ceil

class FlashcardViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.get(application)
    private val dao = db.flashcardDao()
    private val home = HomeStore(application)

    /** Every card from every deck. */
    val cards: StateFlow<List<Flashcard>> = combine(
        db.sectionDao().observeAll(),
        db.questionDao().observeAll(),
        db.answerRecordDao().observeAll(),
        dao.observeCustom()
    ) { sections, questions, answers, custom ->
        buildCards(sections, questions, answers, custom)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val progress: StateFlow<Map<String, CardProgressEntity>> = dao.observeProgress()
        .map { list -> list.associateBy { it.cardKey } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    val custom: StateFlow<List<CustomCardEntity>> = dao.observeCustom()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _session = MutableStateFlow<FlashSession?>(null)
    val session: StateFlow<FlashSession?> = _session.asStateFlow()

    // ---- sessions ----

    /** Starts the daily practice for one deck (or all decks when [deck] is null). */
    fun start(deck: FlashDeck?, practiceOnly: Boolean = false) {
        val pool = cards.value.filter { deck == null || it.deck == deck }
        val now = System.currentTimeMillis()
        val queue = if (practiceOnly) {
            pool.shuffled().take(10)
        } else {
            Srs.buildSession(pool, progress.value, now)
        }
        _session.value = FlashSession(
            deck = deck,
            queue = queue,
            startedAt = now,
            practiceOnly = practiceOnly
        )
    }

    fun flip() {
        val s = _session.value ?: return
        if (s.finished || s.queue.isEmpty()) return
        _session.value = s.copy(flipped = !s.flipped)
    }

    fun answer(remembered: Boolean) {
        val s = _session.value ?: return
        if (s.finished || !s.flipped || s.index >= s.queue.size) return
        val card = s.queue[s.index]
        // Only the first time a card appears in a session changes its schedule.
        val first = s.queue.subList(0, s.index).none { it.key == card.key }
        val now = System.currentTimeMillis()
        if (first && !s.practiceOnly) {
            val updated = Srs.after(progress.value[card.key], card.key, remembered, now)
            viewModelScope.launch { dao.upsertProgress(updated) }
        }
        // A forgotten card comes back once more at the end of this session.
        val queue = if (!remembered && first) s.queue + card else s.queue
        val rememberedCount = s.remembered + if (first && remembered) 1 else 0
        val forgotCount = s.forgot + if (first && !remembered) 1 else 0
        val next = s.index + 1
        val updatedSession = s.copy(
            queue = queue,
            index = next,
            flipped = false,
            remembered = rememberedCount,
            forgot = forgotCount
        )
        if (next >= queue.size) finish(updatedSession) else _session.value = updatedSession
    }

    private fun finish(s: FlashSession) {
        _session.value = s.copy(finished = true, flipped = false)
        val reviewed = s.remembered + s.forgot
        if (!s.practiceOnly && reviewed > 0) {
            viewModelScope.launch {
                val today = LocalDate.now().toString()
                val minutes = ceil((System.currentTimeMillis() - s.startedAt) / 60000.0).toInt()
                home.recordQuestions(today, reviewed)
                home.addMinutes(today, minutes.coerceAtLeast(1))
            }
        }
    }

    fun endSession() {
        _session.value = null
    }

    // ---- custom cards ----

    fun addCard(front: String, back: String) {
        val f = front.trim()
        val b = back.trim()
        if (f.isEmpty() || b.isEmpty()) return
        viewModelScope.launch {
            dao.insertCustom(CustomCardEntity(front = f, back = b, createdAt = System.currentTimeMillis()))
        }
    }

    fun deleteCard(id: Long) {
        viewModelScope.launch {
            dao.deleteCustom(id)
            dao.deleteProgress("c:$id")
        }
    }

    // ---- building the decks ----

    private fun buildCards(
        sections: List<SectionEntity>,
        questions: List<QuestionEntity>,
        answers: List<AnswerRecordEntity>,
        custom: List<CustomCardEntity>
    ): List<Flashcard> {
        val cards = ArrayList<Flashcard>()

        sections.filter { it.shortEn.isNotBlank() }.forEach { s ->
            cards.add(
                Flashcard(
                    key = "sec:${s.id}",
                    deck = FlashDeck.SECTIONS,
                    frontEn = "${sectionWord(s.lawId)} ${s.number}: ${s.titleEn}",
                    frontUr = "دفعہ ${s.number}: ${s.titleUr.ifBlank { s.titleEn }}",
                    backEn = s.shortEn,
                    backUr = s.shortUr.ifBlank { s.shortEn },
                    ref = sectionRef(s.id)
                )
            )
        }

        VocabCards.terms.forEach { v ->
            cards.add(
                Flashcard(
                    key = "v:${v.id}",
                    deck = FlashDeck.VOCAB,
                    frontEn = v.termEn,
                    frontUr = v.termUr,
                    backEn = v.meaningEn,
                    backUr = v.meaningUr,
                    ref = v.ref
                )
            )
        }

        // Difficult questions: the hard ones, and any question whose latest answer was wrong.
        val latestWrong = HashMap<String, Boolean>()
        answers.forEach { latestWrong[it.questionId] = !it.correct }
        questions.filter { it.difficulty == 3 || latestWrong[it.id] == true }.forEach { q ->
            val optionsEn = q.optionsEn.split("\n")
            val optionsUr = q.optionsUr.split("\n")
            val answerEn = optionsEn.getOrElse(q.correctIndex) { "" }
            val answerUr = optionsUr.getOrElse(q.correctIndex) { answerEn }
            cards.add(
                Flashcard(
                    key = "q:${q.id}",
                    deck = FlashDeck.DIFFICULT,
                    frontEn = q.textEn,
                    frontUr = q.textUr.ifBlank { q.textEn },
                    backEn = "Answer: $answerEn\n\n${q.explanationEn}",
                    backUr = "جواب: $answerUr\n\n${q.explanationUr.ifBlank { q.explanationEn }}",
                    ref = q.ref
                )
            )
        }

        custom.forEach { c ->
            cards.add(
                Flashcard(
                    key = "c:${c.id}",
                    deck = FlashDeck.CUSTOM,
                    frontEn = c.front,
                    frontUr = c.front,
                    backEn = c.back,
                    backUr = c.back,
                    ref = ""
                )
            )
        }
        return cards
    }
}
