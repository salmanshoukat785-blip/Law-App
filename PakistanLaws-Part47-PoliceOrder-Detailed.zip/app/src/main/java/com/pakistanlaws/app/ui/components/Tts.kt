package com.pakistanlaws.app.ui.components

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import java.util.Locale

/** Reads text aloud with the phone's own text-to-speech voice (works offline if the voice is installed). */
class TtsController(context: Context) {

    var speaking by mutableStateOf(false)
        private set

    private var ready = false
    private var engine: TextToSpeech? = null

    init {
        engine = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}

                    override fun onDone(utteranceId: String?) {
                        if (utteranceId == LAST_ID) speaking = false
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        speaking = false
                    }
                })
            }
        }
    }

    /** Returns false if the voice for the language is missing or the engine is not ready. */
    fun speak(text: String, urdu: Boolean): Boolean {
        val tts = engine ?: return false
        if (!ready) return false
        val locale = if (urdu) Locale("ur") else Locale.ENGLISH
        val result = tts.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            return false
        }
        val chunks = splitIntoChunks(text)
        if (chunks.isEmpty()) return false
        speaking = true
        chunks.forEachIndexed { index, chunk ->
            val id = if (index == chunks.lastIndex) LAST_ID else "part-$index"
            val mode = if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            tts.speak(chunk, mode, null, id)
        }
        return true
    }

    fun stop() {
        engine?.stop()
        speaking = false
    }

    fun shutdown() {
        engine?.stop()
        engine?.shutdown()
        engine = null
        speaking = false
    }

    /** The engine refuses very long input, so the text is read in pieces of at most 3,000 characters. */
    private fun splitIntoChunks(text: String): List<String> {
        val chunks = ArrayList<String>()
        val current = StringBuilder()
        for (paragraph in text.split("\n")) {
            if (paragraph.isBlank()) continue
            if (current.length + paragraph.length + 1 > MAX_CHUNK && current.isNotEmpty()) {
                chunks.add(current.toString())
                current.clear()
            }
            if (paragraph.length > MAX_CHUNK) {
                paragraph.chunked(MAX_CHUNK).forEach { chunks.add(it) }
            } else {
                if (current.isNotEmpty()) current.append(' ')
                current.append(paragraph)
            }
        }
        if (current.isNotEmpty()) chunks.add(current.toString())
        return chunks
    }

    private companion object {
        const val LAST_ID = "last"
        const val MAX_CHUNK = 3000
    }
}

@Composable
fun rememberTts(): TtsController {
    val context = LocalContext.current
    val controller = remember { TtsController(context) }
    DisposableEffect(controller) {
        onDispose { controller.shutdown() }
    }
    return controller
}
