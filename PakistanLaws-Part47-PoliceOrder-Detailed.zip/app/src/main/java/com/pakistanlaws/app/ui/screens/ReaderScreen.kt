package com.pakistanlaws.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pakistanlaws.app.ui.theme.UrduFont
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pakistanlaws.app.R
import com.pakistanlaws.app.data.db.SectionEntity
import com.pakistanlaws.app.content.LawCatalog
import com.pakistanlaws.app.data.db.NoteEntity
import com.pakistanlaws.app.ui.ReaderViewModel
import com.pakistanlaws.app.ui.SettingsViewModel
import com.pakistanlaws.app.ui.StudyViewModel
import com.pakistanlaws.app.ui.components.GUEST_SECTION_LIMIT
import com.pakistanlaws.app.ui.components.LocalIsGuest
import com.pakistanlaws.app.ui.components.LockedScreen
import com.pakistanlaws.app.ui.components.NoteEditorDialog
import com.pakistanlaws.app.ui.components.rememberTts
import com.pakistanlaws.app.ui.theme.Language
import com.pakistanlaws.app.ui.components.UrduTranslator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay

private const val MODE_EASY = 0
private const val MODE_DETAILED = 1

/** What is shown on screen and which voice should read it. */
private data class Shown(val text: String, val urdu: Boolean, val noDetail: Boolean = false)

/** Picks the preferred language, falling back to the other one if it is empty. */
private fun pick(preferUrdu: Boolean, en: String, ur: String): Shown =
    if (preferUrdu && ur.isNotBlank()) Shown(ur, true)
    else if (en.isNotBlank()) Shown(en, false)
    else Shown(ur, true)

private val SECTION_REF = Regex("""(?i)\bsections?\s+""")
private val NUMBER = Regex("""^(\d{1,3}[A-Z]?)(\([A-Za-z0-9]+\))*""")
private val SEPARATOR = Regex("""^(\s*,\s*(and\s+|or\s+)?|\s+and\s+|\s+or\s+)""")

/** Finds section numbers mentioned in a text, for example "sections 4, 5 and 9". */
private fun referencedNumbers(text: String): List<String> {
    val found = LinkedHashSet<String>()
    for (match in SECTION_REF.findAll(text)) {
        var rest = text.substring(match.range.last + 1)
        while (true) {
            val number = NUMBER.find(rest) ?: break
            found.add(number.groupValues[1])
            rest = rest.substring(number.value.length)
            val separator = SEPARATOR.find(rest) ?: break
            rest = rest.substring(separator.value.length)
        }
    }
    return found.toList()
}

@Composable
fun ReaderScreen(
    sectionId: String,
    onBack: () -> Unit,
    vm: ReaderViewModel = viewModel(),
    studyVm: StudyViewModel = viewModel()
) {
    var currentId by rememberSaveable(sectionId) { mutableStateOf(sectionId) }
    LaunchedEffect(currentId) { vm.load(currentId) }

    val section by vm.section.collectAsState()
    val siblings by vm.siblings.collectAsState()
    val bookmarked by vm.bookmarked.collectAsState()
    val inSyllabus by vm.inSyllabus.collectAsState()
    val appUrdu = Language.isUrdu(LocalConfiguration.current)
    var contentUrdu by rememberSaveable { mutableStateOf(appUrdu) }
    var mode by rememberSaveable { mutableIntStateOf(MODE_EASY) }
    val settingsVm: SettingsViewModel = viewModel()
    val appSettings by settingsVm.settings.collectAsState()
    val isGuest = LocalIsGuest.current
    val urduOn = appSettings?.autoUrdu == true && !isGuest
    var retryTick by remember { mutableIntStateOf(0) }
    val scroll = rememberScrollState()
    var editorOpen by remember { mutableStateOf(false) }
    var editingNote by remember { mutableStateOf<NoteEntity?>(null) }
    val tts = rememberTts()
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val ttsMissing = stringResource(R.string.reader_tts_missing)
    val copiedMessage = stringResource(R.string.reader_copied)

    LaunchedEffect(currentId, mode, contentUrdu, urduOn) {
        tts.stop()
        scroll.scrollTo(0)
    }

    // "Not found" is only shown if the section still has not loaded after a moment.
    var waited by remember(currentId) { mutableStateOf(false) }
    LaunchedEffect(currentId) {
        delay(700)
        waited = true
    }

    val s: SectionEntity? = section
    if (isGuest && s != null && s.sortOrder > GUEST_SECTION_LIMIT) {
        LockedScreen(onBack = onBack)
        return
    }
    if (s == null || s.id != currentId) {
        Column(modifier = Modifier.fillMaxSize()) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(R.string.action_back)
                )
            }
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (waited) {
                    Text(
                        text = stringResource(R.string.reader_not_found),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        return
    }

    val index = siblings.indexOfFirst { it.id == s.id }
    val previous = if (index > 0) siblings[index - 1] else null
    val next = if (index >= 0 && index < siblings.lastIndex) siblings[index + 1] else null

    val heading = pick(contentUrdu, s.titleEn, s.titleUr)
    val chapter = pick(contentUrdu, s.chapter, s.chapterUr)
    val shown: Shown = when (mode) {
        MODE_DETAILED -> {
            val long = pick(contentUrdu, s.longEn, s.longUr)
            if (long.text.isBlank()) {
                // No hand-written explanation yet: show nothing in Detailed mode.
                Shown(text = "", urdu = false)
            } else {
                long
            }
        }
        else -> pick(contentUrdu, s.shortEn, s.shortUr)
    }

    val related = remember(s.id, siblings) {
        val byId = siblings.associateBy { it.id }
        referencedNumbers(s.originalText)
            .mapNotNull { byId["${s.lawId}-$it"] }
            .filter { it.id != s.id }
            .take(6)
    }
    // Machine translation to Urdu (ML Kit), only while the Urdu switch is on.
    var urduText by remember(s.id, mode, urduOn) { mutableStateOf<Triple<String, String, String>?>(null) }
    var urduFailed by remember(s.id, mode, urduOn, retryTick) { mutableStateOf(false) }
    LaunchedEffect(s.id, mode, urduOn, retryTick) {
        if (urduOn) {
            try {
                urduText = Triple(
                    UrduTranslator.translate(chapter.text),
                    UrduTranslator.translate(heading.text),
                    UrduTranslator.translate(shown.text)
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                urduFailed = true
            }
        }
    }
    val inUrdu = urduOn && urduText != null
    val chapterText = if (inUrdu) urduText!!.first else chapter.text
    val headingText = if (inUrdu) urduText!!.second else heading.text
    val bodyText = if (inUrdu) urduText!!.third else shown.text
    val urduFamily = UrduFont.family(LocalContext.current)
    fun urduStyle(base: androidx.compose.ui.text.TextStyle) =
        if (inUrdu) base.copy(fontFamily = urduFamily, lineHeight = (base.fontSize.value * 2.0f).sp, textDirection = androidx.compose.ui.text.style.TextDirection.Rtl) else base
    val speakable = (headingText + "\n" + bodyText).replace(Regex("[\u200F\u2066\u2069]"), "")
    val sectionNotes by remember(s.id) { studyVm.notesFor(s.id) }
        .collectAsState(initial = emptyList())
    val allNotes by studyVm.notes.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        // Top bar: back, section label, listen, copy, bookmark
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(R.string.action_back)
                )
            }
            Text(
                text = com.pakistanlaws.app.ui.sectionWord(s.lawId) + " " + s.number,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = {
                if (tts.speaking) {
                    tts.stop()
                } else if (!tts.speak(speakable, shown.urdu || inUrdu)) {
                    Toast.makeText(context, ttsMissing, Toast.LENGTH_LONG).show()
                }
            }) {
                Icon(
                    imageVector = if (tts.speaking) Icons.Filled.Stop else Icons.AutoMirrored.Filled.VolumeUp,
                    contentDescription = stringResource(
                        if (tts.speaking) R.string.reader_stop else R.string.reader_listen
                    )
                )
            }
            IconButton(onClick = {
                clipboard.setText(AnnotatedString(speakable))
                Toast.makeText(context, copiedMessage, Toast.LENGTH_SHORT).show()
            }) {
                Icon(
                    imageVector = Icons.Filled.ContentCopy,
                    contentDescription = stringResource(R.string.reader_copy)
                )
            }
            IconButton(onClick = { vm.toggleSyllabus() }) {
                Icon(
                    imageVector = if (inSyllabus) Icons.Filled.CheckCircle else Icons.Filled.AddCircleOutline,
                    contentDescription = stringResource(
                        if (inSyllabus) R.string.syllabus_remove else R.string.syllabus_add
                    ),
                    tint = MaterialTheme.colorScheme.primary
                )
            }
            IconButton(onClick = { vm.toggleBookmark() }) {
                Icon(
                    imageVector = if (bookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                    contentDescription = stringResource(
                        if (bookmarked) R.string.reader_bookmarked else R.string.reader_bookmark_add
                    ),
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(scroll)
                .padding(horizontal = 16.dp)
        ) {
            CompositionLocalProvider(
                LocalLayoutDirection provides
                    if (inUrdu) LayoutDirection.Rtl else LocalLayoutDirection.current
            ) {
                Text(
                    text = chapterText,
                    style = urduStyle(MaterialTheme.typography.labelMedium),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = headingText,
                    style = urduStyle(MaterialTheme.typography.headlineSmall),
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            if (s.isImportant) {
                Spacer(Modifier.height(8.dp))
                AssistChip(
                    onClick = {},
                    label = { Text(stringResource(R.string.reader_important)) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Filled.Star,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                )
            }
            if (s.needsVerify) {
                Spacer(Modifier.height(8.dp))
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.reader_verify),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            AssistChip(
                onClick = {
                    editingNote = null
                    editorOpen = true
                },
                label = { Text(stringResource(R.string.notes_add)) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Filled.EditNote,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                }
            )

            // Easy / Detailed
            Spacer(Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = mode == MODE_EASY,
                    onClick = { mode = MODE_EASY },
                    label = { Text(stringResource(R.string.reader_easy)) },
                    modifier = Modifier.weight(1f)
                )
                FilterChip(
                    selected = mode == MODE_DETAILED && !isGuest,
                    onClick = { mode = MODE_DETAILED },
                    enabled = !isGuest,
                    label = {
                        Text(stringResource(R.string.reader_detailed) + if (isGuest) "  \uD83D\uDD12" else "")
                    },
                    modifier = Modifier.weight(1f)
                )
            }

            // Urdu translation status (the switch itself is in Settings)
            if (urduOn) {
                Spacer(Modifier.height(8.dp))
                when {
                    urduFailed -> {
                        Text(
                            text = stringResource(R.string.reader_urdu_error),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                        OutlinedButton(onClick = { retryTick++ }) {
                            Text(stringResource(R.string.reader_urdu_retry))
                        }
                    }
                    urduText == null -> Text(
                        text = stringResource(R.string.reader_urdu_loading),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    else -> Unit
                }
            }

            // The text itself: can be selected and copied
            Spacer(Modifier.height(16.dp))
            if (shown.noDetail) {
                Text(
                    text = stringResource(R.string.reader_no_detail),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
            }
            CompositionLocalProvider(
                LocalLayoutDirection provides
                    if (inUrdu) LayoutDirection.Rtl else LocalLayoutDirection.current
            ) {
                SelectionContainer {
                    Text(
                        text = bodyText,
                        style = urduStyle(MaterialTheme.typography.bodyLarge),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            if (related.isNotEmpty()) {
                Spacer(Modifier.height(24.dp))
                Text(
                    text = stringResource(R.string.reader_related),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    related.forEach { other ->
                        AssistChip(
                            onClick = { currentId = other.id },
                            label = { Text(other.number) }
                        )
                    }
                }
            }
            if (sectionNotes.isNotEmpty()) {
                Spacer(Modifier.height(24.dp))
                Text(
                    text = stringResource(R.string.notes_section_notes),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                sectionNotes.forEach { note ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable {
                                editingNote = note
                                editorOpen = true
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = note.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = note.body,
                                style = MaterialTheme.typography.bodyMedium,
                                maxLines = 3,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }

        // Previous / position / next
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            OutlinedButton(
                onClick = { previous?.let { currentId = it.id } },
                enabled = previous != null
            ) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = null)
                Text(stringResource(R.string.reader_previous))
            }
            if (index >= 0) {
                Text(
                    text = stringResource(R.string.reader_page_format, index + 1, siblings.size),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            OutlinedButton(
                onClick = { next?.let { currentId = it.id } },
                enabled = next != null
            ) {
                Text(stringResource(R.string.reader_next))
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
            }
        }
    }

    if (editorOpen) {
        val lawName = LawCatalog.laws.firstOrNull { it.id == s.lawId }?.shortName ?: s.lawId
        val subjectChoices = (allNotes.map { it.subject } + lawName)
            .filter { it.isNotBlank() }
            .distinct()
        NoteEditorDialog(
            existing = editingNote,
            defaultSubject = lawName,
            subjects = subjectChoices,
            onSave = { subject, title, body ->
                studyVm.saveNote(editingNote, s.id, subject, title, body)
                editorOpen = false
            },
            onDelete = editingNote?.let { note ->
                {
                    studyVm.deleteNote(note.id)
                    editorOpen = false
                }
            },
            onDismiss = { editorOpen = false }
        )
    }
}
