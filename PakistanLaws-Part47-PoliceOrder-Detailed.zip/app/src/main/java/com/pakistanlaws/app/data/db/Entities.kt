package com.pakistanlaws.app.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** One law, for example the Punjab Arms Ordinance. */
@Entity(tableName = "laws")
data class LawEntity(
    @PrimaryKey val id: String,
    val titleEn: String,
    val titleUr: String,
    val shortName: String,
    val sortOrder: Int,
    /** A note about which amendments the text includes. */
    val noteEn: String,
    val noteUr: String
)

/** One section, article or rule of a law, with its short and long explanations. */
@Entity(tableName = "sections", indices = [Index("lawId")])
data class SectionEntity(
    @PrimaryKey val id: String,
    val lawId: String,
    val number: String,
    val chapter: String,
    val chapterUr: String,
    val titleEn: String,
    val titleUr: String,
    val shortEn: String,
    val shortUr: String,
    val longEn: String,
    val longUr: String,
    val originalText: String,
    val sortOrder: Int,
    val isImportant: Boolean,
    /** True when the text must still be checked against the official Gazette. */
    val needsVerify: Boolean
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey val sectionId: String,
    val createdAt: Long
)

@Entity(tableName = "notes", indices = [Index("sectionId")])
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sectionId: String?,
    val subject: String,
    val title: String,
    val body: String,
    val createdAt: Long,
    val updatedAt: Long
)

/** Result row for "how many sections does each law have". */
data class LawCount(
    val lawId: String,
    val count: Int
)

/**
 * One multiple-choice question. The four options of each language are stored in one text,
 * separated by a new line, in the same order in both languages.
 */
@Entity(tableName = "questions", indices = [Index("lawId")])
data class QuestionEntity(
    @PrimaryKey val id: String,
    val lawId: String,
    val topicEn: String,
    val topicUr: String,
    /** What kind of question it is, for example punishment or powers and procedure. */
    val typeEn: String,
    val typeUr: String,
    /** True for questions on the most important provisions. */
    val isImportant: Boolean,
    /** 1 = easy, 2 = medium, 3 = hard */
    val difficulty: Int,
    val textEn: String,
    val textUr: String,
    val optionsEn: String,
    val optionsUr: String,
    val correctIndex: Int,
    val explanationEn: String,
    val explanationUr: String,
    val ref: String
)

/** The summary of one finished quiz. [periodKey] is set for daily and weekly challenges. */
@Entity(tableName = "quiz_results", indices = [Index("periodKey")])
data class QuizResultEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val mode: String,
    val lawId: String?,
    val total: Int,
    val correct: Int,
    val wrong: Int,
    val skipped: Int,
    val score: Double,
    val percent: Int,
    val durationSec: Int,
    val finishedAt: Long,
    val periodKey: String
)

/** One answered question, kept so wrong answers can be revised later. */
@Entity(tableName = "answer_records", indices = [Index("questionId")])
data class AnswerRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val questionId: String,
    val correct: Boolean,
    val answeredAt: Long,
    val mode: String
)

/** A flashcard the user made. The front and the back are the same in English and Urdu. */
@Entity(tableName = "custom_cards")
data class CustomCardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val front: String,
    val back: String,
    val createdAt: Long
)

/**
 * Spaced-repetition state of one card. [cardKey] identifies the card, for example
 * "sec:arms-8", "v:cognizable", "q:arms-05" or "c:12". [box] runs from 1 to 5; the higher the
 * box, the longer the gap before the card comes back at [dueAt].
 */
@Entity(tableName = "card_progress")
data class CardProgressEntity(
    @PrimaryKey val cardKey: String,
    val box: Int,
    val dueAt: Long,
    val reps: Int,
    val lapses: Int,
    val lastReviewedAt: Long
)

/** A favourite law ([kind] = "l") or favourite question ([kind] = "q"). [favKey] is kind:itemId. */
@Entity(tableName = "favourites")
data class FavouriteEntity(
    @PrimaryKey val favKey: String,
    val kind: String,
    val itemId: String,
    val createdAt: Long
)

/**
 * A highlighted paragraph of a section. [source] tells which text it belongs to, for example
 * "orig", "easy-en", "detail-ur"; [paragraph] is the position of the paragraph in that text.
 */
@Entity(tableName = "highlights", primaryKeys = ["sectionId", "source", "paragraph"])
data class HighlightEntity(
    val sectionId: String,
    val source: String,
    val paragraph: Int,
    val text: String,
    val createdAt: Long
)
