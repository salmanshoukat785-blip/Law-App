package com.pakistanlaws.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pakistanlaws.app.data.db.AppDatabase
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

class LibraryViewModel(application: Application) : AndroidViewModel(application) {

    private val sections = AppDatabase.get(application).sectionDao()

    /** Law id -> number of sections stored on this phone. */
    val counts: StateFlow<Map<String, Int>> = sections.observeCounts()
        .map { rows -> rows.associate { it.lawId to it.count } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())
}
