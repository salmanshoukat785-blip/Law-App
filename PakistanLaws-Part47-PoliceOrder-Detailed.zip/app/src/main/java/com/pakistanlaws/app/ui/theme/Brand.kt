package com.pakistanlaws.app.ui.theme

import androidx.compose.ui.graphics.Color

/** Fixed brand colours used on the splash screen and the logo. */
object Brand {
    val Green = Color(0xFF0B3D2E)
    val DeepGreen = Color(0xFF06241B)
    val Gold = Color(0xFFD4AF37)
    val Mist = Color(0xFFB7C9C0)
}
