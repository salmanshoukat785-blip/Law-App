package com.pakistanlaws.app.content

/**
 * Legal terms for the Vocabulary flashcards. Each meaning follows the definition given in the law
 * that is named in [ref] (checked against the uploaded text of that law).
 */
data class VocabTerm(
    val id: String,
    val termEn: String,
    val termUr: String,
    val meaningEn: String,
    val meaningUr: String,
    val ref: String
)

object VocabCards {
    val terms = listOf(
        VocabTerm(
            "cognizable", "Cognizable offence", "قابلِ دست اندازی جرم",
            "An offence for which a police officer may arrest without a warrant.",
            "ایسا جرم جس میں پولیس افسر بغیر وارنٹ گرفتار کر سکتا ہے۔",
            "CrPC s.4(1)(f)"
        ),
        VocabTerm(
            "bailable", "Bailable offence", "قابلِ ضمانت جرم",
            "An offence shown as bailable in the Second Schedule, or made bailable by another law.",
            "ایسا جرم جسے دوسرے شیڈول میں قابلِ ضمانت دکھایا گیا ہو یا کسی اور قانون نے قابلِ ضمانت بنایا ہو۔",
            "CrPC s.4(1)(b)"
        ),
        VocabTerm(
            "nonbailable", "Non-bailable offence", "ناقابلِ ضمانت جرم",
            "Any offence that is not bailable.",
            "ہر وہ جرم جو قابلِ ضمانت نہ ہو۔",
            "CrPC s.4(1)(b)"
        ),
        VocabTerm(
            "complaint", "Complaint", "استغاثہ (شکایت)",
            "An allegation made, orally or in writing, to a Magistrate that some person has committed an offence, so that he may take action. It does not include a police officer’s report.",
            "مجسٹریٹ کو زبانی یا تحریری طور پر دی گئی وہ اطلاع کہ کسی شخص نے جرم کیا ہے تاکہ وہ کارروائی کرے۔ اس میں پولیس افسر کی رپورٹ شامل نہیں۔",
            "CrPC s.4(1)(h)"
        ),
        VocabTerm(
            "investigation", "Investigation", "تفتیش",
            "All the proceedings under the Code for collecting evidence, conducted by a police officer or by a person (other than a Magistrate) authorised by a Magistrate.",
            "ضابطے کے تحت شہادت جمع کرنے کی تمام کارروائی، جو پولیس افسر یا مجسٹریٹ کے مجاز کردہ کسی شخص (مجسٹریٹ کے سوا) کی جانب سے ہو۔",
            "CrPC s.4(1)(l)"
        ),
        VocabTerm(
            "fir", "First Information Report (FIR)", "ابتدائی اطلاعی رپورٹ (ایف آئی آر)",
            "Information about a cognizable offence given to the officer in charge of a police station, written down and signed by the person giving it.",
            "قابلِ دست اندازی جرم کی وہ اطلاع جو تھانے کے انچارج کو دی جائے، تحریر کی جائے اور دینے والا اس پر دستخط کرے۔",
            "CrPC s.154"
        ),
        VocabTerm(
            "qatl", "Qatl", "قتل",
            "Causing the death of a person.",
            "کسی شخص کی موت کا سبب بننا۔",
            "PPC s.299(j)"
        ),
        VocabTerm(
            "qisas", "Qisas", "قصاص",
            "Punishment by causing similar hurt at the same part of the body of the convict as he caused to the victim, or by causing his death if he committed qatl-i-amd, in exercise of the right of the victim or a Wali.",
            "مجرم کو اسی عضو پر ویسی ہی چوٹ پہنچانے کی سزا جیسی اس نے مظلوم کو پہنچائی، یا قتلِ عمد کی صورت میں اسے قتل کرنے کی سزا، جو مظلوم یا ولی کے حق کے استعمال میں دی جائے۔",
            "PPC s.299(k)"
        ),
        VocabTerm(
            "diyat", "Diyat", "دیت",
            "The compensation specified in section 323, payable to the heirs of the victim.",
            "دفعہ 323 میں مقرر کردہ معاوضہ جو مقتول کے ورثا کو ادا کیا جائے۔",
            "PPC s.299(e)"
        ),
        VocabTerm(
            "arsh", "Arsh", "ارش",
            "The compensation specified in the Chapter, to be paid to the victim or his heirs.",
            "اس باب میں مقرر کردہ معاوضہ جو مظلوم یا اس کے ورثا کو ادا کیا جائے۔",
            "PPC s.299(b)"
        ),
        VocabTerm(
            "daman", "Daman", "ضمان",
            "The compensation determined by the Court, to be paid by the offender to the victim for causing hurt not liable to arsh.",
            "عدالت کا مقرر کردہ معاوضہ جو مجرم مظلوم کو ایسی چوٹ پہنچانے پر ادا کرے جس پر ارش واجب نہ ہو۔",
            "PPC s.299(d)"
        ),
        VocabTerm(
            "tazir", "Ta’zir", "تعزیر",
            "Punishment other than qisas, diyat, arsh or daman.",
            "قصاص، دیت، ارش یا ضمان کے سوا کوئی سزا۔",
            "PPC s.299(l)"
        ),
        VocabTerm(
            "wali", "Wali", "ولی",
            "A person entitled to claim qisas.",
            "وہ شخص جو قصاص کا دعویٰ کرنے کا حق رکھتا ہو۔",
            "PPC s.299(m)"
        ),
        VocabTerm(
            "hadd", "Hadd", "حد",
            "Punishment ordained by the Holy Quran or Sunnah.",
            "قرآنِ پاک یا سنت کی مقرر کردہ سزا۔",
            "Hadd Order Art. 2(f)"
        ),
        VocabTerm(
            "ikrah", "Ikrah", "اکراہ",
            "Putting any person in fear of injury to the person, property or honour of that or any other person.",
            "کسی شخص کو اپنی یا کسی اور کی جان، مال یا عزت کو نقصان کے خوف میں ڈالنا۔",
            "Hadd Order Art. 6"
        ),
        VocabTerm(
            "iztirar", "Iztirar", "اضطرار",
            "A situation in which a person fears death because of extreme hunger or thirst or serious illness.",
            "ایسی صورتِ حال جس میں شخص شدید بھوک، پیاس یا سنگین بیماری سے موت کا خوف محسوس کرے۔",
            "Hadd Order Art. 6"
        ),
        VocabTerm(
            "tazkiyah", "Tazkiyah al-shuhood", "تزکیۃ الشہود",
            "The mode of inquiry a Court adopts to satisfy itself about the credibility of a witness.",
            "وہ طریقۂ تحقیق جس سے عدالت کسی گواہ کی معتبریت کے بارے میں مطمئن ہوتی ہے۔",
            "Hadd Order Art. 9"
        ),
        VocabTerm(
            "flickknife", "Flick-knife", "فلک نائف",
            "A knife whose blade opens automatically by hand pressure on a button, spring or other device, or is released by gravity or centrifugal force and locked in place.",
            "ایسا چاقو جس کی دھار بٹن، سپرنگ یا کسی اور آلے پر ہاتھ کے دباؤ سے خود بخود کھلے، یا کشش ثقل یا مرکز گریز قوت سے کھل کر اپنی جگہ لاک ہو جائے۔",
            "Arms Ordinance s.3(1)(dd)"
        ),
        VocabTerm(
            "militarystores", "Military stores", "فوجی سامان",
            "Stores that the Federal Government declares, by notification in the official Gazette, to be military stores.",
            "وہ سامان جسے وفاقی حکومت سرکاری گزٹ میں نوٹیفکیشن کے ذریعے فوجی سامان قرار دے۔",
            "Arms Ordinance s.3(1)(f)"
        ),
        VocabTerm(
            "prohibitedbore", "Prohibited bore", "ممنوعہ بور",
            "A description, calibre or bore of arms that the Government specifies by notification as prohibited. Licences for these are issued only by the Government.",
            "اسلحے کی وہ قسم، کیلیبر یا بور جسے حکومت نوٹیفکیشن کے ذریعے ممنوعہ قرار دے۔ ان کے لائسنس صرف حکومت جاری کرتی ہے۔",
            "Arms Ordinance s.11A"
        ),
        VocabTerm(
            "controlleddelivery", "Controlled delivery", "کنٹرولڈ ڈیلیوری",
            "Allowing illicit or suspect consignments of narcotics to pass out of, through or into Pakistan, with the knowledge and under the supervision of the Federal Government, to identify the persons involved.",
            "ممنوعہ یا مشتبہ منشیات کی کھیپ کو وفاقی حکومت کے علم اور نگرانی میں پاکستان سے باہر، اندر یا گزرنے دینا تاکہ ملوث افراد کی شناخت ہو سکے۔",
            "CNSA s.2(j)"
        ),
        VocabTerm(
            "freezing", "Freezing (of assets)", "اثاثوں کی منجمدی",
            "Prohibiting, by an order of the Special Court or an authorized officer, the transfer, conversion, disposal or movement of any assets.",
            "خصوصی عدالت یا مجاز افسر کے حکم سے کسی اثاثے کی منتقلی، تبدیلی، نکاسی یا نقل و حرکت پر پابندی لگانا۔",
            "CNSA s.2(o)"
        ),
        VocabTerm(
            "tracing", "Tracing (of assets)", "اثاثوں کا سراغ",
            "Finding out the true nature, source, disposition, movement or ownership of assets.",
            "اثاثوں کی اصل نوعیت، ماخذ، نکاسی، نقل و حرکت یا ملکیت کا پتا لگانا۔",
            "CNSA s.2(zd)"
        ),
        VocabTerm(
            "addict", "Addict", "عادی نشہ باز",
            "A person physically or mentally dependent on a narcotic drug or psychotropic substance, or who habitually uses them.",
            "وہ شخص جو کسی منشیات یا نفسیاتی مادے پر جسمانی یا ذہنی طور پر انحصار کرتا ہو یا انہیں عادتاً استعمال کرتا ہو۔",
            "CNSA s.2(a)"
        ),
        VocabTerm(
            "phooka", "Phooka (doom dev)", "پھوکا",
            "Any process of introducing air or any substance into the female organ of a milch animal in order to draw off a secretion of milk.",
            "دودھ دینے والے جانور کے مادہ عضو میں ہوا یا کوئی چیز داخل کرنے کا ہر عمل تاکہ دودھ نکالا جا سکے۔",
            "Animals Act s.2(3)"
        )
    )
}
