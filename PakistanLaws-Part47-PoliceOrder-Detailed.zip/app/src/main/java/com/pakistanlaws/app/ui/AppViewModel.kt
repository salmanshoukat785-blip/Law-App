package com.pakistanlaws.app.ui

import android.app.Application
import androidx.annotation.StringRes
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.firestore.FirebaseFirestoreException
import com.pakistanlaws.app.R
import com.pakistanlaws.app.data.AuthRepository
import com.pakistanlaws.app.data.ContentImporter
import com.pakistanlaws.app.data.PhoneUtil
import com.pakistanlaws.app.data.DeviceLimitException
import com.pakistanlaws.app.data.Prefs
import com.pakistanlaws.app.data.PrefsSnapshot
import com.pakistanlaws.app.data.STATUS_APPROVED
import com.pakistanlaws.app.data.STATUS_REJECTED
import com.pakistanlaws.app.data.UserProfile
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = Prefs(application)
    private val repo = AuthRepository(application)

    private val _session = MutableStateFlow<Session>(Session.Loading)
    val session: StateFlow<Session> = _session.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _error = MutableStateFlow<Int?>(null)
    val error: StateFlow<Int?> = _error.asStateFlow()

    /** Starts as true so the quick tour never flashes before the saved value is read. */
    val guideSeen: StateFlow<Boolean> = prefs.flow
        .map { it.guideSeen }
        .stateIn(viewModelScope, SharingStarted.Eagerly, true)

    val firebaseReady: Boolean get() = repo.isConfigured

    private var watchJob: Job? = null

    init {
        viewModelScope.launch {
            val snap = prefs.snapshot()
            _session.value = if (!snap.onboardingDone) Session.NeedsOnboarding else resolve(snap)
        }
    }

    init {
        // Load the built-in law texts into the database (only does work the first time).
        viewModelScope.launch(Dispatchers.IO) {
            try {
                ContentImporter.importIfNeeded(getApplication())
            } catch (e: Exception) {
                // The app still works without the laws; they will be retried next start.
            }
        }
    }

    private suspend fun resolve(snap: PrefsSnapshot): Session {
        val uid = repo.currentUid()
        if (uid != null) {
            val profile = try {
                withTimeout(10_000) { repo.fetchProfile(uid) }
            } catch (e: CancellationException) {
                if (e is TimeoutCancellationException) null else throw e
            } catch (e: DeviceLimitException) {
                prefs.clearAccount()
                _error.value = R.string.err_device_limit
                return Session.NeedsAuth
            } catch (e: Exception) {
                null
            }
            if (profile != null) {
                prefs.cacheProfile(profile)
                return profile.toSession()
            }
            // Offline: fall back to the last status saved on this phone.
            if (snap.cachedUid == uid && snap.cachedStatus.isNotEmpty()) {
                return UserProfile(uid, snap.cachedName, snap.cachedPhone, snap.cachedStatus).toSession()
            }
            return Session.NeedsAuth
        }
        if (snap.guestName.isNotBlank()) return Session.Active(snap.guestName, isGuest = true)
        return Session.NeedsAuth
    }

    fun completeOnboarding() {
        viewModelScope.launch {
            prefs.setOnboardingDone()
            if (_session.value is Session.NeedsOnboarding) _session.value = Session.NeedsAuth
        }
    }

    fun clearError() {
        _error.value = null
    }

    fun continueAsGuest(name: String) {
        val trimmed = name.trim()
        if (trimmed.length < 2) return fail(R.string.err_name)
        _error.value = null
        viewModelScope.launch {
            prefs.setGuestName(trimmed)
            _session.value = Session.Active(trimmed, isGuest = true)
        }
    }

    fun signUp(name: String, phoneInput: String, pin: String, confirmPin: String) {
        val trimmed = name.trim()
        if (trimmed.length < 2) return fail(R.string.err_name)
        val phone = PhoneUtil.normalize(phoneInput) ?: return fail(R.string.err_phone)
        if (pin.length != 6) return fail(R.string.err_pin)
        if (pin != confirmPin) return fail(R.string.err_pin_match)
        if (!repo.isConfigured) return fail(R.string.err_not_configured)

        _error.value = null
        viewModelScope.launch {
            _busy.value = true
            try {
                val profile = repo.signUp(trimmed, phone, pin)
                prefs.cacheProfile(profile)
                _session.value = profile.toSession()
            } catch (e: Exception) {
                repo.signOut()
                _error.value = mapError(e)
            } finally {
                _busy.value = false
            }
        }
    }

    fun signIn(phoneInput: String, pin: String) {
        val phone = PhoneUtil.normalize(phoneInput) ?: return fail(R.string.err_phone)
        if (pin.length != 6) return fail(R.string.err_pin)
        if (!repo.isConfigured) return fail(R.string.err_not_configured)

        _error.value = null
        viewModelScope.launch {
            _busy.value = true
            try {
                val profile = repo.signIn(phone, pin)
                prefs.cacheProfile(profile)
                _session.value = profile.toSession()
            } catch (e: Exception) {
                _error.value = mapError(e)
            } finally {
                _busy.value = false
            }
        }
    }

    fun signOut() {
        watchJob?.cancel()
        viewModelScope.launch {
            try {
                withTimeout(5_000) { repo.releaseDevice() }
            } catch (e: CancellationException) {
                if (e !is TimeoutCancellationException) throw e
            } catch (e: Exception) {
                // Offline: the account stays tied to this phone until the next log out.
            }
            repo.signOut()
            prefs.clearAccount()
            _error.value = null
            _session.value = Session.NeedsAuth
        }
    }

    /** Listens for the admin changing this account's status. */
    fun watchApproval() {
        val current = _session.value
        if (current !is Session.Pending && current !is Session.Rejected) return
        val uid = repo.currentUid() ?: return
        watchJob?.cancel()
        watchJob = viewModelScope.launch {
            repo.observeProfile(uid).collect { profile ->
                if (profile != null) {
                    prefs.cacheProfile(profile)
                    _session.value = profile.toSession()
                }
            }
        }
    }

    fun stopWatching() {
        watchJob?.cancel()
    }

    fun refreshStatus() {
        val uid = repo.currentUid() ?: return
        viewModelScope.launch {
            _busy.value = true
            try {
                val profile = repo.fetchProfile(uid)
                prefs.cacheProfile(profile)
                _session.value = profile.toSession()
                _error.value = null
            } catch (e: Exception) {
                _error.value = mapError(e)
            } finally {
                _busy.value = false
            }
        }
    }

    fun markGuideSeen() {
        viewModelScope.launch { prefs.setGuideSeen() }
    }

    private fun fail(@StringRes message: Int) {
        _error.value = message
    }

    @StringRes
    private fun mapError(e: Exception): Int = when (e) {
        is DeviceLimitException -> R.string.err_device_limit
        is FirebaseAuthUserCollisionException -> R.string.err_phone_exists
        is FirebaseAuthInvalidUserException,
        is FirebaseAuthInvalidCredentialsException -> R.string.err_wrong_credentials
        is FirebaseNetworkException -> R.string.err_network
        is FirebaseTooManyRequestsException -> R.string.err_too_many
        is FirebaseFirestoreException ->
            if (e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                R.string.err_permission
            } else {
                R.string.err_network
            }
        else -> R.string.err_generic
    }
}

private fun UserProfile.toSession(): Session = when (status) {
    STATUS_APPROVED -> Session.Active(
        name = name.ifBlank { PhoneUtil.display(phone) },
        isGuest = false,
        phone = PhoneUtil.display(phone)
    )
    STATUS_REJECTED -> Session.Rejected(this)
    else -> Session.Pending(this)
}
