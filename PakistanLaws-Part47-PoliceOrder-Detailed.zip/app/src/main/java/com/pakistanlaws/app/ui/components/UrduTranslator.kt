package com.pakistanlaws.app.ui.components

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.tasks.await
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalConfiguration
import com.pakistanlaws.app.ui.theme.Language

/**
 * English to Urdu machine translation with Google ML Kit.
 * The Urdu language pack (about 30 MB) is downloaded once, which needs the internet.
 * After that it also works offline.
 */
object UrduTranslator {
    private val translator by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.URDU)
                .build()
        )
    }

    private val cache = HashMap<String, String>()

    fun cached(text: String): String? = cache[text]
    private var modelReady = false

    private suspend fun ensureModel() {
        if (modelReady) return
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
        modelReady = true
    }

    private val latinRun = Regex("[A-Za-z0-9][A-Za-z0-9 .,'’\\-/&%()]*[A-Za-z0-9.)%]|[A-Za-z0-9]")

    /**
     * Urdu with English words, section numbers and brackets mixed in can display out of order.
     * Every paragraph starts as right-to-left, and each English or numeric run is isolated so it
     * stays together as one block in the right place.
     */
    private fun fixBidi(text: String): String = text.split("\n").joinToString("\n") { line ->
        if (line.isBlank()) line
        else "\u200F" + latinRun.replace(line) { "\u2066" + it.value + "\u2069" }
    }

    /** Splits a long text into pieces of at most [limit] characters at sentence ends. */
    private fun chunks(line: String, limit: Int = 400): List<String> {
        if (line.length <= limit) return listOf(line)
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (part in line.split(Regex("(?<=[.;:])\\s+"))) {
            if (sb.isNotEmpty() && sb.length + part.length + 1 > limit) {
                out.add(sb.toString())
                sb.clear()
            }
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(part)
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return out
    }

    /** Translates [text]; paragraph breaks are kept. Throws if the pack cannot be downloaded. */
    suspend fun translate(text: String): String {
        if (text.isBlank()) return text
        cache[text]?.let { return it }
        ensureModel()
        val lines = ArrayList<String>()
        for (line in text.split("\n")) {
            if (line.isBlank()) {
                lines.add(line)
            } else {
                val pieces = ArrayList<String>()
                for (chunk in chunks(line.trim())) {
                    pieces.add(translator.translate(chunk).await())
                }
                lines.add(pieces.joinToString(" "))
            }
        }
        val result = fixBidi(lines.joinToString("\n"))
        cache[text] = result
        return result
    }
}

/**
 * Headings and titles that exist only in English. When the app is in Urdu (and the user is not a
 * guest) the text is machine-translated and shown in Urdu; until it is ready, or if it fails
 * (for example no internet for the first download), the English text stays on screen.
 */
@Composable
fun rememberUrdu(text: String): String {
    val on = Language.isUrdu(LocalConfiguration.current) && !LocalIsGuest.current && text.isNotBlank()
    var out by remember(text, on) { mutableStateOf(if (on) UrduTranslator.cached(text) ?: text else text) }
    LaunchedEffect(text, on) {
        if (on && UrduTranslator.cached(text) == null) {
            out = runCatching { UrduTranslator.translate(text) }.getOrDefault(text)
        }
    }
    return out
}
