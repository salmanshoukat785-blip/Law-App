package com.pakistanlaws.app.ui

import com.pakistanlaws.app.data.UserProfile

/** Where the user currently is in the app's life cycle. */
sealed interface Session {
    data object Loading : Session
    data object NeedsOnboarding : Session
    data object NeedsAuth : Session
    data class Pending(val profile: UserProfile) : Session
    data class Rejected(val profile: UserProfile) : Session
    data class Active(
        val name: String,
        val isGuest: Boolean,
        val phone: String = ""
    ) : Session
}
