package com.pakistanlaws.app.ui

import androidx.annotation.StringRes
import com.pakistanlaws.app.R
import com.pakistanlaws.app.data.db.QuestionEntity

/**
 * The ways to take a quiz.
 * [negativeMarking] is the mark lost for each wrong answer, [secondsPerQuestionTotal] gives an
 * overall timer (questions x seconds), [secondsPerQuestion] gives a timer for each question.
 */
enum class QuizMode(
    @StringRes val titleRes: Int,
    @StringRes val descRes: Int,
    val instantFeedback: Boolean,
    val negativeMarking: Double,
    val secondsPerQuestionTotal: Int,
    val secondsPerQuestion: Int,
    val lives: Int
) {
    PRACTICE(R.string.mode_practice, R.string.mode_practice_desc, true, 0.0, 0, 0, 0),
    RANDOM(R.string.mode_random, R.string.mode_random_desc, true, 0.0, 0, 0, 0),
    SELF_TEST(R.string.mode_self, R.string.mode_self_desc, false, 0.0, 0, 0, 0),
    EXAM(R.string.mode_exam, R.string.mode_exam_desc, false, 0.25, 60, 0, 0),
    SPEED(R.string.mode_speed, R.string.mode_speed_desc, true, 0.0, 0, 15, 0),
    SURVIVAL(R.string.mode_survival, R.string.mode_survival_desc, true, 0.0, 0, 0, 3),
    DAILY(R.string.quiz_daily_title, R.string.quiz_daily_desc, true, 0.0, 0, 0, 0),
    WEEKLY(R.string.quiz_weekly_title, R.string.quiz_weekly_desc, false, 0.25, 60, 0, 0)
}

/** What the user chose on the setup screen. [lawId], [topic] and [difficulty] are null for "all". */
data class QuizConfig(
    val mode: QuizMode,
    val lawId: String? = null,
    val topic: String? = null,
    val difficulty: Int? = null,
    val count: Int = 10,
    /** When set, only these questions are used (for example the wrong answers or a filtered list). */
    val questionIds: List<String>? = null,
    /** Ready-made questions (for example the ones built from the user's syllabus); filters are ignored. */
    val custom: List<QuestionEntity>? = null
)

/** A finished quiz, with everything the result screen needs. */
data class QuizOutcome(
    val total: Int,
    val correct: Int,
    val wrong: Int,
    val skipped: Int,
    val score: Double,
    val percent: Int,
    val durationSec: Int,
    val questions: List<QuestionEntity>,
    val answers: Map<Int, Int>
)

/** The quiz that is running (or has just finished). */
data class QuizState(
    val config: QuizConfig,
    val questions: List<QuestionEntity>,
    val index: Int = 0,
    /** Question position -> chosen option. */
    val answers: Map<Int, Int> = emptyMap(),
    /** True once the current question is answered and its feedback is on screen. */
    val locked: Boolean = false,
    val secondsLeft: Int = 0,
    val lives: Int = 0,
    val loading: Boolean = false,
    val outcome: QuizOutcome? = null
)

fun QuestionEntity.text(urdu: Boolean): String =
    if (urdu && textUr.isNotBlank()) textUr else textEn

fun QuestionEntity.options(urdu: Boolean): List<String> =
    (if (urdu && optionsUr.isNotBlank()) optionsUr else optionsEn).split("\n")

fun QuestionEntity.explanation(urdu: Boolean): String =
    if (urdu && explanationUr.isNotBlank()) explanationUr else explanationEn

fun QuestionEntity.type(urdu: Boolean): String =
    if (urdu && typeUr.isNotBlank()) typeUr else typeEn

fun QuestionEntity.topic(urdu: Boolean): String =
    if (urdu && topicUr.isNotBlank()) topicUr else topicEn

/** The same question with its four options in a new order (the correct index is adjusted). */
fun QuestionEntity.withShuffledOptions(random: kotlin.random.Random): QuestionEntity {
    val en = optionsEn.split("\n")
    val ur = optionsUr.split("\n")
    if (en.size != 4 || ur.size != 4) return this
    val order = listOf(0, 1, 2, 3).shuffled(random)
    return copy(
        optionsEn = order.joinToString("\n") { en[it] },
        optionsUr = order.joinToString("\n") { ur[it] },
        correctIndex = order.indexOf(correctIndex)
    )
}
