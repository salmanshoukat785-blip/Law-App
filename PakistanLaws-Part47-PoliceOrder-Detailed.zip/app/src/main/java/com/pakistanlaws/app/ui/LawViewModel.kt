package com.pakistanlaws.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pakistanlaws.app.data.db.AppDatabase
import com.pakistanlaws.app.data.db.LawEntity
import com.pakistanlaws.app.data.db.SectionEntity
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn

@OptIn(ExperimentalCoroutinesApi::class)
class LawViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.get(application)
    private val lawId = MutableStateFlow("")

    val law: StateFlow<LawEntity?> = lawId
        .flatMapLatest { db.lawDao().observeLaw(it) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val sections: StateFlow<List<SectionEntity>> = lawId
        .flatMapLatest { db.sectionDao().observeByLaw(it) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun load(id: String) {
        lawId.value = id
    }
}
