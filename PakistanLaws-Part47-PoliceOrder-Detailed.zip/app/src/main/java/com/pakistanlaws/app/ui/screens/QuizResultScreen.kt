package com.pakistanlaws.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.pakistanlaws.app.R
import com.pakistanlaws.app.ui.QuizMode
import com.pakistanlaws.app.ui.QuizViewModel
import com.pakistanlaws.app.ui.explanation
import com.pakistanlaws.app.ui.options
import com.pakistanlaws.app.ui.text
import com.pakistanlaws.app.ui.theme.Language

private fun formatScore(score: Double): String =
    if (score % 1.0 == 0.0) score.toInt().toString() else String.format(java.util.Locale.US, "%.2f", score)

/** The exam result screen: score, summary and a review of every answer with its explanation. */
@Composable
fun QuizResultScreen(
    vm: QuizViewModel,
    onRetry: () -> Unit,
    onBack: () -> Unit
) {
    val state by vm.state.collectAsState()
    val s = state
    val outcome = s?.outcome
    val appUrdu = Language.isUrdu(LocalConfiguration.current)
    var urdu by rememberSaveable { mutableStateOf(appUrdu) }

    if (s == null || outcome == null) {
        Box(modifier = Modifier.fillMaxSize())
        return
    }

    val mode = s.config.mode
    val canRetry = mode != QuizMode.DAILY && mode != QuizMode.WEEKLY
    val message = when {
        outcome.percent >= 80 -> R.string.result_excellent
        outcome.percent >= 60 -> R.string.result_good
        outcome.percent >= 40 -> R.string.result_fair
        else -> R.string.result_low
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp)
    ) {
        item {
            Text(
                text = stringResource(R.string.result_title) + " · " + stringResource(mode.titleRes),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(16.dp))
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    progress = { 1f },
                    modifier = Modifier.size(140.dp),
                    strokeWidth = 12.dp,
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
                )
                CircularProgressIndicator(
                    progress = { outcome.percent / 100f },
                    modifier = Modifier.size(140.dp),
                    strokeWidth = 12.dp,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = outcome.percent.toString() + "%",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(12.dp))
            Text(
                text = stringResource(message),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatBox(R.string.result_correct, outcome.correct, Modifier.weight(1f))
                StatBox(R.string.result_wrong, outcome.wrong, Modifier.weight(1f))
                StatBox(R.string.result_skipped, outcome.skipped, Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            Text(
                text = stringResource(R.string.result_score_format, formatScore(outcome.score)) +
                    "   ·   " +
                    stringResource(
                        R.string.result_time_format,
                        outcome.durationSec / 60,
                        outcome.durationSec % 60
                    ),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (canRetry) {
                    Button(onClick = onRetry, modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.result_retry))
                    }
                }
                OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.result_back))
                }
            }
            Spacer(Modifier.height(20.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = stringResource(R.string.result_review),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        itemsIndexed(outcome.questions) { i, question ->
            val chosen = outcome.answers[i]
            val options = question.options(urdu)
            val correct = chosen == question.correctIndex
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(
                            imageVector = when {
                                chosen == null -> Icons.Filled.Remove
                                correct -> Icons.Filled.Check
                                else -> Icons.Filled.Close
                            },
                            contentDescription = null,
                            tint = when {
                                chosen == null -> MaterialTheme.colorScheme.outline
                                correct -> MaterialTheme.colorScheme.primary
                                else -> MaterialTheme.colorScheme.error
                            }
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = (i + 1).toString() + ". " + question.text(urdu),
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = stringResource(
                            R.string.result_your_answer_format,
                            if (chosen != null) options[chosen] else stringResource(R.string.result_not_answered)
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (chosen == null || !correct) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.primary
                    )
                    if (!correct) {
                        Text(
                            text = stringResource(
                                R.string.play_correct_answer_format,
                                options[question.correctIndex]
                            ),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = question.explanation(urdu),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = question.ref,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun StatBox(labelRes: Int, value: Int, modifier: Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value.toString(),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            Text(
                text = stringResource(labelRes),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }
}
