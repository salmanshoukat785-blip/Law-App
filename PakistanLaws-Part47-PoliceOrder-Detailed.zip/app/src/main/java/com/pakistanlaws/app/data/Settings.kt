package com.pakistanlaws.app.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.pakistanlaws.app.ui.theme.AppPalette
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "pakistan_laws_settings")

enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Everything the user can change in Settings > Appearance. Language is stored by AppCompat. */
data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val palette: AppPalette = AppPalette.EMERALD,
    val fontScale: Float = 1f,
    val accessibility: Boolean = false,
    val animations: Boolean = true,
    val autoUrdu: Boolean = false
)

private val KEY_THEME_MODE = stringPreferencesKey("theme_mode")
private val KEY_PALETTE = stringPreferencesKey("palette")
private val KEY_FONT_SCALE = floatPreferencesKey("font_scale")
private val KEY_ACCESSIBILITY = booleanPreferencesKey("accessibility")
private val KEY_ANIMATIONS = booleanPreferencesKey("animations")
private val KEY_AUTO_URDU = booleanPreferencesKey("auto_urdu")

class SettingsStore(context: Context) {
    private val store = context.applicationContext.settingsDataStore

    private fun Preferences.toSettings() = AppSettings(
        themeMode = runCatching { ThemeMode.valueOf(this[KEY_THEME_MODE] ?: "") }
            .getOrDefault(ThemeMode.SYSTEM),
        palette = runCatching { AppPalette.valueOf(this[KEY_PALETTE] ?: "") }
            .getOrDefault(AppPalette.EMERALD),
        fontScale = (this[KEY_FONT_SCALE] ?: 1f).coerceIn(0.85f, 1.4f),
        accessibility = this[KEY_ACCESSIBILITY] ?: false,
        animations = this[KEY_ANIMATIONS] ?: true,
        autoUrdu = this[KEY_AUTO_URDU] ?: false
    )

    val flow: Flow<AppSettings> = store.data.map { it.toSettings() }

    suspend fun setThemeMode(mode: ThemeMode) {
        store.edit { it[KEY_THEME_MODE] = mode.name }
    }

    suspend fun setPalette(palette: AppPalette) {
        store.edit { it[KEY_PALETTE] = palette.name }
    }

    suspend fun setFontScale(scale: Float) {
        store.edit { it[KEY_FONT_SCALE] = scale.coerceIn(0.85f, 1.4f) }
    }

    suspend fun setAccessibility(enabled: Boolean) {
        store.edit { it[KEY_ACCESSIBILITY] = enabled }
    }

    suspend fun setAnimations(enabled: Boolean) {
        store.edit { it[KEY_ANIMATIONS] = enabled }
    }

    suspend fun setAutoUrdu(enabled: Boolean) {
        store.edit { it[KEY_AUTO_URDU] = enabled }
    }
}
