package com.pakistanlaws.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pakistanlaws.app.data.HomeStore
import com.pakistanlaws.app.data.db.AnswerRecordEntity
import com.pakistanlaws.app.data.db.AppDatabase
import com.pakistanlaws.app.data.db.QuestionEntity
import com.pakistanlaws.app.data.db.QuizResultEntity
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.temporal.IsoFields
import kotlin.math.ceil
import kotlin.math.roundToInt
import kotlin.random.Random

@OptIn(ExperimentalCoroutinesApi::class)
class QuizViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.get(application)
    private val home = HomeStore(application)

    /** Every question on this phone (used by the setup screen to count matches). */
    val bank: StateFlow<List<QuestionEntity>> = db.questionDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val recent: StateFlow<List<QuizResultEntity>> = db.quizResultDao().observeRecent()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** The result of today's daily challenge, or null if it has not been done. */
    val dailyDone: StateFlow<QuizResultEntity?> = db.quizResultDao().observeByPeriod(dailyKey())
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val weeklyDone: StateFlow<QuizResultEntity?> = db.quizResultDao().observeByPeriod(weeklyKey())
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    private val _state = MutableStateFlow<QuizState?>(null)
    val state: StateFlow<QuizState?> = _state.asStateFlow()

    private var timerJob: Job? = null
    private var startedAt = 0L

    // ---- starting ----

    fun start(config: QuizConfig) {
        timerJob?.cancel()
        _state.value = QuizState(config = config, questions = emptyList(), loading = true)
        viewModelScope.launch {
            val all = db.questionDao().getAll()
            val allowed = config.questionIds?.toSet()
            val matching = config.custom ?: all.filter { q ->
                (allowed == null || q.id in allowed) &&
                    (config.lawId == null || q.lawId == config.lawId) &&
                    (config.topic == null || q.topicEn == config.topic) &&
                    (config.difficulty == null || q.difficulty == config.difficulty)
            }
            val random = when (config.mode) {
                QuizMode.DAILY -> Random(dailyKey().hashCode().toLong())
                QuizMode.WEEKLY -> Random(weeklyKey().hashCode().toLong())
                else -> Random.Default
            }
            val picked = matching
                .shuffled(random)
                .take(config.count)
                .map { it.withShuffledOptions(random) }

            startedAt = System.currentTimeMillis()
            val mode = config.mode
            val seconds = if (mode.secondsPerQuestionTotal > 0) {
                picked.size * mode.secondsPerQuestionTotal
            } else {
                mode.secondsPerQuestion
            }
            _state.value = QuizState(
                config = config,
                questions = picked,
                secondsLeft = seconds,
                lives = mode.lives
            )
            if (picked.isNotEmpty()) startTimer()
        }
    }

    fun retry() {
        val config = _state.value?.config ?: return
        start(config)
    }

    /** Throws the running quiz away (used by "Leave the quiz" and "Discard"). */
    fun quit() {
        timerJob?.cancel()
        _state.value = null
    }

    // ---- answering ----

    fun select(option: Int) {
        val s = _state.value ?: return
        if (s.outcome != null || s.questions.isEmpty()) return
        val mode = s.config.mode
        if (mode.instantFeedback) {
            if (s.locked) return
            val question = s.questions[s.index]
            val right = option == question.correctIndex
            val lives = if (!right && mode.lives > 0) s.lives - 1 else s.lives
            _state.value = s.copy(
                answers = s.answers + (s.index to option),
                locked = true,
                lives = lives
            )
            if (mode == QuizMode.SPEED) {
                val position = s.index
                viewModelScope.launch {
                    delay(900)
                    val now = _state.value
                    if (now != null && now.outcome == null && now.index == position) moveNext()
                }
            }
        } else {
            _state.value = s.copy(answers = s.answers + (s.index to option))
        }
    }

    fun next() {
        val s = _state.value ?: return
        if (s.outcome != null) return
        if (s.config.mode.instantFeedback && !s.locked) return
        if (s.config.mode.lives > 0 && s.lives <= 0) {
            finish()
            return
        }
        moveNext()
    }

    fun previous() {
        val s = _state.value ?: return
        if (s.outcome != null || s.config.mode.instantFeedback || s.index == 0) return
        _state.value = s.copy(index = s.index - 1)
    }

    private fun moveNext() {
        val s = _state.value ?: return
        if (s.outcome != null) return
        if (s.index >= s.questions.lastIndex) {
            finish()
            return
        }
        val perQuestion = s.config.mode.secondsPerQuestion
        _state.value = s.copy(
            index = s.index + 1,
            locked = false,
            secondsLeft = if (perQuestion > 0) perQuestion else s.secondsLeft
        )
    }

    // ---- timer ----

    private fun startTimer() {
        timerJob?.cancel()
        val mode = _state.value?.config?.mode ?: return
        if (mode.secondsPerQuestionTotal == 0 && mode.secondsPerQuestion == 0) return
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                val s = _state.value ?: return@launch
                if (s.outcome != null) return@launch
                val left = s.secondsLeft - 1
                if (left > 0) {
                    _state.value = s.copy(secondsLeft = left)
                } else if (mode.secondsPerQuestion > 0) {
                    moveNext()
                } else {
                    _state.value = s.copy(secondsLeft = 0)
                    finish()
                    return@launch
                }
            }
        }
    }

    // ---- finishing ----

    fun finish() {
        val s = _state.value ?: return
        if (s.outcome != null) return
        timerJob?.cancel()
        val mode = s.config.mode

        // Survival ends early, so only the questions that were reached are counted.
        val considered = if (mode == QuizMode.SURVIVAL) {
            s.questions.take(s.index + if (s.locked) 1 else 0)
        } else {
            s.questions
        }
        var correct = 0
        var wrong = 0
        considered.forEachIndexed { i, q ->
            val chosen = s.answers[i]
            if (chosen != null) {
                if (chosen == q.correctIndex) correct++ else wrong++
            }
        }
        val skipped = considered.size - correct - wrong
        val score = correct - wrong * mode.negativeMarking
        val percent = if (considered.isEmpty()) 0
        else ((maxOf(score, 0.0) / considered.size) * 100).roundToInt()
        val duration = ((System.currentTimeMillis() - startedAt) / 1000).toInt()

        val outcome = QuizOutcome(
            total = considered.size,
            correct = correct,
            wrong = wrong,
            skipped = skipped,
            score = score,
            percent = percent,
            durationSec = duration,
            questions = considered,
            answers = s.answers
        )
        _state.value = s.copy(outcome = outcome)

        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val period = when (mode) {
                QuizMode.DAILY -> dailyKey()
                QuizMode.WEEKLY -> weeklyKey()
                else -> ""
            }
            db.quizResultDao().insert(
                QuizResultEntity(
                    mode = mode.name,
                    lawId = s.config.lawId,
                    total = considered.size,
                    correct = correct,
                    wrong = wrong,
                    skipped = skipped,
                    score = score,
                    percent = percent,
                    durationSec = duration,
                    finishedAt = now,
                    periodKey = period
                )
            )
            val records = considered.mapIndexedNotNull { i, q ->
                s.answers[i]?.let { chosen ->
                    AnswerRecordEntity(
                        questionId = q.id,
                        correct = chosen == q.correctIndex,
                        answeredAt = now,
                        mode = mode.name
                    )
                }
            }
            if (records.isNotEmpty()) db.answerRecordDao().insertAll(records)

            // Feed the dashboard's daily goals and streak.
            val today = LocalDate.now().toString()
            if (correct + wrong > 0) home.recordQuestions(today, correct + wrong)
            home.addMinutes(today, ceil(duration / 60.0).toInt().coerceAtLeast(1))
        }
    }

    private companion object {
        fun dailyKey(): String = "D:" + LocalDate.now().toString()

        fun weeklyKey(): String {
            val today = LocalDate.now()
            val year = today.get(IsoFields.WEEK_BASED_YEAR)
            val week = today.get(IsoFields.WEEK_OF_WEEK_BASED_YEAR)
            return "W:$year-$week"
        }
    }
}
