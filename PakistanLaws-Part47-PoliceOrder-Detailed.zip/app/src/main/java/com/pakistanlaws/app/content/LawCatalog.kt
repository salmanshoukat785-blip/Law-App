package com.pakistanlaws.app.content

/** The laws included in the app. Section text for each law is added in later parts. */
data class LawInfo(
    val id: String,
    val shortName: String,
    val nameEn: String,
    val nameUr: String
) {
    fun name(urdu: Boolean) = if (urdu) nameUr else nameEn
}

object LawCatalog {
    val laws = listOf(
        LawInfo("ppc", "PPC", "Pakistan Penal Code, 1860", "مجموعہ تعزیراتِ پاکستان، 1860"),
        LawInfo("crpc", "CrPC", "Code of Criminal Procedure, 1898", "مجموعہ ضابطہ فوجداری، 1898"),
        LawInfo("qso", "QSO", "Qanun-e-Shahadat Order, 1984", "قانونِ شہادت آرڈر، 1984"),
        LawInfo("police_order", "Police Order", "Police Order, 2002", "پولیس آرڈر، 2002 (پنجاب)"),
        LawInfo("police_rules", "Police Rules", "Punjab Police Rules, 1934", "پنجاب پولیس رولز، 1934"),
        LawInfo("arms", "Arms", "Punjab Arms Ordinance, 1965", "پنجاب اسلحہ آرڈیننس، 1965"),
        LawInfo("cnsa", "CNSA", "Control of Narcotic Substances Act, 1997", "کنٹرول آف نارکوٹک سبسٹینسز ایکٹ، 1997"),
        LawInfo("ata", "ATA", "Anti-Terrorism Act, 1997", "انسدادِ دہشت گردی ایکٹ، 1997"),
        LawInfo("hadd", "Hadd Order", "Prohibition (Enforcement of Hadd) Order, 1979", "امتناع (نفاذِ حد) آرڈر، 1979"),
        LawInfo("animals", "Animals Act", "Prevention of Cruelty to Animals Act, 1890", "انسدادِ ظلم بر حیوانات ایکٹ، 1890"),
        LawInfo("pmvo", "Motor Vehicles", "Provincial Motor Vehicles Ordinance, 1965", "صوبائی موٹر وہیکلز آرڈیننس، 1965"),
        LawInfo("sound", "Sound Systems", "Punjab Sound Systems (Regulation) Act, 2015", "پنجاب ساؤنڈ سسٹمز (ریگولیشن) ایکٹ، 2015"),
        LawInfo("probation", "Probation", "Probation of Offenders Ordinance, 1960", "پروبیشن آف آفنڈرز آرڈیننس، 1960"),
        LawInfo("peca", "PECA", "Prevention of Electronic Crimes Act, 2016", "الیکٹرانک کرائمز کی روک تھام کا ایکٹ، 2016"),
        LawInfo("explosive", "Explosive Substances", "Explosive Substances Act, 1908", "دھماکہ خیز مواد کا ایکٹ، 1908"),
        LawInfo("pwav", "Women Protection", "Punjab Protection of Women against Violence Act, 2016", "پنجاب تحفظِ خواتین بمقابلہ تشدد ایکٹ، 2016")
    )

    fun search(query: String): List<LawInfo> {
        val q = query.trim()
        if (q.length < 2) return emptyList()
        return laws.filter {
            it.nameEn.contains(q, ignoreCase = true) ||
                it.shortName.contains(q, ignoreCase = true) ||
                it.nameUr.contains(q)
        }
    }
}
