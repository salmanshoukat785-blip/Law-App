package com.pakistanlaws.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pakistanlaws.app.data.db.AppDatabase
import com.pakistanlaws.app.data.db.QuestionEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

class QuestionBankViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.get(application)

    val bank: StateFlow<List<QuestionEntity>> = db.questionDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /**
     * Question id -> true if the latest answer was right, false if it was wrong.
     * Questions that were never answered are not in the map.
     */
    val status: StateFlow<Map<String, Boolean>> = db.answerRecordDao().observeAll()
        .map { records ->
            val latest = LinkedHashMap<String, Boolean>()
            records.forEach { latest[it.questionId] = it.correct }
            latest
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())
}
