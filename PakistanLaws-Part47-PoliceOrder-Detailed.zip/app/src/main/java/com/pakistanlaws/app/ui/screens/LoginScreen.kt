package com.pakistanlaws.app.ui.screens

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.pakistanlaws.app.R
import com.pakistanlaws.app.ui.AppViewModel
import com.pakistanlaws.app.ui.Session
import com.pakistanlaws.app.ui.components.AppTextField
import com.pakistanlaws.app.ui.components.AuthLayout
import com.pakistanlaws.app.ui.components.ErrorText
import com.pakistanlaws.app.ui.components.PinField
import com.pakistanlaws.app.ui.components.PrimaryButton

@Composable
fun LoginScreen(
    vm: AppViewModel,
    onSession: (Session) -> Unit,
    onSignUp: () -> Unit,
    onBack: () -> Unit
) {
    val session by vm.session.collectAsState()
    val busy by vm.busy.collectAsState()
    val error by vm.error.collectAsState()
    var phone by rememberSaveable { mutableStateOf("") }
    var pin by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(Unit) { vm.clearError() }
    LaunchedEffect(session) {
        if (session is Session.Active || session is Session.Pending || session is Session.Rejected) {
            onSession(session)
        }
    }

    AuthLayout(
        title = stringResource(R.string.login_title),
        subtitle = stringResource(R.string.login_subtitle),
        onBack = onBack
    ) {
        if (!vm.firebaseReady) {
            Text(
                text = stringResource(R.string.err_not_configured),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error
            )
            Spacer(Modifier.height(12.dp))
        }
        AppTextField(
            value = phone,
            onValueChange = { phone = it },
            label = stringResource(R.string.label_phone),
            keyboardType = KeyboardType.Phone
        )
        Spacer(Modifier.height(12.dp))
        PinField(
            value = pin,
            onValueChange = { pin = it },
            label = stringResource(R.string.label_pin)
        )
        ErrorText(error, modifier = Modifier.padding(top = 12.dp))
        Spacer(Modifier.height(20.dp))
        PrimaryButton(
            text = stringResource(R.string.action_login),
            busy = busy,
            onClick = { vm.signIn(phone, pin) }
        )
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = onSignUp) {
            Text(stringResource(R.string.login_no_account))
        }
    }
}
