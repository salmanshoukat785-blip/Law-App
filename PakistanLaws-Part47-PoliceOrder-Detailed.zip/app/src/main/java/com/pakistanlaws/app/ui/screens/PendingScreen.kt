package com.pakistanlaws.app.ui.screens

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Block
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.pakistanlaws.app.AppConfig
import com.pakistanlaws.app.R
import com.pakistanlaws.app.data.PhoneUtil
import com.pakistanlaws.app.ui.AppViewModel
import com.pakistanlaws.app.ui.Session
import com.pakistanlaws.app.ui.components.ErrorText
import com.pakistanlaws.app.ui.components.PrimaryButton

/**
 * Shown while the account is pending (or rejected). The user taps the WhatsApp button, the admin
 * approves the account in the Firebase console, and this screen then opens the app by itself.
 */
@Composable
fun PendingScreen(
    vm: AppViewModel,
    onSession: (Session) -> Unit
) {
    val session by vm.session.collectAsState()
    val busy by vm.busy.collectAsState()
    val error by vm.error.collectAsState()
    val context = LocalContext.current

    val profile = when (val s = session) {
        is Session.Pending -> s.profile
        is Session.Rejected -> s.profile
        else -> null
    }
    val rejected = session is Session.Rejected

    DisposableEffect(Unit) {
        vm.watchApproval()
        onDispose { vm.stopWatching() }
    }
    LaunchedEffect(session) {
        if (session is Session.Active || session is Session.NeedsAuth) onSession(session)
    }

    val whatsappFailed = stringResource(R.string.whatsapp_missing)
    fun openWhatsApp() {
        val message = context.getString(
            R.string.whatsapp_message,
            profile?.name.orEmpty(),
            PhoneUtil.display(profile?.phone.orEmpty())
        )
        val uri = Uri.parse("https://wa.me/${AppConfig.ADMIN_WHATSAPP}?text=${Uri.encode(message)}")
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, whatsappFailed, Toast.LENGTH_LONG).show()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(Modifier.height(24.dp))
        Icon(
            imageVector = if (rejected) Icons.Filled.Block else Icons.Filled.HourglassTop,
            contentDescription = null,
            tint = if (rejected) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(64.dp)
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = stringResource(if (rejected) R.string.rejected_title else R.string.pending_title),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(16.dp))
        if (!rejected) {
            Text(
                text = stringResource(R.string.pending_cta),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(12.dp))
        }
        Text(
            text = stringResource(if (rejected) R.string.rejected_body else R.string.pending_body),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = stringResource(R.string.admin_number_label),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = AppConfig.ADMIN_WHATSAPP_DISPLAY,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(Modifier.height(20.dp))
        PrimaryButton(
            text = stringResource(R.string.action_whatsapp),
            onClick = { openWhatsApp() }
        )
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = { vm.refreshStatus() },
            enabled = !busy,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text(stringResource(R.string.action_check_status))
        }
        ErrorText(error, modifier = Modifier.padding(top = 12.dp))
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = { vm.signOut() }) {
            Text(stringResource(R.string.action_logout))
        }
    }
}
