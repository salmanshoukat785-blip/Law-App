package com.pakistanlaws.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.syllabusDataStore by preferencesDataStore(name = "pakistan_laws_syllabus")
private val KEY_IDS = stringSetPreferencesKey("section_ids")

/** The user's own syllabus: the ids of sections they chose, one by one. */
class SyllabusStore(context: Context) {
    private val store = context.applicationContext.syllabusDataStore

    val ids: Flow<Set<String>> = store.data.map { it[KEY_IDS] ?: emptySet() }

    suspend fun toggle(id: String) {
        store.edit {
            val cur = it[KEY_IDS] ?: emptySet()
            it[KEY_IDS] = if (id in cur) cur - id else cur + id
        }
    }

    suspend fun remove(id: String) {
        store.edit { it[KEY_IDS] = (it[KEY_IDS] ?: emptySet()) - id }
    }

    suspend fun clear() {
        store.edit { it[KEY_IDS] = emptySet() }
    }
}
