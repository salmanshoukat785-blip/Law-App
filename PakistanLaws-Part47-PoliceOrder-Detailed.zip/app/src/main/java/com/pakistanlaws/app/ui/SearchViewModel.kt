package com.pakistanlaws.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pakistanlaws.app.content.LawCatalog
import com.pakistanlaws.app.content.LawInfo
import com.pakistanlaws.app.data.db.AppDatabase
import com.pakistanlaws.app.data.db.SectionEntity
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

@OptIn(ExperimentalCoroutinesApi::class)
class SearchViewModel(application: Application) : AndroidViewModel(application) {

    private val sectionDao = AppDatabase.get(application).sectionDao()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    val laws: StateFlow<List<LawInfo>> = _query
        .map { LawCatalog.search(it) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val sections: StateFlow<List<SectionEntity>> = _query
        .map { it.trim() }
        .flatMapLatest { q ->
            if (q.length < 2) flowOf(emptyList<SectionEntity>()) else sectionDao.search(q)
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun setQuery(value: String) {
        _query.value = value
    }
}
