package com.pakistanlaws.app.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.pakistanlaws.app.R
import com.pakistanlaws.app.ui.FlashSession
import com.pakistanlaws.app.ui.FlashcardViewModel
import com.pakistanlaws.app.ui.theme.Language
import com.pakistanlaws.app.ui.theme.LocalAnimations

/** One practice session: flip the card, then say whether you remember it. */
@Composable
fun FlashcardSessionScreen(
    vm: FlashcardViewModel,
    onClose: () -> Unit
) {
    val state by vm.session.collectAsState()
    val s = state
    val appUrdu = Language.isUrdu(LocalConfiguration.current)
    var urdu by rememberSaveable { mutableStateOf(appUrdu) }

    BackHandler {
        vm.endSession()
        onClose()
    }

    if (s == null) {
        Box(modifier = Modifier.fillMaxSize())
        return
    }

    // Nothing to practise
    if (s.queue.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = stringResource(R.string.fc_nothing),
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = { vm.start(s.deck, practiceOnly = true) }) {
                Text(stringResource(R.string.fc_practise_anyway))
            }
            TextButton(onClick = {
                vm.endSession()
                onClose()
            }) {
                Text(stringResource(R.string.fc_back_to_decks))
            }
        }
        return
    }

    // Finished
    if (s.finished) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Check,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(64.dp)
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = stringResource(R.string.fc_session_done),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.fc_summary_format, s.remembered, s.forgot),
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center
            )
            if (s.practiceOnly) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = stringResource(R.string.fc_practice_note),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
            Spacer(Modifier.height(24.dp))
            Button(onClick = {
                vm.endSession()
                onClose()
            }) {
                Text(stringResource(R.string.fc_back_to_decks))
            }
        }
        return
    }

    val card = s.queue[s.index]

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {
                vm.endSession()
                onClose()
            }) {
                Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.action_back))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.fc_progress_format, s.index + 1, s.queue.size),
                    style = MaterialTheme.typography.labelLarge
                )
                LinearProgressIndicator(
                    progress = { (s.index + 1f) / s.queue.size },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                )
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.Center
        ) {
            // A new composition for every card, so a card never flips back to show the next answer.
            key(s.index) {
                FlipCard(
                    front = card.front(urdu),
                    back = card.back(urdu),
                    ref = card.ref,
                    flipped = s.flipped,
                    onClick = { vm.flip() }
                )
            }
            Spacer(Modifier.height(12.dp))
            if (!s.flipped) {
                Text(
                    text = stringResource(R.string.fc_tap_flip),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        if (s.flipped) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = { vm.answer(false) },
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text(stringResource(R.string.fc_forgot))
                }
                Button(
                    onClick = { vm.answer(true) },
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                ) {
                    Text(stringResource(R.string.fc_remember))
                }
            }
        } else {
            Spacer(Modifier.height(76.dp))
        }
    }
}

@Composable
private fun FlipCard(
    front: String,
    back: String,
    ref: String,
    flipped: Boolean,
    onClick: () -> Unit
) {
    val animated = LocalAnimations.current
    val rotation by animateFloatAsState(
        targetValue = if (flipped) 180f else 0f,
        animationSpec = if (animated) tween<Float>(450) else snap<Float>(),
        label = "flip"
    )
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                rotationY = rotation
                cameraDistance = 14f * density
            }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (rotation <= 90f) {
            Face(
                text = front,
                ref = "",
                container = MaterialTheme.colorScheme.surfaceVariant,
                content = MaterialTheme.colorScheme.onSurface
            )
        } else {
            // The back is drawn mirrored by the rotation, so it is turned once more to read correctly.
            Box(modifier = Modifier.graphicsLayer { rotationY = 180f }) {
                Face(
                    text = back,
                    ref = ref,
                    container = MaterialTheme.colorScheme.primaryContainer,
                    content = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }
    }
}

@Composable
private fun Face(
    text: String,
    ref: String,
    container: androidx.compose.ui.graphics.Color,
    content: androidx.compose.ui.graphics.Color
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 460.dp),
        colors = CardDefaults.cardColors(containerColor = container)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 260.dp)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold,
                color = content,
                textAlign = TextAlign.Center
            )
            if (ref.isNotBlank()) {
                Spacer(Modifier.height(16.dp))
                Text(
                    text = ref,
                    style = MaterialTheme.typography.labelMedium,
                    color = content.copy(alpha = 0.7f)
                )
            }
        }
    }
}
