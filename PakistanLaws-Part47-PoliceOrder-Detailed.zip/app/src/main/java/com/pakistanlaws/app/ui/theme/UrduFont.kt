package com.pakistanlaws.app.ui.theme

import android.content.Context
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily

/**
 * Looks for a Nastaliq Urdu font in res/font, in this order:
 *   1. jameel_noori_nastaleeq.ttf  (Jameel Noori Nastaleeq)
 *   2. noto_nastaliq_urdu.ttf      (Noto Nastaliq Urdu)
 * If neither file has been added, Urdu text uses the phone's own Urdu font.
 */
object UrduFont {
    fun family(context: Context): FontFamily {
        val names = listOf("jameel_noori_nastaleeq", "noto_nastaliq_urdu")
        for (name in names) {
            val id = context.resources.getIdentifier(name, "font", context.packageName)
            if (id != 0) return FontFamily(Font(id))
        }
        return FontFamily.Default
    }
}
