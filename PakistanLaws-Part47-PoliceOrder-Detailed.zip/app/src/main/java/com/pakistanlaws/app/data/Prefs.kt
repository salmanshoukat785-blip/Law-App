package com.pakistanlaws.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.appDataStore by preferencesDataStore(name = "pakistan_laws_prefs")

private val KEY_ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
private val KEY_GUEST_NAME = stringPreferencesKey("guest_name")
private val KEY_GUIDE_SEEN = booleanPreferencesKey("guide_seen")
private val KEY_CACHED_UID = stringPreferencesKey("cached_uid")
private val KEY_CACHED_NAME = stringPreferencesKey("cached_name")
private val KEY_CACHED_PHONE = stringPreferencesKey("cached_phone")
private val KEY_CACHED_STATUS = stringPreferencesKey("cached_status")
private val KEY_CONTENT_VERSION = intPreferencesKey("content_version")

data class PrefsSnapshot(
    val onboardingDone: Boolean = false,
    val guestName: String = "",
    val guideSeen: Boolean = false,
    val cachedUid: String = "",
    val cachedName: String = "",
    val cachedPhone: String = "",
    val cachedStatus: String = ""
)

class Prefs(context: Context) {
    private val store = context.applicationContext.appDataStore

    private fun Preferences.toSnapshot() = PrefsSnapshot(
        onboardingDone = this[KEY_ONBOARDING_DONE] ?: false,
        guestName = this[KEY_GUEST_NAME] ?: "",
        guideSeen = this[KEY_GUIDE_SEEN] ?: false,
        cachedUid = this[KEY_CACHED_UID] ?: "",
        cachedName = this[KEY_CACHED_NAME] ?: "",
        cachedPhone = this[KEY_CACHED_PHONE] ?: "",
        cachedStatus = this[KEY_CACHED_STATUS] ?: ""
    )

    val flow: Flow<PrefsSnapshot> = store.data.map { it.toSnapshot() }

    suspend fun snapshot(): PrefsSnapshot = flow.first()

    suspend fun setOnboardingDone() {
        store.edit { it[KEY_ONBOARDING_DONE] = true }
    }

    suspend fun setGuestName(name: String) {
        store.edit { it[KEY_GUEST_NAME] = name }
    }

    suspend fun setGuideSeen() {
        store.edit { it[KEY_GUIDE_SEEN] = true }
    }

    suspend fun cacheProfile(p: UserProfile) {
        store.edit {
            it[KEY_CACHED_UID] = p.uid
            it[KEY_CACHED_NAME] = p.name
            it[KEY_CACHED_PHONE] = p.phone
            it[KEY_CACHED_STATUS] = p.status
        }
    }

    suspend fun contentVersion(): Int = store.data.map { it[KEY_CONTENT_VERSION] ?: 0 }.first()

    suspend fun setContentVersion(version: Int) {
        store.edit { it[KEY_CONTENT_VERSION] = version }
    }

    /** Called on logout: forgets the account and guest name. */
    suspend fun clearAccount() {
        store.edit {
            it.remove(KEY_GUEST_NAME)
            it.remove(KEY_CACHED_UID)
            it.remove(KEY_CACHED_NAME)
            it.remove(KEY_CACHED_PHONE)
            it.remove(KEY_CACHED_STATUS)
        }
    }
}
