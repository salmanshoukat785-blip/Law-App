Urdu font (optional)
Put the font file here:  app/src/main/res/font/jameel_noori_nastaleeq.ttf
(file name must be all lowercase, letters, digits and underscores only)
If that file is missing the app tries  noto_nastaliq_urdu.ttf, and if that is missing too it uses the phone's own Urdu font.
The font is used for the Urdu translation text in the reader.
