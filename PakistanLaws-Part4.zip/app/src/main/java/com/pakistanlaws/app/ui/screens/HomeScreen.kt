package com.pakistanlaws.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.pakistanlaws.app.R
import com.pakistanlaws.app.navigation.BottomTab
import com.pakistanlaws.app.ui.HomeViewModel

/** The Home dashboard: greeting, search, continue learning, goals, shortcuts and daily content. */
@Composable
fun HomeScreen(
    name: String,
    vm: HomeViewModel,
    onOpenSearch: () -> Unit,
    onOpenTab: (BottomTab) -> Unit,
    onOpenSettings: () -> Unit
) {
    val state by vm.state.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        HomeHeader(name = name, onOpenSettings = onOpenSettings)

        SearchBarButton(onClick = onOpenSearch)

        ContinueCard(
            recent = state.recent.firstOrNull(),
            onOpenLibrary = { onOpenTab(BottomTab.LIBRARY) }
        )

        GoalsCard(
            done = state.goalsDone,
            total = state.goalsTotal,
            streak = state.streak,
            questionDone = state.selectedChoice != null,
            knowledgeDone = state.knowledgeRead
        )

        HomeSectionTitle(stringResource(R.string.quick_title))
        QuickAccessGrid(onOpenTab = onOpenTab)

        HomeSectionTitle(stringResource(R.string.laws_title))
        LawsRow(onOpenLaw = { onOpenTab(BottomTab.LIBRARY) })

        DailyQuestionCard(
            question = state.question,
            selected = state.selectedChoice,
            onAnswer = { vm.answerQuestion(it) }
        )

        DailyKnowledgeCard(
            card = state.knowledge,
            read = state.knowledgeRead,
            onMarkRead = { vm.markKnowledgeRead() }
        )

        HomeSectionTitle(stringResource(R.string.recent_title))
        RecentList(
            items = state.recent,
            onOpen = { onOpenTab(BottomTab.LIBRARY) }
        )

        Text(
            text = stringResource(R.string.disclaimer),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.outline,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(vertical = 8.dp)
        )
    }
}
