package com.pakistanlaws.app.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.pakistanlaws.app.ui.AppViewModel
import com.pakistanlaws.app.ui.HomeViewModel
import com.pakistanlaws.app.ui.SearchViewModel
import com.pakistanlaws.app.ui.Session
import com.pakistanlaws.app.ui.components.PlaceholderScreen
import com.pakistanlaws.app.ui.components.UserGuideDialog
import com.pakistanlaws.app.ui.screens.HomeScreen
import com.pakistanlaws.app.ui.screens.ProfileScreen
import com.pakistanlaws.app.ui.screens.SearchScreen

/** Switches to one of the five tabs, keeping each tab's own state. */
private fun NavController.switchTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) {
            saveState = true
        }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun MainScaffold(
    vm: AppViewModel,
    onLoggedOut: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val tabNav = rememberNavController()
    val backStackEntry by tabNav.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val guideSeen by vm.guideSeen.collectAsState()
    val session by vm.session.collectAsState()
    val name = (session as? Session.Active)?.name.orEmpty()

    val tabRoutes = remember { BottomTab.entries.map { it.route } }
    val showBottomBar = currentRoute == null || currentRoute in tabRoutes

    if (!guideSeen) {
        UserGuideDialog(onFinish = { vm.markGuideSeen() })
    }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    BottomTab.entries.forEach { tab ->
                        NavigationBarItem(
                            selected = currentRoute == tab.route,
                            onClick = { tabNav.switchTab(tab.route) },
                            icon = {
                                Icon(tab.icon, contentDescription = stringResource(tab.label))
                            },
                            label = { Text(stringResource(tab.label)) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = tabNav,
            startDestination = BottomTab.HOME.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(BottomTab.HOME.route) {
                val homeVm: HomeViewModel = viewModel()
                HomeScreen(
                    name = name,
                    vm = homeVm,
                    onOpenSearch = { tabNav.navigate(Routes.SEARCH) },
                    onOpenTab = { tabNav.switchTab(it.route) },
                    onOpenSettings = onOpenSettings
                )
            }
            composable(BottomTab.PROFILE.route) {
                ProfileScreen(
                    vm = vm,
                    onLoggedOut = onLoggedOut,
                    onOpenSettings = onOpenSettings
                )
            }
            listOf(BottomTab.LIBRARY, BottomTab.PRACTICE, BottomTab.STUDY).forEach { tab ->
                composable(tab.route) {
                    PlaceholderScreen(
                        title = stringResource(tab.label),
                        icon = tab.icon
                    )
                }
            }
            composable(Routes.SEARCH) {
                val searchVm: SearchViewModel = viewModel()
                SearchScreen(
                    vm = searchVm,
                    onBack = { tabNav.popBackStack() },
                    // The library screens arrive in the next part; for now both open the Library tab.
                    onOpenLaw = { tabNav.switchTab(BottomTab.LIBRARY.route) },
                    onOpenSection = { tabNav.switchTab(BottomTab.LIBRARY.route) }
                )
            }
        }
    }
}
