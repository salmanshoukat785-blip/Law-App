package com.pakistanlaws.app.content

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.HowToReg
import androidx.compose.material.icons.filled.LocalBar
import androidx.compose.material.icons.filled.LocalPharmacy
import androidx.compose.material.icons.filled.LocalPolice
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.ui.graphics.vector.ImageVector
import com.pakistanlaws.app.data.db.LawEntity

/** One law in the app, with names in English and Urdu. */
data class LawInfo(
    val id: String,
    val shortEn: String,
    val shortUr: String,
    val titleEn: String,
    val titleUr: String,
    val icon: ImageVector
)

object LawCatalog {
    val all: List<LawInfo> = listOf(
        LawInfo("ppc", "PPC", "تعزیرات", "Pakistan Penal Code, 1860", "مجموعہ تعزیراتِ پاکستان، 1860", Icons.Filled.Gavel),
        LawInfo("crpc", "CrPC", "ضابطہ فوجداری", "Code of Criminal Procedure, 1898", "مجموعہ ضابطہ فوجداری، 1898", Icons.Filled.Description),
        LawInfo("qso", "Qanun-e-Shahadat", "قانونِ شہادت", "Qanun-e-Shahadat Order, 1984", "قانونِ شہادت آرڈر، 1984", Icons.Filled.Fingerprint),
        LawInfo("police_order", "Police Order", "پولیس آرڈر", "Police Order, 2002", "پولیس آرڈر، 2002", Icons.Filled.LocalPolice),
        LawInfo("police_rules", "Police Rules", "پولیس رولز", "Punjab Police Rules, 1934", "پنجاب پولیس رولز، 1934", Icons.Filled.Assignment),
        LawInfo("arms", "Arms Ordinance", "آرمز آرڈیننس", "Punjab Arms Ordinance, 1965", "پنجاب آرمز آرڈیننس، 1965", Icons.Filled.Security),
        LawInfo("cnsa", "Narcotics Act", "منشیات ایکٹ", "Control of Narcotic Substances Act, 1997", "کنٹرول آف نارکوٹک سبسٹینسز ایکٹ، 1997", Icons.Filled.LocalPharmacy),
        LawInfo("ata", "Anti-Terrorism Act", "انسدادِ دہشت گردی", "Anti-Terrorism Act, 1997", "انسدادِ دہشت گردی ایکٹ، 1997", Icons.Filled.Shield),
        LawInfo("hadd", "Hadd Order", "حد آرڈر", "Prohibition (Enforcement of Hadd) Order, 1979", "امتناع (نفاذِ حد) آرڈر، 1979", Icons.Filled.LocalBar),
        LawInfo("animals", "Animals Act", "حیوانات ایکٹ", "Prevention of Cruelty to Animals Act, 1890", "انسدادِ ظلم بر حیوانات ایکٹ، 1890", Icons.Filled.Pets),
        LawInfo("pmvo", "Motor Vehicles", "موٹر وہیکلز", "Provincial Motor Vehicles Ordinance, 1965", "صوبائی موٹر وہیکلز آرڈیننس، 1965", Icons.Filled.DirectionsCar),
        LawInfo("probation", "Probation", "پروبیشن", "Probation of Offenders Ordinance, 1960", "پروبیشن آف آفینڈرز آرڈیننس، 1960", Icons.Filled.HowToReg)
    )

    fun byId(id: String): LawInfo? = all.firstOrNull { it.id == id }

    /** Finds laws whose English or Urdu name contains [query]. */
    fun search(query: String): List<LawInfo> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyList()
        return all.filter {
            it.shortEn.lowercase().contains(q) ||
                it.titleEn.lowercase().contains(q) ||
                it.shortUr.contains(q) ||
                it.titleUr.contains(q)
        }
    }

    /** The rows saved into the Room database on first start. */
    fun entities(): List<LawEntity> = all.mapIndexed { index, law ->
        LawEntity(
            id = law.id,
            titleEn = law.titleEn,
            titleUr = law.titleUr,
            shortName = law.shortEn,
            sortOrder = index
        )
    }
}
