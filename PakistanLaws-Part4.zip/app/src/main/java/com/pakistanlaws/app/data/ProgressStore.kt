package com.pakistanlaws.app.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate

private val Context.progressDataStore by preferencesDataStore(name = "pakistan_laws_progress")

private val KEY_LAST_ACTIVE = stringPreferencesKey("last_active")
private val KEY_STREAK = intPreferencesKey("streak")
private val KEY_DQ_DATE = stringPreferencesKey("dq_date")
private val KEY_DQ_CHOICE = intPreferencesKey("dq_choice")
private val KEY_DK_DATE = stringPreferencesKey("dk_date")
private val KEY_RECENT = stringPreferencesKey("recent_sections")

data class ProgressSnapshot(
    val lastActive: String = "",
    val streak: Int = 0,
    val dqDate: String = "",
    val dqChoice: Int = -1,
    val dkDate: String = "",
    /** Section ids, newest first. */
    val recent: List<String> = emptyList()
)

/** Small daily progress kept on the phone: streak, today's answers and recently opened sections. */
class ProgressStore(context: Context) {
    private val store = context.applicationContext.progressDataStore

    private fun Preferences.toSnapshot() = ProgressSnapshot(
        lastActive = this[KEY_LAST_ACTIVE] ?: "",
        streak = this[KEY_STREAK] ?: 0,
        dqDate = this[KEY_DQ_DATE] ?: "",
        dqChoice = this[KEY_DQ_CHOICE] ?: -1,
        dkDate = this[KEY_DK_DATE] ?: "",
        recent = (this[KEY_RECENT] ?: "").split("|").filter { it.isNotBlank() }
    )

    val flow: Flow<ProgressSnapshot> = store.data.map { it.toSnapshot() }

    /** Counts today as an active day and updates the streak. */
    suspend fun touchToday() {
        val today = LocalDate.now()
        store.edit { prefs ->
            val last = prefs[KEY_LAST_ACTIVE]?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
            val streak = prefs[KEY_STREAK] ?: 0
            if (last != today) {
                prefs[KEY_STREAK] = if (last != null && last.plusDays(1) == today) streak + 1 else 1
            }
            prefs[KEY_LAST_ACTIVE] = today.toString()
        }
    }

    suspend fun saveDailyAnswer(date: String, choice: Int) {
        store.edit {
            it[KEY_DQ_DATE] = date
            it[KEY_DQ_CHOICE] = choice
        }
    }

    suspend fun markKnowledgeRead(date: String) {
        store.edit { it[KEY_DK_DATE] = date }
    }

    suspend fun addRecent(sectionId: String) {
        store.edit { prefs ->
            val current = (prefs[KEY_RECENT] ?: "").split("|").filter { it.isNotBlank() }
            val updated = (listOf(sectionId) + current.filter { it != sectionId }).take(10)
            prefs[KEY_RECENT] = updated.joinToString("|")
        }
    }
}
