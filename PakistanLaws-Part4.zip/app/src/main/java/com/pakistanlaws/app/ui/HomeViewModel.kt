package com.pakistanlaws.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pakistanlaws.app.content.DailyContent
import com.pakistanlaws.app.content.DailyQuestion
import com.pakistanlaws.app.content.KnowledgeCard
import com.pakistanlaws.app.content.LawCatalog
import com.pakistanlaws.app.data.ProgressSnapshot
import com.pakistanlaws.app.data.ProgressStore
import com.pakistanlaws.app.data.db.AppDatabase
import com.pakistanlaws.app.data.db.SectionEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

data class HomeUiState(
    val question: DailyQuestion,
    /** The option the user picked today, or null if not answered yet. */
    val selectedChoice: Int?,
    val knowledge: KnowledgeCard,
    val knowledgeRead: Boolean,
    val streak: Int,
    val recent: List<SectionEntity>,
    val goalsDone: Int,
    val goalsTotal: Int
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val store = ProgressStore(application)
    private val database = AppDatabase.get(application)

    private fun build(snap: ProgressSnapshot, recent: List<SectionEntity>): HomeUiState {
        val today = LocalDate.now()
        val todayText = today.toString()
        val choice = if (snap.dqDate == todayText && snap.dqChoice >= 0) snap.dqChoice else null
        val read = snap.dkDate == todayText
        return HomeUiState(
            question = DailyContent.questionFor(today),
            selectedChoice = choice,
            knowledge = DailyContent.knowledgeFor(today),
            knowledgeRead = read,
            streak = snap.streak,
            recent = recent,
            goalsDone = (if (choice != null) 1 else 0) + (if (read) 1 else 0),
            goalsTotal = 2
        )
    }

    val state: StateFlow<HomeUiState> = store.flow
        .map { snap ->
            val recent = snap.recent.mapNotNull { database.sectionDao().getById(it) }
            build(snap, recent)
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, build(ProgressSnapshot(), emptyList()))

    init {
        viewModelScope.launch {
            // Keep the list of laws in the database in step with the app's catalogue.
            database.lawDao().insertAll(LawCatalog.entities())
            store.touchToday()
        }
    }

    fun answerQuestion(choice: Int) {
        if (state.value.selectedChoice != null) return
        viewModelScope.launch {
            store.saveDailyAnswer(LocalDate.now().toString(), choice)
        }
    }

    fun markKnowledgeRead() {
        viewModelScope.launch {
            store.markKnowledgeRead(LocalDate.now().toString())
        }
    }
}
