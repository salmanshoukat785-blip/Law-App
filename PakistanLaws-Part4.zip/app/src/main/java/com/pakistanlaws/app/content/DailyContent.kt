package com.pakistanlaws.app.content

import java.time.LocalDate

data class DailyQuestion(
    val questionEn: String,
    val questionUr: String,
    val optionsEn: List<String>,
    val optionsUr: List<String>,
    val correct: Int,
    val explanationEn: String,
    val explanationUr: String,
    val sourceEn: String,
    val sourceUr: String
)

data class KnowledgeCard(
    val titleEn: String,
    val titleUr: String,
    val bodyEn: String,
    val bodyUr: String,
    val sourceEn: String,
    val sourceUr: String
)

/**
 * Hand-written daily content. One question and one knowledge card are picked by date,
 * so everyone sees the same ones on the same day. The full question bank arrives in a later part.
 */
object DailyContent {

    fun questionFor(date: LocalDate): DailyQuestion =
        questions[(date.toEpochDay() % questions.size).toInt()]

    fun knowledgeFor(date: LocalDate): KnowledgeCard =
        knowledge[(date.toEpochDay() % knowledge.size).toInt()]

    val questions: List<DailyQuestion> = listOf(
        DailyQuestion(
            questionEn = "Which section of the Code of Criminal Procedure, 1898 deals with the power to record statements and confessions?",
            questionUr = "ضابطہ فوجداری 1898 کی کون سی دفعہ بیانات اور اعترافات ریکارڈ کرنے کے اختیار سے متعلق ہے؟",
            optionsEn = listOf("Section 154", "Section 161", "Section 164", "Section 173"),
            optionsUr = listOf("دفعہ 154", "دفعہ 161", "دفعہ 164", "دفعہ 173"),
            correct = 2,
            explanationEn = "Section 164 allows a Magistrate to record statements and confessions during an investigation.",
            explanationUr = "دفعہ 164 کے تحت مجسٹریٹ تفتیش کے دوران بیانات اور اعترافات ریکارڈ کر سکتا ہے۔",
            sourceEn = "CrPC, section 164",
            sourceUr = "ضابطہ فوجداری، دفعہ 164"
        ),
        DailyQuestion(
            questionEn = "Under which Article of the Qanun-e-Shahadat Order, 1984 can a confession made to a police officer not be proved against the accused?",
            questionUr = "قانونِ شہادت آرڈر 1984 کے کس آرٹیکل کے تحت پولیس افسر کے سامنے کیا گیا اعتراف ملزم کے خلاف ثابت نہیں کیا جا سکتا؟",
            optionsEn = listOf("Article 17", "Article 38", "Article 46", "Article 164"),
            optionsUr = listOf("آرٹیکل 17", "آرٹیکل 38", "آرٹیکل 46", "آرٹیکل 164"),
            correct = 1,
            explanationEn = "Article 38 says a confession made to a police officer cannot be proved against a person accused of an offence.",
            explanationUr = "آرٹیکل 38 کے مطابق پولیس افسر کے سامنے کیا گیا اعتراف کسی ملزم کے خلاف ثابت نہیں کیا جا سکتا۔",
            sourceEn = "Qanun-e-Shahadat Order, 1984, Article 38",
            sourceUr = "قانونِ شہادت آرڈر 1984، آرٹیکل 38"
        ),
        DailyQuestion(
            questionEn = "What is the minimum rank of an officer who may enter, search, seize and arrest without a warrant under section 21 of the Control of Narcotic Substances Act, 1997?",
            questionUr = "کنٹرول آف نارکوٹک سبسٹینسز ایکٹ 1997 کی دفعہ 21 کے تحت بغیر وارنٹ داخل ہونے، تلاشی لینے، ضبطی اور گرفتاری کا اختیار کم از کم کس رینک کے افسر کو ہے؟",
            optionsEn = listOf("Head Constable", "Assistant Sub-Inspector", "Sub-Inspector", "Superintendent of Police"),
            optionsUr = listOf("ہیڈ کانسٹیبل", "اسسٹنٹ سب انسپکٹر", "سب انسپکٹر", "سپرنٹنڈنٹ پولیس"),
            correct = 2,
            explanationEn = "Section 21 names an authorised officer not below the rank of Sub-Inspector (or equivalent). He must record his grounds and send a copy to his immediate superior.",
            explanationUr = "دفعہ 21 میں مجاز افسر کا رینک سب انسپکٹر (یا اس کے برابر) سے کم نہیں ہونا چاہیے۔ اسے اپنی وجوہات لکھ کر اس کی نقل اپنے بالا افسر کو بھیجنا ہوتی ہے۔",
            sourceEn = "Control of Narcotic Substances Act, 1997, section 21",
            sourceUr = "کنٹرول آف نارکوٹک سبسٹینسز ایکٹ 1997، دفعہ 21"
        ),
        DailyQuestion(
            questionEn = "Within how long must a prosecution under the Prevention of Cruelty to Animals Act, 1890 be started?",
            questionUr = "انسدادِ ظلم بر حیوانات ایکٹ 1890 کے تحت مقدمہ کتنی مدت کے اندر شروع کرنا ضروری ہے؟",
            optionsEn = listOf("One month", "Three months", "Six months", "One year"),
            optionsUr = listOf("ایک ماہ", "تین ماہ", "چھ ماہ", "ایک سال"),
            correct = 1,
            explanationEn = "Section 9 says a prosecution must not be instituted after three months from the date of the offence.",
            explanationUr = "دفعہ 9 کے مطابق جرم کی تاریخ سے تین ماہ گزرنے کے بعد مقدمہ شروع نہیں کیا جا سکتا۔",
            sourceEn = "Prevention of Cruelty to Animals Act, 1890, section 9",
            sourceUr = "انسدادِ ظلم بر حیوانات ایکٹ 1890، دفعہ 9"
        ),
        DailyQuestion(
            questionEn = "In the version of the Punjab Arms Ordinance, 1965 used by this app, what is the minimum imprisonment under section 13(2)(a) for an offence relating to a non-prohibited bore weapon?",
            questionUr = "اس ایپ میں شامل پنجاب آرمز آرڈیننس 1965 کے متن کے مطابق دفعہ 13(2)(الف) کے تحت غیر ممنوعہ بور کے ہتھیار سے متعلق جرم کی کم از کم قید کتنی ہے؟",
            optionsEn = listOf("Six months", "One year", "Two years", "Five years"),
            optionsUr = listOf("چھ ماہ", "ایک سال", "دو سال", "پانچ سال"),
            correct = 2,
            explanationEn = "It is not less than two years and may extend to seven years, with fine. Always check the latest official text for newer changes.",
            explanationUr = "یہ سزا دو سال سے کم نہیں اور سات سال تک ہو سکتی ہے، ساتھ جرمانہ بھی۔ نئی تبدیلیوں کے لیے تازہ ترین سرکاری متن ضرور دیکھیں۔",
            sourceEn = "Punjab Arms Ordinance, 1965, section 13",
            sourceUr = "پنجاب آرمز آرڈیننس 1965، دفعہ 13"
        ),
        DailyQuestion(
            questionEn = "How long can a person arrested by the police be kept in custody without the order of a Magistrate, excluding the journey to court?",
            questionUr = "پولیس کے گرفتار کیے گئے شخص کو مجسٹریٹ کے حکم کے بغیر، عدالت تک سفر کا وقت چھوڑ کر، کتنی دیر حراست میں رکھا جا سکتا ہے؟",
            optionsEn = listOf("12 hours", "24 hours", "48 hours", "72 hours"),
            optionsUr = listOf("12 گھنٹے", "24 گھنٹے", "48 گھنٹے", "72 گھنٹے"),
            correct = 1,
            explanationEn = "Section 61 of the CrPC and Article 10 of the Constitution allow at most 24 hours, excluding the journey, unless a Magistrate authorises longer detention.",
            explanationUr = "ضابطہ فوجداری کی دفعہ 61 اور آئین کے آرٹیکل 10 کے مطابق زیادہ سے زیادہ 24 گھنٹے، سفر کا وقت چھوڑ کر، جب تک مجسٹریٹ مزید حراست کی اجازت نہ دے۔",
            sourceEn = "CrPC, section 61; Constitution, Article 10",
            sourceUr = "ضابطہ فوجداری، دفعہ 61؛ آئین، آرٹیکل 10"
        ),
        DailyQuestion(
            questionEn = "Which section of the Pakistan Penal Code makes each person liable for a criminal act done by several persons in furtherance of their common intention?",
            questionUr = "مجموعہ تعزیراتِ پاکستان کی کون سی دفعہ ایسے جرم میں ہر شخص کو ذمہ دار ٹھہراتی ہے جو کئی افراد نے مشترکہ نیت کے تحت کیا ہو؟",
            optionsEn = listOf("Section 34", "Section 107", "Section 149", "Section 302"),
            optionsUr = listOf("دفعہ 34", "دفعہ 107", "دفعہ 149", "دفعہ 302"),
            correct = 0,
            explanationEn = "Section 34: when a criminal act is done by several persons in furtherance of the common intention of all, each of them is liable as if he alone had done it.",
            explanationUr = "دفعہ 34: جب کئی افراد سب کی مشترکہ نیت کے تحت کوئی جرم کریں تو ان میں سے ہر ایک ایسے ذمہ دار ہے جیسے اس نے اکیلے کیا ہو۔",
            sourceEn = "Pakistan Penal Code, section 34",
            sourceUr = "مجموعہ تعزیراتِ پاکستان، دفعہ 34"
        ),
        DailyQuestion(
            questionEn = "Which section of the Anti-Terrorism Act, 1997 defines \"terrorism\"?",
            questionUr = "انسدادِ دہشت گردی ایکٹ 1997 کی کون سی دفعہ \"دہشت گردی\" کی تعریف کرتی ہے؟",
            optionsEn = listOf("Section 2", "Section 6", "Section 7", "Section 11"),
            optionsUr = listOf("دفعہ 2", "دفعہ 6", "دفعہ 7", "دفعہ 11"),
            correct = 1,
            explanationEn = "Section 6 defines terrorism, and section 7 provides the punishment for acts of terrorism.",
            explanationUr = "دفعہ 6 دہشت گردی کی تعریف کرتی ہے اور دفعہ 7 میں دہشت گردی کے افعال کی سزا بیان کی گئی ہے۔",
            sourceEn = "Anti-Terrorism Act, 1997, sections 6 and 7",
            sourceUr = "انسدادِ دہشت گردی ایکٹ 1997، دفعات 6 اور 7"
        ),
        DailyQuestion(
            questionEn = "In section 299 of the Pakistan Penal Code (qisas and diyat), who is an \"adult\"?",
            questionUr = "مجموعہ تعزیراتِ پاکستان کی دفعہ 299 (قصاص و دیت) میں \"بالغ\" سے کیا مراد ہے؟",
            optionsEn = listOf("A person of 15 years", "A person of 16 years", "A person of 18 years", "A person of 21 years"),
            optionsUr = listOf("15 سال کا شخص", "16 سال کا شخص", "18 سال کا شخص", "21 سال کا شخص"),
            correct = 2,
            explanationEn = "Section 299(a) defines an adult as a person who has attained the age of eighteen years.",
            explanationUr = "دفعہ 299 (الف) کے مطابق بالغ وہ شخص ہے جس کی عمر اٹھارہ سال ہو چکی ہو۔",
            sourceEn = "Pakistan Penal Code, section 299",
            sourceUr = "مجموعہ تعزیراتِ پاکستان، دفعہ 299"
        ),
        DailyQuestion(
            questionEn = "Under section 154 of the CrPC, who records the First Information Report in a cognizable case?",
            questionUr = "ضابطہ فوجداری کی دفعہ 154 کے تحت قابلِ دست اندازی جرم میں ابتدائی اطلاعی رپورٹ کون درج کرتا ہے؟",
            optionsEn = listOf("A Magistrate", "The officer in charge of a police station", "The Public Prosecutor", "A Sessions Judge"),
            optionsUr = listOf("مجسٹریٹ", "تھانے کا انچارج افسر", "پبلک پراسیکیوٹر", "سیشن جج"),
            correct = 1,
            explanationEn = "Information about a cognizable offence is given to the officer in charge of a police station, who records it. This is the FIR.",
            explanationUr = "قابلِ دست اندازی جرم کی اطلاع تھانے کے انچارج افسر کو دی جاتی ہے، جو اسے درج کرتا ہے۔ یہی ایف آئی آر ہے۔",
            sourceEn = "CrPC, section 154",
            sourceUr = "ضابطہ فوجداری، دفعہ 154"
        )
    )

    val knowledge: List<KnowledgeCard> = listOf(
        KnowledgeCard(
            titleEn = "The FIR sets the law in motion",
            titleUr = "ایف آئی آر قانونی کارروائی کا آغاز ہے",
            bodyEn = "The First Information Report (FIR) is recorded by the officer in charge of a police station when he receives information about a cognizable offence. It starts the police investigation. By itself it is not full proof of what happened; it is used to compare with what the informant later says in court.",
            bodyUr = "جب تھانے کے انچارج افسر کو قابلِ دست اندازی جرم کی اطلاع ملتی ہے تو وہ ابتدائی اطلاعی رپورٹ (ایف آئی آر) درج کرتا ہے۔ اس سے پولیس تفتیش شروع ہوتی ہے۔ یہ بذاتِ خود واقعے کا مکمل ثبوت نہیں ہوتی؛ بعد میں عدالت میں مدعی کے بیان سے اس کا موازنہ کیا جاتا ہے۔",
            sourceEn = "CrPC, section 154",
            sourceUr = "ضابطہ فوجداری، دفعہ 154"
        ),
        KnowledgeCard(
            titleEn = "The 24-hour rule",
            titleUr = "24 گھنٹے کا اصول",
            bodyEn = "A person arrested by the police must be produced before a Magistrate within 24 hours, not counting the time needed to travel to the court. Longer detention needs the Magistrate's order. This protection comes from section 61 of the CrPC and Article 10 of the Constitution.",
            bodyUr = "پولیس کے گرفتار کردہ شخص کو 24 گھنٹے کے اندر مجسٹریٹ کے سامنے پیش کرنا لازم ہے، عدالت تک سفر کا وقت شمار نہیں ہوتا۔ اس سے زیادہ حراست کے لیے مجسٹریٹ کا حکم چاہیے۔ یہ تحفظ ضابطہ فوجداری کی دفعہ 61 اور آئین کے آرٹیکل 10 سے ملتا ہے۔",
            sourceEn = "CrPC, section 61; Constitution, Article 10",
            sourceUr = "ضابطہ فوجداری، دفعہ 61؛ آئین، آرٹیکل 10"
        ),
        KnowledgeCard(
            titleEn = "Bailable and non-bailable offences",
            titleUr = "قابلِ ضمانت اور ناقابلِ ضمانت جرائم",
            bodyEn = "In a bailable offence, bail is a matter of right. In a non-bailable offence, the court decides whether to grant bail after looking at the facts. The rules are in sections 496 and 497 of the CrPC.",
            bodyUr = "قابلِ ضمانت جرم میں ضمانت حق کے طور پر ملتی ہے۔ ناقابلِ ضمانت جرم میں عدالت حقائق دیکھ کر فیصلہ کرتی ہے کہ ضمانت دی جائے یا نہیں۔ یہ قواعد ضابطہ فوجداری کی دفعات 496 اور 497 میں ہیں۔",
            sourceEn = "CrPC, sections 496 and 497",
            sourceUr = "ضابطہ فوجداری، دفعات 496 اور 497"
        ),
        KnowledgeCard(
            titleEn = "Common intention and common object",
            titleUr = "مشترکہ نیت اور مشترکہ مقصد",
            bodyEn = "Section 34 of the PPC deals with a criminal act done by several persons in furtherance of their common intention. Section 149 is different: it applies to members of an unlawful assembly when an offence is committed in pursuit of the common object of that assembly.",
            bodyUr = "تعزیراتِ پاکستان کی دفعہ 34 ایسے جرم سے متعلق ہے جو کئی افراد مشترکہ نیت کے تحت کریں۔ دفعہ 149 مختلف ہے: یہ غیر قانونی مجمع کے ارکان پر لاگو ہوتی ہے جب مجمع کے مشترکہ مقصد کے حصول میں کوئی جرم ہو۔",
            sourceEn = "Pakistan Penal Code, sections 34 and 149",
            sourceUr = "مجموعہ تعزیراتِ پاکستان، دفعات 34 اور 149"
        ),
        KnowledgeCard(
            titleEn = "Evidence from modern devices",
            titleUr = "جدید آلات سے حاصل ثبوت",
            bodyEn = "Article 164 of the Qanun-e-Shahadat Order lets the court allow evidence that has become available because of modern devices or techniques, such as recordings, in the cases where it considers this appropriate.",
            bodyUr = "قانونِ شہادت آرڈر کا آرٹیکل 164 عدالت کو اختیار دیتا ہے کہ جن مقدمات میں وہ مناسب سمجھے، جدید آلات یا طریقوں سے حاصل ہونے والا ثبوت، مثلاً ریکارڈنگ، پیش کرنے کی اجازت دے۔",
            sourceEn = "Qanun-e-Shahadat Order, 1984, Article 164",
            sourceUr = "قانونِ شہادت آرڈر 1984، آرٹیکل 164"
        ),
        KnowledgeCard(
            titleEn = "Old police rules and the Police Order",
            titleUr = "پرانے پولیس رولز اور پولیس آرڈر",
            bodyEn = "The Punjab Police Rules, 1934 are old. Under Article 185 of the Police Order, 2002, existing rules continue only so far as they are consistent with the Order. If a rule clashes with the Order, the Order prevails.",
            bodyUr = "پنجاب پولیس رولز 1934 پرانے ہیں۔ پولیس آرڈر 2002 کے آرٹیکل 185 کے تحت موجودہ رولز صرف اسی حد تک جاری رہتے ہیں جس حد تک وہ آرڈر سے مطابقت رکھیں۔ اگر کوئی رول آرڈر سے ٹکرائے تو آرڈر کو ترجیح ہوتی ہے۔",
            sourceEn = "Police Order, 2002, Article 185",
            sourceUr = "پولیس آرڈر 2002، آرٹیکل 185"
        ),
        KnowledgeCard(
            titleEn = "Confessions and the police",
            titleUr = "اعترافات اور پولیس",
            bodyEn = "Article 38 of the Qanun-e-Shahadat Order says a confession made to a police officer cannot be proved against the accused. Article 39 says a confession made while in police custody cannot be proved unless it is made in the immediate presence of a Magistrate.",
            bodyUr = "قانونِ شہادت آرڈر کا آرٹیکل 38 کہتا ہے کہ پولیس افسر کے سامنے کیا گیا اعتراف ملزم کے خلاف ثابت نہیں کیا جا سکتا۔ آرٹیکل 39 کے مطابق پولیس حراست میں کیا گیا اعتراف تب ہی ثابت ہو سکتا ہے جب وہ مجسٹریٹ کی فوری موجودگی میں کیا گیا ہو۔",
            sourceEn = "Qanun-e-Shahadat Order, 1984, Articles 38 and 39",
            sourceUr = "قانونِ شہادت آرڈر 1984، آرٹیکل 38 اور 39"
        ),
        KnowledgeCard(
            titleEn = "Terrorism and the special courts",
            titleUr = "دہشت گردی اور خصوصی عدالتیں",
            bodyEn = "The Anti-Terrorism Act, 1997 defines terrorism in section 6 and gives the punishment for acts of terrorism in section 7. Offences under the Act are tried by special Anti-Terrorism Courts. The Act has been amended several times, so always read the latest text.",
            bodyUr = "انسدادِ دہشت گردی ایکٹ 1997 کی دفعہ 6 میں دہشت گردی کی تعریف اور دفعہ 7 میں دہشت گردی کے افعال کی سزا بیان ہے۔ اس ایکٹ کے جرائم خصوصی انسدادِ دہشت گردی عدالتیں سنتی ہیں۔ اس ایکٹ میں کئی بار ترمیم ہو چکی ہے، اس لیے ہمیشہ تازہ ترین متن پڑھیں۔",
            sourceEn = "Anti-Terrorism Act, 1997, sections 6 and 7",
            sourceUr = "انسدادِ دہشت گردی ایکٹ 1997، دفعات 6 اور 7"
        ),
        KnowledgeCard(
            titleEn = "Arms need a licence",
            titleUr = "اسلحے کے لیے لائسنس ضروری ہے",
            bodyEn = "Under the Punjab Arms Ordinance, 1965, a person may not go armed (section 8) or possess arms, ammunition or military stores (section 9) except under a licence. Selling or repairing arms without a licence is also prohibited (section 4).",
            bodyUr = "پنجاب آرمز آرڈیننس 1965 کے تحت لائسنس کے بغیر اسلحہ لے کر چلنا (دفعہ 8) یا اسلحہ، گولہ بارود یا فوجی سامان رکھنا (دفعہ 9) منع ہے۔ لائسنس کے بغیر اسلحہ بیچنا یا مرمت کرنا بھی ممنوع ہے (دفعہ 4)۔",
            sourceEn = "Punjab Arms Ordinance, 1965, sections 4, 8 and 9",
            sourceUr = "پنجاب آرمز آرڈیننس 1965، دفعات 4، 8 اور 9"
        ),
        KnowledgeCard(
            titleEn = "Probation instead of prison",
            titleUr = "قید کے بجائے پروبیشن",
            bodyEn = "The Probation of Offenders Ordinance, 1960 allows a court to release a suitable offender on probation, under supervision and conditions, instead of sending him to prison. It is mainly meant for first-time and less serious offenders.",
            bodyUr = "پروبیشن آف آفینڈرز آرڈیننس 1960 عدالت کو اختیار دیتا ہے کہ مناسب مجرم کو جیل بھیجنے کے بجائے نگرانی اور شرائط کے ساتھ پروبیشن پر رہا کر دے۔ یہ بنیادی طور پر پہلی بار جرم کرنے والوں اور کم سنگین جرائم کے لیے ہے۔",
            sourceEn = "Probation of Offenders Ordinance, 1960",
            sourceUr = "پروبیشن آف آفینڈرز آرڈیننس 1960"
        )
    )
}
