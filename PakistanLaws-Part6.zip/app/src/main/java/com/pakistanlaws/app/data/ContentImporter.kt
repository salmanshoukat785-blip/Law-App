package com.pakistanlaws.app.data

import android.content.Context
import androidx.room.withTransaction
import com.pakistanlaws.app.data.db.AppDatabase
import com.pakistanlaws.app.data.db.LawEntity
import com.pakistanlaws.app.data.db.QuestionEntity
import com.pakistanlaws.app.data.db.SectionEntity
import org.json.JSONArray
import org.json.JSONObject

/**
 * Loads the law texts that ship inside the app (the .json files in assets/laws) into the database.
 * Raise [CONTENT_VERSION] whenever a law file changes so phones re-import it.
 */
object ContentImporter {

    const val CONTENT_VERSION = 2

    suspend fun importIfNeeded(context: Context) {
        val prefs = Prefs(context)
        val db = AppDatabase.get(context)
        if (prefs.contentVersion() >= CONTENT_VERSION &&
            db.lawDao().count() > 0 &&
            db.questionDao().count() > 0
        ) return

        val files = context.assets.list("laws")
            ?.filter { it.endsWith(".json") }
            ?.sorted()
            ?: return

        for (file in files) {
            val json = context.assets.open("laws/$file")
                .bufferedReader(Charsets.UTF_8)
                .use { it.readText() }
            val obj = JSONObject(json)
            val lawId = obj.getString("id")

            val law = LawEntity(
                id = lawId,
                titleEn = obj.getString("titleEn"),
                titleUr = obj.optString("titleUr", ""),
                shortName = obj.optString("shortName", lawId),
                sortOrder = obj.optInt("sortOrder", 99),
                noteEn = obj.optString("noteEn", ""),
                noteUr = obj.optString("noteUr", "")
            )

            val array = obj.getJSONArray("sections")
            val sections = ArrayList<SectionEntity>(array.length())
            for (i in 0 until array.length()) {
                val s = array.getJSONObject(i)
                sections.add(
                    SectionEntity(
                        id = s.getString("id"),
                        lawId = lawId,
                        number = s.getString("number"),
                        chapter = s.optString("chapter", ""),
                        chapterUr = s.optString("chapterUr", ""),
                        titleEn = s.getString("titleEn"),
                        titleUr = s.optString("titleUr", ""),
                        shortEn = s.optString("shortEn", ""),
                        shortUr = s.optString("shortUr", ""),
                        longEn = s.optString("longEn", ""),
                        longUr = s.optString("longUr", ""),
                        originalText = s.optString("originalText", ""),
                        sortOrder = s.optInt("sortOrder", i + 1),
                        isImportant = s.optBoolean("isImportant", false),
                        needsVerify = s.optBoolean("needsVerify", false)
                    )
                )
            }

            db.withTransaction {
                db.sectionDao().deleteByLaw(lawId)
                db.lawDao().insertAll(listOf(law))
                db.sectionDao().insertAll(sections)
            }
        }
        importQuestions(context, db)
        prefs.setContentVersion(CONTENT_VERSION)
    }

    /** Loads assets/quiz/questions.json (a list of questions) into the database. */
    private suspend fun importQuestions(context: Context, db: AppDatabase) {
        val json = try {
            context.assets.open("quiz/questions.json")
                .bufferedReader(Charsets.UTF_8)
                .use { it.readText() }
        } catch (e: java.io.IOException) {
            return
        }
        val array = JSONArray(json)
        val questions = ArrayList<QuestionEntity>(array.length())
        for (i in 0 until array.length()) {
            val q = array.getJSONObject(i)
            questions.add(
                QuestionEntity(
                    id = q.getString("id"),
                    lawId = q.getString("lawId"),
                    topicEn = q.optString("topicEn", ""),
                    topicUr = q.optString("topicUr", ""),
                    difficulty = q.optInt("difficulty", 2),
                    textEn = q.getString("textEn"),
                    textUr = q.optString("textUr", ""),
                    optionsEn = q.getString("optionsEn"),
                    optionsUr = q.optString("optionsUr", ""),
                    correctIndex = q.getInt("correctIndex"),
                    explanationEn = q.optString("explanationEn", ""),
                    explanationUr = q.optString("explanationUr", ""),
                    ref = q.optString("ref", "")
                )
            )
        }
        db.withTransaction {
            db.questionDao().deleteAll()
            db.questionDao().insertAll(questions)
        }
    }
}
