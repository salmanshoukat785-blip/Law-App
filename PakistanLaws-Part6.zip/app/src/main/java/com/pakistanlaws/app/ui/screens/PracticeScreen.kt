package com.pakistanlaws.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.pakistanlaws.app.R
import com.pakistanlaws.app.ui.QuizConfig
import com.pakistanlaws.app.ui.QuizMode
import com.pakistanlaws.app.ui.QuizViewModel
import com.pakistanlaws.app.ui.components.SectionHeader

fun quizModeIcon(mode: QuizMode): ImageVector = when (mode) {
    QuizMode.PRACTICE -> Icons.Filled.School
    QuizMode.RANDOM -> Icons.Filled.Shuffle
    QuizMode.SELF_TEST -> Icons.Filled.Checklist
    QuizMode.EXAM -> Icons.Filled.Timer
    QuizMode.SPEED -> Icons.Filled.Bolt
    QuizMode.SURVIVAL -> Icons.Filled.Favorite
    QuizMode.DAILY -> Icons.Filled.Today
    QuizMode.WEEKLY -> Icons.Filled.DateRange
}

/** The Practice tab: daily and weekly challenges, the quiz modes and recent results. */
@Composable
fun PracticeScreen(
    vm: QuizViewModel,
    onOpenSetup: (QuizMode) -> Unit,
    onPlay: () -> Unit
) {
    val state by vm.state.collectAsState()
    val dailyDone by vm.dailyDone.collectAsState()
    val weeklyDone by vm.weeklyDone.collectAsState()
    val recent by vm.recent.collectAsState()
    val bank by vm.bank.collectAsState()

    val running = state?.let { it.outcome == null && !it.loading && it.questions.isNotEmpty() } == true

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = stringResource(R.string.tab_practice),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        if (bank.isEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(
                text = stringResource(R.string.play_no_questions),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (running) {
            Spacer(Modifier.height(16.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = stringResource(R.string.quiz_resume),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                    Text(
                        text = stringResource(R.string.quiz_resume_desc),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onPlay) { Text(stringResource(R.string.continue_resume)) }
                        OutlinedButton(onClick = { vm.quit() }) {
                            Text(stringResource(R.string.quiz_discard))
                        }
                    }
                }
            }
        }

        // Daily and weekly challenges
        Spacer(Modifier.height(16.dp))
        ChallengeCard(
            mode = QuizMode.DAILY,
            percentDone = dailyDone?.percent,
            enabled = bank.isNotEmpty(),
            onStart = {
                vm.start(QuizConfig(QuizMode.DAILY, count = 5))
                onPlay()
            }
        )
        Spacer(Modifier.height(12.dp))
        ChallengeCard(
            mode = QuizMode.WEEKLY,
            percentDone = weeklyDone?.percent,
            enabled = bank.isNotEmpty(),
            onStart = {
                vm.start(QuizConfig(QuizMode.WEEKLY, count = 15))
                onPlay()
            }
        )

        // Modes
        SectionHeader(stringResource(R.string.quiz_modes_title))
        val modes = listOf(
            QuizMode.PRACTICE, QuizMode.RANDOM, QuizMode.SELF_TEST,
            QuizMode.EXAM, QuizMode.SPEED, QuizMode.SURVIVAL
        )
        modes.chunked(2).forEach { pair ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                pair.forEach { mode ->
                    ModeCard(
                        mode = mode,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            if (mode == QuizMode.RANDOM) {
                                vm.start(QuizConfig(QuizMode.RANDOM, count = 10))
                                onPlay()
                            } else {
                                onOpenSetup(mode)
                            }
                        }
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        // Recent results
        SectionHeader(stringResource(R.string.result_recent))
        if (recent.isEmpty()) {
            Text(
                text = stringResource(R.string.result_empty),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            recent.take(5).forEach { result ->
                val mode = QuizMode.values().firstOrNull { it.name == result.mode }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (mode != null) stringResource(mode.titleRes) else result.mode,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = result.correct.toString() + "/" + result.total +
                            "  ·  " + result.percent + "%",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ChallengeCard(
    mode: QuizMode,
    percentDone: Int?,
    enabled: Boolean,
    onStart: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = quizModeIcon(mode),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.size(32.dp)
            )
            Spacer(Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(mode.titleRes),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    text = if (percentDone != null) stringResource(R.string.quiz_done_format, percentDone)
                    else stringResource(mode.descRes),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
            if (percentDone == null) {
                Button(onClick = onStart, enabled = enabled) {
                    Text(stringResource(R.string.quiz_start))
                }
            }
        }
    }
}

@Composable
private fun ModeCard(mode: QuizMode, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Icon(
                imageVector = quizModeIcon(mode),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(mode.titleRes),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = stringResource(mode.descRes),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
