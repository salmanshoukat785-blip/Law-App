package com.pakistanlaws.app.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** One law, for example the Punjab Arms Ordinance. */
@Entity(tableName = "laws")
data class LawEntity(
    @PrimaryKey val id: String,
    val titleEn: String,
    val titleUr: String,
    val shortName: String,
    val sortOrder: Int,
    /** A note about which amendments the text includes. */
    val noteEn: String,
    val noteUr: String
)

/** One section, article or rule of a law, with its short and long explanations. */
@Entity(tableName = "sections", indices = [Index("lawId")])
data class SectionEntity(
    @PrimaryKey val id: String,
    val lawId: String,
    val number: String,
    val chapter: String,
    val chapterUr: String,
    val titleEn: String,
    val titleUr: String,
    val shortEn: String,
    val shortUr: String,
    val longEn: String,
    val longUr: String,
    val originalText: String,
    val sortOrder: Int,
    val isImportant: Boolean,
    /** True when the text must still be checked against the official Gazette. */
    val needsVerify: Boolean
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey val sectionId: String,
    val createdAt: Long
)

@Entity(tableName = "notes", indices = [Index("sectionId")])
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sectionId: String?,
    val subject: String,
    val title: String,
    val body: String,
    val createdAt: Long,
    val updatedAt: Long
)

/** Result row for "how many sections does each law have". */
data class LawCount(
    val lawId: String,
    val count: Int
)

/**
 * One multiple-choice question. The four options of each language are stored in one text,
 * separated by a new line, in the same order in both languages.
 */
@Entity(tableName = "questions", indices = [Index("lawId")])
data class QuestionEntity(
    @PrimaryKey val id: String,
    val lawId: String,
    val topicEn: String,
    val topicUr: String,
    /** 1 = easy, 2 = medium, 3 = hard */
    val difficulty: Int,
    val textEn: String,
    val textUr: String,
    val optionsEn: String,
    val optionsUr: String,
    val correctIndex: Int,
    val explanationEn: String,
    val explanationUr: String,
    val ref: String
)

/** The summary of one finished quiz. [periodKey] is set for daily and weekly challenges. */
@Entity(tableName = "quiz_results", indices = [Index("periodKey")])
data class QuizResultEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val mode: String,
    val lawId: String?,
    val total: Int,
    val correct: Int,
    val wrong: Int,
    val skipped: Int,
    val score: Double,
    val percent: Int,
    val durationSec: Int,
    val finishedAt: Long,
    val periodKey: String
)

/** One answered question, kept so wrong answers can be revised later. */
@Entity(tableName = "answer_records", indices = [Index("questionId")])
data class AnswerRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val questionId: String,
    val correct: Boolean,
    val answeredAt: Long,
    val mode: String
)
