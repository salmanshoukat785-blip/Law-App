package com.pakistanlaws.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LawDao {
    @Query("SELECT * FROM laws ORDER BY sortOrder")
    fun observeAll(): Flow<List<LawEntity>>

    @Query("SELECT * FROM laws WHERE id = :id")
    fun observeLaw(id: String): Flow<LawEntity?>

    @Query("SELECT COUNT(*) FROM laws")
    fun observeCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM laws")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<LawEntity>)
}

@Dao
interface SectionDao {
    @Query("SELECT * FROM sections WHERE lawId = :lawId ORDER BY sortOrder")
    fun observeByLaw(lawId: String): Flow<List<SectionEntity>>

    @Query("SELECT * FROM sections WHERE id = :id")
    suspend fun getById(id: String): SectionEntity?

    @Query("SELECT * FROM sections WHERE id IN (:ids)")
    suspend fun getByIds(ids: List<String>): List<SectionEntity>

    @Query(
        "SELECT * FROM sections WHERE titleEn LIKE '%' || :query || '%' " +
            "OR titleUr LIKE '%' || :query || '%' " +
            "OR number LIKE :query || '%' ORDER BY lawId, sortOrder LIMIT 100"
    )
    fun search(query: String): Flow<List<SectionEntity>>

    @Query("SELECT lawId AS lawId, COUNT(*) AS count FROM sections GROUP BY lawId")
    fun observeCounts(): Flow<List<LawCount>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<SectionEntity>)

    @Query("DELETE FROM sections WHERE lawId = :lawId")
    suspend fun deleteByLaw(lawId: String)

    @Query("SELECT COUNT(*) FROM sections")
    suspend fun count(): Int
}

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<BookmarkEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE sectionId = :sectionId)")
    fun observeIsBookmarked(sectionId: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(bookmark: BookmarkEntity)

    @Query("DELETE FROM bookmarks WHERE sectionId = :sectionId")
    suspend fun delete(sectionId: String)
}

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<NoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(note: NoteEntity): Long

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface QuestionDao {
    @Query("SELECT * FROM questions ORDER BY id")
    fun observeAll(): Flow<List<QuestionEntity>>

    @Query("SELECT * FROM questions ORDER BY id")
    suspend fun getAll(): List<QuestionEntity>

    @Query("SELECT COUNT(*) FROM questions")
    suspend fun count(): Int

    @Query("DELETE FROM questions")
    suspend fun deleteAll()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<QuestionEntity>)
}

@Dao
interface QuizResultDao {
    @Insert
    suspend fun insert(result: QuizResultEntity): Long

    @Query("SELECT * FROM quiz_results ORDER BY finishedAt DESC LIMIT 20")
    fun observeRecent(): Flow<List<QuizResultEntity>>

    @Query("SELECT * FROM quiz_results WHERE periodKey = :key ORDER BY finishedAt DESC LIMIT 1")
    fun observeByPeriod(key: String): Flow<QuizResultEntity?>
}

@Dao
interface AnswerRecordDao {
    @Insert
    suspend fun insertAll(items: List<AnswerRecordEntity>)
}
