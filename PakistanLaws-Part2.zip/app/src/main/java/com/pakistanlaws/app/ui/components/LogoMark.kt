package com.pakistanlaws.app.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.pakistanlaws.app.ui.theme.Brand

/** The scales-of-justice logo. It fades in, grows and then swings gently when [animate] is true. */
@Composable
fun LogoMark(
    modifier: Modifier = Modifier,
    logoSize: Dp = 120.dp,
    animate: Boolean = true
) {
    val reveal = remember { Animatable(if (animate) 0f else 1f) }
    val swing = remember { Animatable(0f) }

    LaunchedEffect(animate) {
        if (animate) {
            reveal.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
            swing.snapTo(9f)
            swing.animateTo(0f, spring(dampingRatio = 0.25f, stiffness = 35f))
        }
    }

    Canvas(modifier = modifier.size(logoSize)) {
        val u = this.size.minDimension / 108f
        val a = reveal.value
        val c = Brand.Gold.copy(alpha = a)
        val w = 3f * u

        fun p(x: Float, y: Float) = Offset(x * u, y * u)

        scale(0.6f + 0.4f * a, pivot = center) {
            drawLine(color = c, start = p(54f, 28f), end = p(54f, 76f), strokeWidth = w, cap = StrokeCap.Round)
            drawLine(color = c, start = p(38f, 76f), end = p(70f, 76f), strokeWidth = w, cap = StrokeCap.Round)

            rotate(swing.value, pivot = p(54f, 36f)) {
                drawLine(color = c, start = p(30f, 36f), end = p(78f, 36f), strokeWidth = w, cap = StrokeCap.Round)

                drawLine(color = c, start = p(30f, 36f), end = p(22f, 56f), strokeWidth = w, cap = StrokeCap.Round)
                drawLine(color = c, start = p(30f, 36f), end = p(38f, 56f), strokeWidth = w, cap = StrokeCap.Round)
                drawLine(color = c, start = p(78f, 36f), end = p(70f, 56f), strokeWidth = w, cap = StrokeCap.Round)
                drawLine(color = c, start = p(78f, 36f), end = p(86f, 56f), strokeWidth = w, cap = StrokeCap.Round)

                drawArc(
                    color = c,
                    startAngle = 0f,
                    sweepAngle = 180f,
                    useCenter = true,
                    topLeft = p(20f, 48f),
                    size = Size(20f * u, 16f * u)
                )
                drawArc(
                    color = c,
                    startAngle = 0f,
                    sweepAngle = 180f,
                    useCenter = true,
                    topLeft = p(68f, 48f),
                    size = Size(20f * u, 16f * u)
                )
            }
        }
    }
}

/** The logo on a rounded deep-green tile, readable on light and dark backgrounds. */
@Composable
fun LogoBadge(
    modifier: Modifier = Modifier,
    badgeSize: Dp = 96.dp,
    animate: Boolean = false
) {
    Box(
        modifier = modifier
            .size(badgeSize)
            .clip(RoundedCornerShape(badgeSize * 0.26f))
            .background(Brand.Green),
        contentAlignment = Alignment.Center
    ) {
        LogoMark(logoSize = badgeSize * 0.8f, animate = animate)
    }
}
