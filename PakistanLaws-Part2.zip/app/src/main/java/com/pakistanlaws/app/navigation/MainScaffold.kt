package com.pakistanlaws.app.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.pakistanlaws.app.ui.AppViewModel
import com.pakistanlaws.app.ui.components.PlaceholderScreen
import com.pakistanlaws.app.ui.components.UserGuideDialog
import com.pakistanlaws.app.ui.screens.ProfileScreen

@Composable
fun MainScaffold(vm: AppViewModel, onLoggedOut: () -> Unit) {
    val tabNav = rememberNavController()
    val backStackEntry by tabNav.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val guideSeen by vm.guideSeen.collectAsState()

    if (!guideSeen) {
        UserGuideDialog(onFinish = { vm.markGuideSeen() })
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                BottomTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = currentRoute == tab.route,
                        onClick = {
                            tabNav.navigate(tab.route) {
                                popUpTo(tabNav.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = {
                            Icon(tab.icon, contentDescription = stringResource(tab.label))
                        },
                        label = { Text(stringResource(tab.label)) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = tabNav,
            startDestination = BottomTab.HOME.route,
            modifier = Modifier.padding(padding)
        ) {
            BottomTab.entries.forEach { tab ->
                composable(tab.route) {
                    if (tab == BottomTab.PROFILE) {
                        ProfileScreen(vm = vm, onLoggedOut = onLoggedOut)
                    } else {
                        PlaceholderScreen(
                            title = stringResource(tab.label),
                            icon = tab.icon
                        )
                    }
                }
            }
        }
    }
}
