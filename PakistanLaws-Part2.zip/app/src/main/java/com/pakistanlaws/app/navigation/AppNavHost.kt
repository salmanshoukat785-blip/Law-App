package com.pakistanlaws.app.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.pakistanlaws.app.ui.AppViewModel
import com.pakistanlaws.app.ui.Session
import com.pakistanlaws.app.ui.screens.AuthChooserScreen
import com.pakistanlaws.app.ui.screens.GuestNameScreen
import com.pakistanlaws.app.ui.screens.LoginScreen
import com.pakistanlaws.app.ui.screens.OnboardingScreen
import com.pakistanlaws.app.ui.screens.PendingScreen
import com.pakistanlaws.app.ui.screens.SignUpScreen
import com.pakistanlaws.app.ui.screens.SplashScreen
import com.pakistanlaws.app.ui.screens.WelcomeScreen

/** Moves to the screen for [session] and clears everything behind it. */
private fun NavController.goTo(session: Session) {
    val target = routeFor(session)
    if (target == Routes.SPLASH) return
    navigate(target) {
        popUpTo(graph.id) { inclusive = true }
        launchSingleTop = true
    }
}

@Composable
fun AppNavHost(vm: AppViewModel = viewModel()) {
    val nav = rememberNavController()

    NavHost(navController = nav, startDestination = Routes.SPLASH) {
        composable(Routes.SPLASH) {
            SplashScreen(vm = vm, onReady = { nav.goTo(it) })
        }
        composable(Routes.WELCOME) {
            WelcomeScreen(onContinue = { nav.navigate(Routes.ONBOARDING) })
        }
        composable(Routes.ONBOARDING) {
            OnboardingScreen(
                onDone = {
                    vm.completeOnboarding()
                    nav.goTo(Session.NeedsAuth)
                }
            )
        }
        composable(Routes.AUTH) {
            AuthChooserScreen(
                onLogin = { nav.navigate(Routes.LOGIN) },
                onSignUp = { nav.navigate(Routes.SIGNUP) },
                onGuest = { nav.navigate(Routes.GUEST) }
            )
        }
        composable(Routes.LOGIN) {
            LoginScreen(
                vm = vm,
                onSession = { nav.goTo(it) },
                onSignUp = {
                    nav.navigate(Routes.SIGNUP) {
                        popUpTo(Routes.AUTH)
                        launchSingleTop = true
                    }
                },
                onBack = { nav.popBackStack() }
            )
        }
        composable(Routes.SIGNUP) {
            SignUpScreen(
                vm = vm,
                onSession = { nav.goTo(it) },
                onLogin = {
                    nav.navigate(Routes.LOGIN) {
                        popUpTo(Routes.AUTH)
                        launchSingleTop = true
                    }
                },
                onBack = { nav.popBackStack() }
            )
        }
        composable(Routes.GUEST) {
            GuestNameScreen(
                vm = vm,
                onSession = { nav.goTo(it) },
                onBack = { nav.popBackStack() }
            )
        }
        composable(Routes.PENDING) {
            PendingScreen(vm = vm, onSession = { nav.goTo(it) })
        }
        composable(Routes.MAIN) {
            MainScaffold(vm = vm, onLoggedOut = { nav.goTo(Session.NeedsAuth) })
        }
    }
}
