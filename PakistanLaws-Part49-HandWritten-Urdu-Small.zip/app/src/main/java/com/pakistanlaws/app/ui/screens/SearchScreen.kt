package com.pakistanlaws.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pakistanlaws.app.R
import com.pakistanlaws.app.content.LawCatalog
import com.pakistanlaws.app.ui.SearchViewModel
import com.pakistanlaws.app.ui.components.SectionHeader
import com.pakistanlaws.app.ui.theme.Language

@Composable
fun SearchScreen(
    onBack: () -> Unit,
    onOpenLaw: (String) -> Unit,
    onOpenSection: (String) -> Unit,
    vm: SearchViewModel = viewModel()
) {
    val query by vm.query.collectAsState()
    val laws by vm.laws.collectAsState()
    val sections by vm.sections.collectAsState()
    val urdu = Language.isUrdu(LocalConfiguration.current)
    val focus = remember { FocusRequester() }

    LaunchedEffect(Unit) { focus.requestFocus() }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = stringResource(R.string.action_back)
                )
            }
            OutlinedTextField(
                value = query,
                onValueChange = { vm.setQuery(it) },
                singleLine = true,
                placeholder = { Text(stringResource(R.string.search_hint)) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                modifier = Modifier
                    .weight(1f)
                    .focusRequester(focus)
            )
        }

        val trimmed = query.trim()
        when {
            trimmed.length < 2 -> {
                Text(
                    text = stringResource(R.string.search_hint_min),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(24.dp)
                )
            }
            laws.isEmpty() && sections.isEmpty() -> {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        text = stringResource(R.string.search_no_results),
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.search_content_note),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            else -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    if (laws.isNotEmpty()) {
                        item { SectionHeader(stringResource(R.string.search_laws_header)) }
                        items(laws, key = { "law-" + it.id }) { law ->
                            ResultCard(
                                title = law.name(urdu),
                                subtitle = law.shortName,
                                onClick = { onOpenLaw(law.id) }
                            )
                        }
                    }
                    if (sections.isNotEmpty()) {
                        item { SectionHeader(stringResource(R.string.search_sections_header)) }
                        items(sections, key = { "section-" + it.id }) { section ->
                            val lawName = LawCatalog.laws.firstOrNull { it.id == section.lawId }?.shortName
                                ?: section.lawId
                            ResultCard(
                                title = section.number + "  " +
                                    com.pakistanlaws.app.ui.components.rememberUrdu(section.titleEn, section.titleUr),
                                subtitle = lawName,
                                onClick = { onOpenSection(section.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultCard(title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
