package com.pakistanlaws.app.data

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import android.provider.Settings
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

/** Thrown when the account is already in use on another phone (one account = one phone). */
class DeviceLimitException : Exception()

/** Thrown at login when the account was already moved to a new phone too many times this month. */
class DeviceSwapLimitException : Exception()

private const val MAX_PHONE_SWAPS_PER_MONTH = 3

/**
 * Talks to Firebase. Accounts use Firebase Auth (mobile number + 6-digit PIN) and
 * every account has a Firestore document users/{uid} whose "status" the admin
 * changes from the Firebase console: pending -> approved (or rejected).
 */
class AuthRepository(private val context: Context) {

    /** False until app/google-services.json has been added to the project. */
    val isConfigured: Boolean
        get() = FirebaseApp.getApps(context).isNotEmpty()

    private val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    private val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()

    /**
     * A stable id for this phone. The MediaDrm id survives reinstalling the app and does not
     * depend on the app signature; if a phone cannot give it, ANDROID_ID is used instead.
     */
    private val deviceId: String
        get() {
            val drm = runCatching {
                val uuid = java.util.UUID(-0x121074568629b532L, -0x5c37d8232ae2de13L)
                val md = android.media.MediaDrm(uuid)
                try {
                    val bytes = md.getPropertyByteArray("deviceUniqueId")
                    java.security.MessageDigest.getInstance("SHA-256").digest(bytes)
                        .joinToString("") { "%02x".format(it) }
                } finally {
                    md.release()
                }
            }.getOrNull()
            if (!drm.isNullOrBlank()) return "d2-" + drm.take(32)
            return Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID).orEmpty()
        }

    fun currentUid(): String? = if (isConfigured) auth.currentUser?.uid else null

    suspend fun signUp(name: String, phone: String, pin: String): UserProfile {
        val result = auth.createUserWithEmailAndPassword(PhoneUtil.toEmail(phone), pin).await()
        val uid = result.user?.uid ?: throw IllegalStateException("No user id")
        db.collection("users").document(uid).set(
            hashMapOf(
                "name" to name,
                "phone" to phone,
                "status" to STATUS_PENDING,
                "deviceId" to deviceId,
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
        return UserProfile(uid, name, phone, STATUS_PENDING)
    }

    suspend fun signIn(phone: String, pin: String): UserProfile {
        val result = auth.signInWithEmailAndPassword(PhoneUtil.toEmail(phone), pin).await()
        val uid = result.user?.uid ?: throw IllegalStateException("No user id")
        return fetchProfile(uid, phone, allowTakeover = true)
    }

    suspend fun fetchProfile(
        uid: String,
        fallbackPhone: String? = null,
        allowTakeover: Boolean = false
    ): UserProfile {
        val ref = db.collection("users").document(uid)
        val snap = ref.get().await()
        if (snap.exists()) {
            // One account works on one phone only.
            val bound = snap.getString("deviceId").orEmpty()
            val mine = deviceId
            if (bound.isNotBlank() && mine.isNotBlank() && bound != mine) {
                if (!allowTakeover) {
                    // The account was logged in on another phone: this phone is logged out.
                    auth.signOut()
                    throw DeviceLimitException()
                }
                // A fresh login with the correct PIN moves the account to this phone,
                // at most MAX_PHONE_SWAPS_PER_MONTH times a month.
                val month = java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.US)
                    .format(java.util.Date())
                val used = if (snap.getString("swapMonth") == month) {
                    (snap.getLong("swapCount") ?: 0L).toInt()
                } else 0
                if (used >= MAX_PHONE_SWAPS_PER_MONTH) {
                    auth.signOut()
                    throw DeviceSwapLimitException()
                }
                try {
                    ref.set(
                        hashMapOf(
                            "deviceId" to mine,
                            "swapMonth" to month,
                            "swapCount" to used + 1
                        ),
                        SetOptions.merge()
                    ).await()
                } catch (e: Exception) {
                    auth.signOut()
                    throw e
                }
            }
            if (bound.isBlank() && mine.isNotBlank()) {
                runCatching { ref.set(hashMapOf("deviceId" to mine), SetOptions.merge()).await() }
            }
            return snap.toProfile(uid)
        }

        // The account exists but its profile was never saved (for example the network dropped
        // during sign up). Recreate it as pending so the admin can still approve it.
        val phone = fallbackPhone
            ?: auth.currentUser?.email?.substringBefore("@").orEmpty()
        ref.set(
            hashMapOf(
                "name" to "",
                "phone" to phone,
                "status" to STATUS_PENDING,
                "deviceId" to deviceId,
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
        return UserProfile(uid, "", phone, STATUS_PENDING)
    }

    /** Live updates, so the "waiting" screen opens the app as soon as the admin approves. */
    fun observeProfile(uid: String): Flow<UserProfile?> = callbackFlow {
        val registration = db.collection("users").document(uid)
            .addSnapshotListener { snap, error ->
                if (error != null) return@addSnapshotListener
                trySend(if (snap != null && snap.exists()) snap.toProfile(uid) else null)
            }
        awaitClose { registration.remove() }
    }

    fun signOut() {
        if (isConfigured) auth.signOut()
    }

    /** On a normal log out the account is freed, so it can be used on another phone. */
    suspend fun releaseDevice() {
        val uid = currentUid() ?: return
        val ref = db.collection("users").document(uid)
        val snap = ref.get().await()
        if (snap.getString("deviceId") == deviceId) {
            ref.set(hashMapOf("deviceId" to ""), SetOptions.merge()).await()
        }
    }

    private fun DocumentSnapshot.toProfile(uid: String) = UserProfile(
        uid = uid,
        name = getString("name").orEmpty(),
        phone = getString("phone").orEmpty(),
        status = getString("status")?.trim()?.lowercase() ?: STATUS_PENDING
    )
}
