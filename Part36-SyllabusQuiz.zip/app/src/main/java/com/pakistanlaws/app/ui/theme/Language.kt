package com.pakistanlaws.app.ui.theme

import android.content.res.Configuration
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

/** The app is English only. Every screen asks [isUrdu], so it always answers false. */
object Language {
    @Suppress("UNUSED_PARAMETER")
    fun isUrdu(config: Configuration): Boolean = false

    /** Clears any Urdu choice saved by an older version of the app. */
    fun forceEnglish() {
        val saved = AppCompatDelegate.getApplicationLocales()
        if (!saved.isEmpty() && saved.toLanguageTags() != "en") {
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags("en"))
        }
    }
}
