package com.pakistanlaws.app.data

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

/**
 * Talks to Firebase. Accounts use Firebase Auth (mobile number + 6-digit PIN) and
 * every account has a Firestore document users/{uid} whose "status" the admin
 * changes from the Firebase console: pending -> approved (or rejected).
 */
class AuthRepository(private val context: Context) {

    /** False until app/google-services.json has been added to the project. */
    val isConfigured: Boolean
        get() = FirebaseApp.getApps(context).isNotEmpty()

    private val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    private val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()

    fun currentUid(): String? = if (isConfigured) auth.currentUser?.uid else null

    suspend fun signUp(name: String, phone: String, pin: String): UserProfile {
        val result = auth.createUserWithEmailAndPassword(PhoneUtil.toEmail(phone), pin).await()
        val uid = result.user?.uid ?: throw IllegalStateException("No user id")
        db.collection("users").document(uid).set(
            hashMapOf(
                "name" to name,
                "phone" to phone,
                "status" to STATUS_PENDING,
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
        return UserProfile(uid, name, phone, STATUS_PENDING)
    }

    suspend fun signIn(phone: String, pin: String): UserProfile {
        val result = auth.signInWithEmailAndPassword(PhoneUtil.toEmail(phone), pin).await()
        val uid = result.user?.uid ?: throw IllegalStateException("No user id")
        return fetchProfile(uid, phone)
    }

    suspend fun fetchProfile(uid: String, fallbackPhone: String? = null): UserProfile {
        val ref = db.collection("users").document(uid)
        val snap = ref.get().await()
        if (snap.exists()) return snap.toProfile(uid)

        // The account exists but its profile was never saved (for example the network dropped
        // during sign up). Recreate it as pending so the admin can still approve it.
        val phone = fallbackPhone
            ?: auth.currentUser?.email?.substringBefore("@").orEmpty()
        ref.set(
            hashMapOf(
                "name" to "",
                "phone" to phone,
                "status" to STATUS_PENDING,
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
        return UserProfile(uid, "", phone, STATUS_PENDING)
    }

    /** Live updates, so the "waiting" screen opens the app as soon as the admin approves. */
    fun observeProfile(uid: String): Flow<UserProfile?> = callbackFlow {
        val registration = db.collection("users").document(uid)
            .addSnapshotListener { snap, error ->
                if (error != null) return@addSnapshotListener
                trySend(if (snap != null && snap.exists()) snap.toProfile(uid) else null)
            }
        awaitClose { registration.remove() }
    }

    fun signOut() {
        if (isConfigured) auth.signOut()
    }

    private fun DocumentSnapshot.toProfile(uid: String) = UserProfile(
        uid = uid,
        name = getString("name").orEmpty(),
        phone = getString("phone").orEmpty(),
        status = getString("status")?.trim()?.lowercase() ?: STATUS_PENDING
    )
}
