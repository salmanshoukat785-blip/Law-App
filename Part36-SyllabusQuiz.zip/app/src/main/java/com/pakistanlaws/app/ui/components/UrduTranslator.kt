package com.pakistanlaws.app.ui.components

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.tasks.await

/**
 * English to Urdu machine translation with Google ML Kit.
 * The Urdu language pack (about 30 MB) is downloaded once, which needs the internet.
 * After that it also works offline.
 */
object UrduTranslator {
    private val translator by lazy {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.URDU)
                .build()
        )
    }

    private val cache = HashMap<String, String>()
    private var modelReady = false

    private suspend fun ensureModel() {
        if (modelReady) return
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
        modelReady = true
    }

    /** Splits a long text into pieces of at most [limit] characters at sentence ends. */
    private fun chunks(line: String, limit: Int = 400): List<String> {
        if (line.length <= limit) return listOf(line)
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (part in line.split(Regex("(?<=[.;:])\\s+"))) {
            if (sb.isNotEmpty() && sb.length + part.length + 1 > limit) {
                out.add(sb.toString())
                sb.clear()
            }
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(part)
        }
        if (sb.isNotEmpty()) out.add(sb.toString())
        return out
    }

    /** Translates [text]; paragraph breaks are kept. Throws if the pack cannot be downloaded. */
    suspend fun translate(text: String): String {
        if (text.isBlank()) return text
        cache[text]?.let { return it }
        ensureModel()
        val result = text.split("\n").joinToString("\n") { line ->
            if (line.isBlank()) line
            else chunks(line.trim()).joinToString(" ") { translator.translate(it).await() }
        }
        cache[text] = result
        return result
    }
}
