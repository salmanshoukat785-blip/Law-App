package com.pakistanlaws.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Style
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pakistanlaws.app.R
import com.pakistanlaws.app.content.DailyContent
import com.pakistanlaws.app.data.HomeData
import com.pakistanlaws.app.navigation.BottomTab
import com.pakistanlaws.app.ui.HomeViewModel
import com.pakistanlaws.app.ui.components.ContinueCard
import com.pakistanlaws.app.ui.components.DailyQuestionCard
import com.pakistanlaws.app.ui.components.GoalsCard
import com.pakistanlaws.app.ui.components.GoalsDialog
import com.pakistanlaws.app.ui.components.KnowledgeCardView
import com.pakistanlaws.app.ui.components.LogoMark
import com.pakistanlaws.app.ui.components.QuickCard
import com.pakistanlaws.app.ui.components.SectionHeader
import com.pakistanlaws.app.ui.theme.Language
import java.time.LocalDate

@Composable
fun HomeScreen(
    name: String,
    onOpenSearch: () -> Unit,
    onOpenTab: (BottomTab) -> Unit,
    onOpenSection: (String) -> Unit,
    onOpenBank: () -> Unit,
    homeVm: HomeViewModel = viewModel()
) {
    val saved by homeVm.data.collectAsState()
    val data = saved ?: HomeData()
    val recent by homeVm.recent.collectAsState()
    val urdu = Language.isUrdu(LocalConfiguration.current)

    val epochDay = remember { LocalDate.now().toEpochDay() }
    val question = remember { DailyContent.questionFor(epochDay) }
    var knowledgeOffset by rememberSaveable { mutableIntStateOf(0) }
    val knowledge = DailyContent.knowledgeFor(epochDay, knowledgeOffset)
    var showGoals by rememberSaveable { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        // Header with logo and greeting
        val primary = MaterialTheme.colorScheme.primary
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.linearGradient(listOf(primary, lerp(primary, Color.Black, 0.5f))),
                    shape = RoundedCornerShape(24.dp)
                )
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            LogoMark(logoSize = 56.dp, animate = false)
            Spacer(Modifier.width(16.dp))
            Column {
                Text(
                    text = if (name.isBlank()) stringResource(R.string.app_name)
                    else stringResource(R.string.home_greeting, name),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = stringResource(R.string.home_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.85f)
                )
            }
        }

        // Search bar
        Spacer(Modifier.height(16.dp))
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onOpenSearch)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Filled.Search,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    text = stringResource(R.string.search_hint),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Goals
        Spacer(Modifier.height(16.dp))
        GoalsCard(data = data, onClick = { showGoals = true })

        // Continue learning
        Spacer(Modifier.height(16.dp))
        ContinueCard(
            title = recent.firstOrNull()?.let { if (urdu && it.titleUr.isNotBlank()) it.titleUr else it.titleEn },
            onClick = {
                val last = recent.firstOrNull()
                if (last != null) onOpenSection(last.id) else onOpenTab(BottomTab.LIBRARY)
            }
        )

        // Quick access
        SectionHeader(stringResource(R.string.quick_title))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            QuickCard(Icons.AutoMirrored.Filled.MenuBook, stringResource(R.string.quick_laws), { onOpenTab(BottomTab.LIBRARY) }, Modifier.weight(1f))
            QuickCard(Icons.Filled.Quiz, stringResource(R.string.quick_quiz), { onOpenTab(BottomTab.PRACTICE) }, Modifier.weight(1f))
            QuickCard(Icons.Filled.Style, stringResource(R.string.quick_flashcards), { onOpenTab(BottomTab.PRACTICE) }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            QuickCard(Icons.Filled.QuestionAnswer, stringResource(R.string.quick_bank), { onOpenBank() }, Modifier.weight(1f))
            QuickCard(Icons.Filled.EditNote, stringResource(R.string.quick_notes), { onOpenTab(BottomTab.STUDY) }, Modifier.weight(1f))
            QuickCard(Icons.Filled.Bookmarks, stringResource(R.string.quick_bookmarks), { onOpenTab(BottomTab.STUDY) }, Modifier.weight(1f))
        }

        // Daily question
        Spacer(Modifier.height(20.dp))
        DailyQuestionCard(
            question = question,
            chosen = data.dailyChoice,
            urdu = urdu,
            onChoose = { homeVm.answerDaily(it) }
        )

        // Daily knowledge
        Spacer(Modifier.height(16.dp))
        KnowledgeCardView(
            card = knowledge,
            urdu = urdu,
            onAnother = { knowledgeOffset += 1 }
        )

        // Recently viewed
        SectionHeader(stringResource(R.string.recent_title))
        if (recent.isEmpty()) {
            Text(
                text = stringResource(R.string.recent_empty),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            recent.take(5).forEach { section ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenSection(section.id) }
                        .padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.History,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text = section.number + "  " +
                            if (urdu && section.titleUr.isNotBlank()) section.titleUr else section.titleEn,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }

    if (showGoals) {
        GoalsDialog(
            currentQuestions = data.goalQuestions,
            currentMinutes = data.goalMinutes,
            onSave = { q, m ->
                homeVm.setGoals(q, m)
                showGoals = false
            },
            onDismiss = { showGoals = false }
        )
    }
}
