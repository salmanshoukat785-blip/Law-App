package com.pakistanlaws.app.ui

import com.pakistanlaws.app.content.LawCatalog

/** Laws whose provisions are called "Articles" rather than "sections". */
private val ARTICLE_LAWS = setOf("qso", "police_order", "hadd")

/** "Article" for the QSO, Police Order and Hadd Order; "Section" for every other law. */
fun sectionWord(lawId: String): String = if (lawId in ARTICLE_LAWS) "Article" else "Section"

/** Turns a section id such as "arms-8" into a short label such as "Arms s.8" (or "QSO Art.17"). */
fun sectionRef(sectionId: String): String {
    val lawId = sectionId.substringBefore('-')
    val number = sectionId.substringAfter('-', "")
    val name = LawCatalog.laws.firstOrNull { it.id == lawId }?.shortName ?: lawId
    val unit = if (lawId in ARTICLE_LAWS) "Art." else "s."
    return if (number.isEmpty()) name else "$name $unit$number"
}
